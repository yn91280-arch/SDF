import {
  pgTable,
  serial,
  varchar,
  text,
  integer,
  boolean,
  timestamp,
  numeric,
  jsonb,
  index,
} from "drizzle-orm/pg-core";

// ---------- Admin Users ----------
export const adminUsers = pgTable("admin_users", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 200 }).notNull().default("مدير المعرض"),
  email: varchar("email", { length: 255 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: varchar("role", { length: 50 }).notNull().default("admin"),
  isActive: boolean("is_active").notNull().default(true),
  lastLoginAt: timestamp("last_login_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// ---------- Admin Sessions ----------
export const adminSessions = pgTable("admin_sessions", {
  id: serial("id").primaryKey(),
  adminId: integer("admin_id").notNull(),
  token: varchar("token", { length: 255 }).notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ---------- Customers ----------
export const customers = pgTable(
  "customers",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 200 }).notNull(),
    phone: varchar("phone", { length: 30 }).notNull(),
    email: varchar("email", { length: 255 }),
    passwordHash: text("password_hash"),
    address: text("address"),
    isActive: boolean("is_active").notNull().default(true),
    totalOrders: integer("total_orders").notNull().default(0),
    totalSpent: numeric("total_spent", { precision: 14, scale: 2 }).notNull().default("0"),
    lastOrderAt: timestamp("last_order_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [index("idx_customers_phone").on(t.phone), index("idx_customers_email").on(t.email)]
);

// ---------- Customer Sessions ----------
export const customerSessions = pgTable("customer_sessions", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  token: varchar("token", { length: 255 }).notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ---------- Categories ----------
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 200 }).notNull(),
  slug: varchar("slug", { length: 200 }).notNull().unique(),
  description: text("description"),
  image: text("image"),
  isActive: boolean("is_active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  discountPercent: numeric("discount_percent", { precision: 5, scale: 2 }).notNull().default("0"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// ---------- Companies ----------
export const companies = pgTable("companies", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 200 }).notNull(),
  slug: varchar("slug", { length: 200 }).notNull().unique(),
  logo: text("logo"),
  description: text("description"),
  contactPhone: varchar("contact_phone", { length: 50 }),
  contactEmail: varchar("contact_email", { length: 255 }),
  lastPriceUpdate: timestamp("last_price_update"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// ---------- Products ----------
export const products = pgTable(
  "products",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 300 }).notNull(),
    companyId: integer("company_id"),
    companyName: varchar("company_name", { length: 200 }),
    brand: varchar("brand", { length: 200 }),
    code: varchar("code", { length: 100 }).notNull(),
    model: varchar("model", { length: 200 }),
    categoryId: integer("category_id"),
    price: numeric("price", { precision: 14, scale: 2 }).notNull().default("0"),
    oldPrice: numeric("old_price", { precision: 14, scale: 2 }),
    discountPrice: numeric("discount_price", { precision: 14, scale: 2 }),
    stock: integer("stock").notNull().default(0),
    minStock: integer("min_stock").notNull().default(5),
    size: varchar("size", { length: 100 }),
    color: varchar("color", { length: 100 }),
    description: text("description"),
    specifications: jsonb("specifications").$type<Record<string, string>>(),
    images: jsonb("images").$type<string[]>().notNull().default([]),
    keywords: text("keywords"),
    searchText: text("search_text"),
    isActive: boolean("is_active").notNull().default(true),
    isFeatured: boolean("is_featured").notNull().default(false),
    isOffer: boolean("is_offer").notNull().default(false),
    views: integer("views").notNull().default(0),
    soldCount: integer("sold_count").notNull().default(0),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [
    index("idx_products_code").on(t.code),
    index("idx_products_category").on(t.categoryId),
    index("idx_products_company").on(t.companyId),
    index("idx_products_active").on(t.isActive),
    index("idx_products_offer").on(t.isOffer),
    index("idx_products_name").on(t.name),
  ]
);

// ---------- Price Lists ----------
export const priceLists = pgTable("price_lists", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id"),
  companyName: varchar("company_name", { length: 200 }),
  fileName: varchar("file_name", { length: 300 }),
  fileType: varchar("file_type", { length: 20 }),
  totalItems: integer("total_items").notNull().default(0),
  newCount: integer("new_count").notNull().default(0),
  existingCount: integer("existing_count").notNull().default(0),
  reviewCount: integer("review_count").notNull().default(0),
  status: varchar("status", { length: 30 }).notNull().default("preview"),
  createdBy: integer("created_by"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const priceListItems = pgTable("price_list_items", {
  id: serial("id").primaryKey(),
  priceListId: integer("price_list_id").notNull(),
  name: varchar("name", { length: 300 }),
  code: varchar("code", { length: 100 }),
  model: varchar("model", { length: 200 }),
  size: varchar("size", { length: 100 }),
  color: varchar("color", { length: 100 }),
  price: numeric("price", { precision: 14, scale: 2 }),
  companyName: varchar("company_name", { length: 200 }),
  matchStatus: varchar("match_status", { length: 20 }).notNull().default("new"),
  matchedProductId: integer("matched_product_id"),
  rawData: jsonb("raw_data").$type<Record<string, unknown>>(),
  isApplied: boolean("is_applied").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ---------- Orders ----------
export const orders = pgTable(
  "orders",
  {
    id: serial("id").primaryKey(),
    orderNumber: varchar("order_number", { length: 50 }).notNull().unique(),
    customerId: integer("customer_id"),
    customerName: varchar("customer_name", { length: 200 }).notNull(),
    customerPhone: varchar("customer_phone", { length: 30 }).notNull(),
    customerAddress: text("customer_address"),
    notes: text("notes"),
    subtotal: numeric("subtotal", { precision: 14, scale: 2 }).notNull().default("0"),
    discount: numeric("discount", { precision: 14, scale: 2 }).notNull().default("0"),
    total: numeric("total", { precision: 14, scale: 2 }).notNull().default("0"),
    status: varchar("status", { length: 30 }).notNull().default("new"),
    source: varchar("source", { length: 30 }).notNull().default("website"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [index("idx_orders_status").on(t.status), index("idx_orders_customer").on(t.customerId), index("idx_orders_date").on(t.createdAt)]
);

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  productId: integer("product_id"),
  productName: varchar("product_name", { length: 300 }).notNull(),
  productCode: varchar("product_code", { length: 100 }),
  companyName: varchar("company_name", { length: 200 }),
  quantity: integer("quantity").notNull().default(1),
  price: numeric("price", { precision: 14, scale: 2 }).notNull().default("0"),
  discount: numeric("discount", { precision: 14, scale: 2 }).notNull().default("0"),
  total: numeric("total", { precision: 14, scale: 2 }).notNull().default("0"),
});

// ---------- Invoices ----------
export const invoices = pgTable(
  "invoices",
  {
    id: serial("id").primaryKey(),
    invoiceNumber: varchar("invoice_number", { length: 50 }).notNull().unique(),
    customerName: varchar("customer_name", { length: 200 }).notNull(),
    customerPhone: varchar("customer_phone", { length: 30 }),
    customerAddress: text("customer_address"),
    subtotal: numeric("subtotal", { precision: 14, scale: 2 }).notNull().default("0"),
    discount: numeric("discount", { precision: 14, scale: 2 }).notNull().default("0"),
    tax: numeric("tax", { precision: 14, scale: 2 }).notNull().default("0"),
    extraCharges: numeric("extra_charges", { precision: 14, scale: 2 }).notNull().default("0"),
    total: numeric("total", { precision: 14, scale: 2 }).notNull().default("0"),
    paid: numeric("paid", { precision: 14, scale: 2 }).notNull().default("0"),
    remaining: numeric("remaining", { precision: 14, scale: 2 }).notNull().default("0"),
    status: varchar("status", { length: 30 }).notNull().default("unpaid"),
    notes: text("notes"),
    templateId: varchar("template_id", { length: 50 }).notNull().default("classic"),
    createdBy: integer("created_by"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [index("idx_invoices_date").on(t.createdAt), index("idx_invoices_status").on(t.status)]
);

export const invoiceItems = pgTable("invoice_items", {
  id: serial("id").primaryKey(),
  invoiceId: integer("invoice_id").notNull(),
  productId: integer("product_id"),
  productName: varchar("product_name", { length: 300 }).notNull(),
  productCode: varchar("product_code", { length: 100 }),
  quantity: integer("quantity").notNull().default(1),
  price: numeric("price", { precision: 14, scale: 2 }).notNull().default("0"),
  discount: numeric("discount", { precision: 14, scale: 2 }).notNull().default("0"),
  total: numeric("total", { precision: 14, scale: 2 }).notNull().default("0"),
});

// ---------- Inventory Movements ----------
export const inventoryMovements = pgTable(
  "inventory_movements",
  {
    id: serial("id").primaryKey(),
    productId: integer("product_id").notNull(),
    productName: varchar("product_name", { length: 300 }),
    type: varchar("type", { length: 20 }).notNull(),
    quantity: integer("quantity").notNull(),
    previousStock: integer("previous_stock").notNull().default(0),
    newStock: integer("new_stock").notNull().default(0),
    reason: varchar("reason", { length: 300 }),
    referenceId: varchar("reference_id", { length: 100 }),
    createdBy: integer("created_by"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_movements_product").on(t.productId), index("idx_movements_date").on(t.createdAt)]
);

// ---------- Offers / Banners ----------
export const offers = pgTable("offers", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 300 }).notNull(),
  subtitle: varchar("subtitle", { length: 500 }),
  image: text("image"),
  linkType: varchar("link_type", { length: 30 }).notNull().default("products"),
  linkValue: varchar("link_value", { length: 300 }),
  discountPercent: numeric("discount_percent", { precision: 5, scale: 2 }),
  isActive: boolean("is_active").notNull().default(true),
  startsAt: timestamp("starts_at"),
  endsAt: timestamp("ends_at"),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ---------- Settings ----------
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// ---------- Login attempts (rate limiting) ----------
export const loginAttempts = pgTable("login_attempts", {
  id: serial("id").primaryKey(),
  identifier: varchar("identifier", { length: 200 }).notNull(),
  success: boolean("success").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
