export default function Logo({ size = 56, className = "" }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      role="img"
      aria-label="شعار معرض المصطفي"
    >
      <defs>
        <linearGradient id="amGold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#f6e27a" />
          <stop offset="45%" stopColor="#c9a227" />
          <stop offset="100%" stopColor="#8c6b12" />
        </linearGradient>
        <linearGradient id="amWater" x1="0.5" y1="0" x2="0.5" y2="1">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="100%" stopColor="#cfd8e6" />
        </linearGradient>
      </defs>
      {/* house roof */}
      <path
        d="M60 8 L112 52 L101 52 L101 112 L19 112 L19 52 L8 52 Z"
        fill="none"
        stroke="url(#amGold)"
        strokeWidth="7"
        strokeLinejoin="round"
      />
      {/* window grid */}
      <rect x="72" y="40" width="16" height="16" rx="2" fill="url(#amGold)" />
      <rect x="82" y="50" width="2" height="16" fill="#0b1526" />
      <rect x="72" y="58" width="16" height="2" fill="#0b1526" />
      {/* water droplet */}
      <path
        d="M60 30 C60 30 74 47 74 58 C74 66.2 67.7 72 60 72 C52.3 72 46 66.2 46 58 C46 47 60 30 60 30 Z"
        fill="url(#amWater)"
      />
      <path d="M55 55 C55 55 52 60 52 63 C52 65.8 54.6 68 58 68" stroke="#0b1526" strokeOpacity="0.25" strokeWidth="2.5" fill="none" strokeLinecap="round" />
      {/* faucet */}
      <path
        d="M32 108 L32 84 L50 84 L50 76"
        stroke="url(#amGold)"
        strokeWidth="7"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      <path d="M22 84 L42 84" stroke="url(#amGold)" strokeWidth="7" strokeLinecap="round" />
      <path d="M50 76 L58 76" stroke="url(#amGold)" strokeWidth="7" strokeLinecap="round" />
    </svg>
  );
}
