"use client";
import Link from "next/link";
import { useState } from "react";
import { useCart } from "./CartProvider";
import { effectivePrice, formatPrice } from "@/lib/utils";

export type ProductCardData = {
  id: number;
  name: string;
  code: string;
  model?: string | null;
  companyName?: string | null;
  brand?: string | null;
  price: number | string;
  oldPrice?: number | string | null;
  discountPrice?: number | string | null;
  stock: number;
  size?: string | null;
  color?: string | null;
  images?: string[];
  isOffer?: boolean;
};

export default function ProductCard({ p, whatsapp }: { p: ProductCardData; whatsapp: string }) {
  const cart = useCart();
  const [fav, setFav] = useState(false);
  const [imgOk, setImgOk] = useState(true);
  const img = imgOk && p.images?.[0] ? p.images[0] : "/images/showroom-shelf.jpg";
  const { final, old, pct } = effectivePrice({ price: p.price, discountPrice: p.discountPrice, oldPrice: p.oldPrice });
  const out = p.stock <= 0;

  const waMsg = encodeURIComponent(
    `🛁 طلب جديد\n———————————\n📦 المنتج: ${p.name}\n🔢 الكود: ${p.code}\n🏭 الشركة: ${p.companyName || ""}\n💰 السعر: ${final} ج.م\n🔢 الكمية: 1\n———————————\n🌐 الموقع: https://Sanitary-ware-store\n🏪 معرض المصطفي`
  );
  const digits = (whatsapp || "01147104601").replace(/[^0-9]/g, "");
  const waNum = digits.startsWith("20") ? digits : "20" + digits.replace(/^0/, "");

  return (
    <div className="group relative flex flex-col overflow-hidden rounded-2xl border border-[#e7e2d6] bg-white transition-all duration-300 hover:-translate-y-1 hover:border-[#c9a227]/50 hover:shadow-[0_18px_45px_rgba(11,21,38,0.16)]">
      {pct > 0 && (
        <span className="absolute right-3 top-3 z-10 rounded-full gold-bg px-2.5 py-1 text-[11px] font-black text-[#0b1526] shadow">
          خصم {pct}%
        </span>
      )}
      <button
        onClick={() => setFav(!fav)}
        aria-label="المفضلة"
        className={`absolute left-3 top-3 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-white/90 text-sm shadow transition hover:scale-110 ${fav ? "text-red-500" : "text-gray-400"}`}
      >
        {fav ? "♥" : "♡"}
      </button>

      <Link href={`/products/${p.id}`} className="relative block aspect-[4/3] overflow-hidden bg-[#f4f1e9]">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={img}
          alt={p.name}
          loading="lazy"
          onError={() => setImgOk(false)}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        {out && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/45">
            <span className="rounded-full bg-red-600 px-4 py-1.5 text-xs font-bold text-white">نفد المخزون</span>
          </div>
        )}
      </Link>

      <div className="flex flex-1 flex-col p-3.5">
        <Link href={`/products/${p.id}`} className="line-clamp-2 min-h-[2.6rem] text-[14.5px] font-bold leading-6 text-[#0b1526] hover:text-[#a87f14]">
          {p.name}
        </Link>
        <div className="mt-1.5 flex items-center gap-1.5 text-[11.5px] text-gray-500">
          <span className="font-semibold text-[#0b1526]">{p.companyName || p.brand || "—"}</span>
          <span className="text-gray-300">|</span>
          <span className="font-mono tracking-wide" dir="ltr">{p.code}</span>
        </div>

        <div className="mt-2.5 flex items-end justify-between">
          <div>
            {old && <div className="text-[11px] text-gray-400 line-through">{formatPrice(old)}</div>}
            <div className="text-[19px] font-black text-[#0b1526]">{formatPrice(final)}</div>
          </div>
          <span className={`rounded-full px-2.5 py-1 text-[10.5px] font-bold ${out ? "bg-red-50 text-red-600" : "bg-emerald-50 text-emerald-700"}`}>
            {out ? "غير متوفر" : "متوفر"}
          </span>
        </div>

        <button
          disabled={out}
          onClick={() => cart.add({ id: p.id, name: p.name, code: p.code, company: p.companyName || "", price: Number(final), oldPrice: old ? Number(old) : null, image: img }, 1)}
          className="mt-3 w-full rounded-xl bg-[#0b1526] py-2.5 text-[13px] font-bold text-white transition hover:bg-[#1c2f57] disabled:cursor-not-allowed disabled:opacity-40"
        >
          أضف إلى السلة
        </button>
        <div className="mt-2 grid grid-cols-2 gap-2">
          <a
            href={`https://wa.me/${waNum}?text=${waMsg}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-1 rounded-xl border border-[#25D366]/35 bg-[#25D366]/10 py-2 text-[11.5px] font-bold text-[#128c4a]"
          >
            واتساب
          </a>
          <Link href={`/products/${p.id}`} className="flex items-center justify-center rounded-xl border border-[#c9a227]/40 bg-[#c9a227]/10 py-2 text-[11.5px] font-bold text-[#7a5f0e]">
            التفاصيل
          </Link>
        </div>
      </div>
    </div>
  );
}
