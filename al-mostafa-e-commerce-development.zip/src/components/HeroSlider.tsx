"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

export type Slide = { title: string; subtitle: string; image: string; cta: string; href: string };

export default function HeroSlider({ slides }: { slides: Slide[] }) {
  const [idx, setIdx] = useState(0);
  const items = slides.length > 0 ? slides : [];
  useEffect(() => {
    if (items.length < 2) return;
    const t = setInterval(() => setIdx((i) => (i + 1) % items.length), 6500);
    return () => clearInterval(t);
  }, [items.length]);
  if (items.length === 0) return null;
  const s = items[idx];

  return (
    <div className="relative h-full min-h-[380px] overflow-hidden rounded-2xl">
      {items.map((sl, i) => (
        <div
          key={i}
          className={`absolute inset-0 transition-opacity duration-700 ${i === idx ? "opacity-100" : "opacity-0"}`}
          style={{ backgroundImage: `url('${sl.image}')`, backgroundSize: "cover", backgroundPosition: "center" }}
        />
      ))}
      <div className="absolute inset-0 bg-gradient-to-l from-transparent via-[#0b1526]/55 to-[#0b1526]/92" />
      <div className="relative flex h-full flex-col justify-center px-6 sm:px-10">
        <h2 className="text-[26px] font-black leading-[1.6] text-white drop-shadow sm:text-[34px]">
          <span className="gold-text">{s.title.slice(0, s.title.indexOf(" ") + 1)}</span>
          {s.title.slice(s.title.indexOf(" ") + 1)}
        </h2>
        <p className="mt-3 max-w-[520px] text-sm leading-7 text-white/80 sm:text-base">{s.subtitle}</p>
        <Link
          href={s.href}
          className="mt-6 w-fit rounded-full px-8 py-3.5 text-base font-black text-[#0b1526] shadow-[0_12px_35px_rgba(201,162,39,0.4)] transition hover:scale-105"
          style={{ background: "linear-gradient(135deg,#f3dc92,#c9a227 50%,#e8c766)" }}
        >
          {s.cta} ←
        </Link>
      </div>

      {items.length > 1 && (
        <>
          <button
            onClick={() => setIdx((idx - 1 + items.length) % items.length)}
            aria-label="السابق"
            className="absolute left-4 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full border border-white/25 bg-black/30 text-white backdrop-blur transition hover:bg-[#c9a227] hover:text-[#0b1526]"
          >
            ‹
          </button>
          <button
            onClick={() => setIdx((idx + 1) % items.length)}
            aria-label="التالي"
            className="absolute right-4 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full border border-white/25 bg-black/30 text-white backdrop-blur transition hover:bg-[#c9a227] hover:text-[#0b1526]"
          >
            ›
          </button>
          <div className="absolute bottom-5 left-1/2 flex -translate-x-1/2 gap-2">
            {items.map((_, i) => (
              <button
                key={i}
                onClick={() => setIdx(i)}
                aria-label={`شريحة ${i + 1}`}
                className={`h-2.5 rounded-full transition-all ${i === idx ? "w-8 gold-bg" : "w-2.5 bg-white/45"}`}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
