import type React from "react";
import Logo from "@/components/Logo";
import { formatPrice, formatDate, INVOICE_STATUS_AR } from "@/lib/utils";

/**
 * ───────────────────────────────────────────────────────────────
 *  نظام قوالب الفواتير القابل للاستبدال
 *  ------------------------------------------------------------
 *  منطق الأعمال (الحسابات / الأرقام / المدفوعات) مستقل تماماً عن
 *  التصميم البصري. لإضافة تصميم جديد:
 *    1) أنشئ مكوّناً يأخذ { invoice, items, settings }
 *    2) سجّله في INVOICE_TEMPLATES بمعرّف جديد (مثل "my-design")
 *  لن تحتاج لتعديل أي حسابات أو API أو قاعدة بيانات.
 * ───────────────────────────────────────────────────────────────
 */

export type InvoiceData = {
  invoice: {
    id: number;
    invoiceNumber: string;
    customerName: string;
    customerPhone?: string | null;
    customerAddress?: string | null;
    subtotal: string | number;
    discount: string | number;
    tax: string | number;
    extraCharges: string | number;
    total: string | number;
    paid: string | number;
    remaining: string | number;
    status: string;
    notes?: string | null;
    createdAt: string | Date;
  };
  items: Array<{
    id?: number;
    productName: string;
    productCode?: string | null;
    quantity: number;
    price: string | number;
    discount: string | number;
    total: string | number;
  }>;
  settings: Record<string, string>;
};

function Head({ s }: { s: Record<string, string> }) {
  return (
    <div className="flex items-start justify-between">
      <div className="flex items-center gap-3">
        <Logo size={68} />
        <div>
          <div className="text-[22px] font-black text-[#0b1526]">{s.store_name || "معرض المصطفي"}</div>
          <div className="text-[13px] font-bold text-[#a87f14]">للأدوات الصحية والسباكة</div>
          <div className="mt-1 text-[11px] text-gray-500">إدارة / {s.manager?.replace("إدارة / ", "") || "محمد محمود طلبة"}</div>
        </div>
      </div>
      <div className="text-left">
        <div className="rounded-xl bg-[#0b1526] px-5 py-2 text-lg font-black text-[#e8c766]">فاتورة مبيعات</div>
        <div className="mt-2 text-[11px] text-gray-500">
          رقم الفاتورة: <span className="font-bold text-[#0b1526]" dir="ltr">{s.invoiceNumber || ""}</span>
        </div>
      </div>
    </div>
  );
}

function Meta({ invoice }: { invoice: InvoiceData["invoice"] }) {
  return (
    <div className="mt-5 grid grid-cols-3 gap-3 rounded-2xl bg-[#f6f4ee] p-4 text-[12px]">
      <div>
        <div className="text-gray-500">اسم العميل</div>
        <div className="font-bold text-[#0b1526]">{invoice.customerName}</div>
      </div>
      <div>
        <div className="text-gray-500">رقم الهاتف</div>
        <div className="font-bold text-[#0b1526]" dir="ltr">{invoice.customerPhone || "—"}</div>
      </div>
      <div>
        <div className="text-gray-500">التاريخ</div>
        <div className="font-bold text-[#0b1526]">{formatDate(invoice.createdAt)}</div>
      </div>
    </div>
  );
}

function ItemsTable({ items }: { items: InvoiceData["items"] }) {
  return (
    <table className="mt-4 w-full text-[12px]">
      <thead>
        <tr className="bg-[#0b1526] text-white">
          <th className="p-2.5 text-right">#</th>
          <th className="p-2.5 text-right">اسم المنتج</th>
          <th className="p-2.5 text-right">الكود</th>
          <th className="p-2.5 text-center">الكمية</th>
          <th className="p-2.5 text-center">السعر</th>
          <th className="p-2.5 text-center">الخصم</th>
          <th className="p-2.5 text-left">الإجمالي</th>
        </tr>
      </thead>
      <tbody>
        {items.map((it, i) => (
          <tr key={i} className="border-b border-[#e7e2d6]">
            <td className="p-2.5">{i + 1}</td>
            <td className="p-2.5 font-bold">{it.productName}</td>
            <td className="p-2.5 font-mono text-gray-500" dir="ltr">{it.productCode || "—"}</td>
            <td className="p-2.5 text-center">{it.quantity}</td>
            <td className="p-2.5 text-center">{formatPrice(it.price)}</td>
            <td className="p-2.5 text-center">{formatPrice(it.discount)}</td>
            <td className="p-2.5 text-left font-bold">{formatPrice(it.total)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function Totals({ invoice, s }: { invoice: InvoiceData["invoice"]; s: Record<string, string> }) {
  return (
    <div className="mt-5 grid grid-cols-2 gap-4">
      <div className="rounded-2xl border border-[#e7e2d6] p-4 text-[12px]">
        <div className="font-bold text-[#0b1526]">حالة الفاتورة</div>
        <div className="mt-1 inline-block rounded-full bg-[#c9a227]/15 px-3 py-1 font-bold text-[#7a5f0e]">
          {INVOICE_STATUS_AR[invoice.status] || invoice.status}
        </div>
        <div className="mt-3 text-gray-500">
          {invoice.notes || s.invoice_notes || "شكراً لتعاملكم مع معرض المصطفي"}
        </div>
      </div>
      <div className="space-y-1.5 text-[12.5px]">
        <Row label="المجموع الفرعي" value={formatPrice(invoice.subtotal)} />
        <Row label="الخصم" value={"− " + formatPrice(invoice.discount)} />
        {Number(invoice.tax) > 0 && <Row label="الضريبة" value={formatPrice(invoice.tax)} />}
        {Number(invoice.extraCharges) > 0 && <Row label="رسوم إضافية" value={formatPrice(invoice.extraCharges)} />}
        <div className="flex items-center justify-between rounded-xl bg-[#0b1526] px-3 py-2.5 text-white">
          <span className="font-bold">الإجمالي</span>
          <span className="text-base font-black text-[#e8c766]">{formatPrice(invoice.total)}</span>
        </div>
        <Row label="المدفوع" value={formatPrice(invoice.paid)} />
        <Row label="المتبقي" value={formatPrice(invoice.remaining)} />
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-gray-500">{label}</span>
      <span className="font-bold text-[#0b1526]">{value}</span>
    </div>
  );
}

/* ── القالب 1: الكلاسيكي ── */
function ClassicTemplate({ invoice, items, settings }: InvoiceData) {
  return (
    <div className="mx-auto max-w-[860px] bg-white p-8 text-[#0b1526]">
      <Head s={{ ...settings, invoiceNumber: invoice.invoiceNumber }} />
      <Meta invoice={invoice} />
      <ItemsTable items={items} />
      <Totals invoice={invoice} s={settings} />
      <Footer s={settings} />
    </div>
  );
}

/* ── القالب 2: العصري ── */
function ModernTemplate({ invoice, items, settings }: InvoiceData) {
  return (
    <div className="mx-auto max-w-[860px] bg-white p-8 text-[#0b1526]">
      <div className="rounded-3xl bg-gradient-to-l from-[#0b1526] to-[#1c2f57] p-6 text-white">
        <div className="flex items-center gap-3">
          <Logo size={58} />
          <div>
            <div className="text-xl font-black gold-text">{settings.store_name || "معرض المصطفي"}</div>
            <div className="text-xs text-white/70">للأدوات الصحية والسباكة</div>
          </div>
          <div className="ms-auto text-left">
            <div className="text-sm text-white/60">فاتورة مبيعات</div>
            <div className="font-mono text-lg text-[#e8c766]" dir="ltr">{invoice.invoiceNumber}</div>
          </div>
        </div>
      </div>
      <Meta invoice={invoice} />
      <ItemsTable items={items} />
      <Totals invoice={invoice} s={settings} />
      <Footer s={settings} />
    </div>
  );
}

/* ── القالب 3: المختصر ── */
function CompactTemplate({ invoice, items, settings }: InvoiceData) {
  return (
    <div className="mx-auto max-w-[620px] bg-white p-6 text-[#0b1526]">
      <div className="flex items-center justify-between border-b-2 border-[#c9a227] pb-3">
        <div>
          <div className="text-lg font-black">{settings.store_name || "معرض المصطفي"}</div>
          <div className="text-[11px] text-gray-500">{settings.phone}</div>
        </div>
        <div className="text-left text-[11px]">
          <div>فاتورة رقم: <b dir="ltr">{invoice.invoiceNumber}</b></div>
          <div>{formatDate(invoice.createdAt)}</div>
        </div>
      </div>
      <div className="mt-3 text-[12px]">العميل: <b>{invoice.customerName}</b> — <span dir="ltr">{invoice.customerPhone}</span></div>
      <ItemsTable items={items} />
      <Totals invoice={invoice} s={settings} />
      <Footer s={settings} />
    </div>
  );
}

function Footer({ s }: { s: Record<string, string> }) {
  return (
    <div className="mt-6 border-t border-dashed border-[#c9a227]/50 pt-4 text-center">
      <div className="text-[11px] text-gray-500">
        {s.phone ? `للاستفسار: ${s.phone}` : ""} {s.whatsapp ? ` • واتساب: ${s.whatsapp}` : ""}
      </div>
      <div className="mt-1 text-[12px] font-bold text-[#a87f14]">شكراً لتعاملكم معنا — {s.store_name || "معرض المصطفي"}</div>
    </div>
  );
}

export const INVOICE_TEMPLATES: Record<string, (p: InvoiceData) => React.ReactElement> = {
  classic: ClassicTemplate,
  modern: ModernTemplate,
  compact: CompactTemplate,
};

export const INVOICE_TEMPLATE_LIST = [
  { id: "classic", name: "الكلاسيكي" },
  { id: "modern", name: "العصري" },
  { id: "compact", name: "المختصر" },
];

export function getInvoiceTemplate(id?: string | null) {
  return INVOICE_TEMPLATES[id || "classic"] || ClassicTemplate;
}
