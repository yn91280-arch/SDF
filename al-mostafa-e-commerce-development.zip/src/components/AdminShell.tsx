"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Logo from "./Logo";

const MENU = [
  { href: "/admin", icon: "🏠", label: "الرئيسية" },
  { href: "/admin/products", icon: "🛁", label: "المنتجات" },
  { href: "/admin/categories", icon: "▦", label: "الأقسام" },
  { href: "/admin/import", icon: "📥", label: "استيراد الأسعار" },
  { href: "/admin/orders", icon: "🛒", label: "الطلبات", badge: true },
  { href: "/admin/customers", icon: "👥", label: "العملاء" },
  { href: "/admin/invoices", icon: "🧾", label: "الفواتير" },
  { href: "/admin/inventory", icon: "📦", label: "المخزون" },
  { href: "/admin/companies", icon: "🏭", label: "الموردين" },
  { href: "/admin/reports", icon: "📊", label: "التقارير" },
  { href: "/admin/users", icon: "👤", label: "المستخدمون" },
  { href: "/admin/settings", icon: "⚙️", label: "إعدادات الموقع" },
  { href: "/admin/security", icon: "🔒", label: "الأمان" },
];

export default function AdminShell({ children, title, noPad }: { children: React.ReactNode; title: string; noPad?: boolean }) {
  const pathname = usePathname();
  const router = useRouter();
  const [admin, setAdmin] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [search, setSearch] = useState("");

  useEffect(() => {
    fetch("/api/admin/me").then((r) => r.json()).then((j) => {
      if (!j.ok) router.push("/admin/login");
      else { setAdmin(j.admin); setLoading(false); }
    }).catch(() => router.push("/admin/login"));
  }, [router]);

  const logout = async () => {
    await fetch("/api/admin/logout", { method: "POST" });
    router.push("/admin/login");
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#060b16]" dir="rtl">
        <div className="text-center">
          <Logo size={80} className="mx-auto animate-pulse" />
          <div className="mt-3 text-sm text-white/55">جاري التحقق من الهوية…</div>
        </div>
      </div>
    );
  }

  return (
    <div dir="rtl" className="min-h-screen bg-[#0a1222] text-white">
      {/* ── topbar ── */}
      <div className="sticky top-0 z-30 border-b border-white/8 bg-[#0b1526]/95 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1600px] items-center gap-3 px-4 py-3">
          <button onClick={() => setMenuOpen(!menuOpen)} className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 lg:hidden" aria-label="القائمة">☰</button>

          <Link href="/admin" className="flex shrink-0 items-center gap-2">
            <Logo size={42} />
            <div>
              <div className="text-lg font-black leading-5">
                <span className="gold-text">معرض</span> <span className="text-white">المصطفى</span>
              </div>
              <div className="text-[10px] text-white/55">للأدوات الصحية والسباكة</div>
            </div>
          </Link>

          <form
            onSubmit={(e) => { e.preventDefault(); router.push(`/admin/products?q=${encodeURIComponent(search)}`); }}
            className="relative mx-auto hidden max-w-[420px] flex-1 md:block"
          >
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="ابحث عن منتج أو طلب أو عميل ..."
              className="w-full rounded-xl border border-white/10 bg-white/[0.06] py-2.5 pe-10 ps-4 text-[13px] text-white placeholder:text-white/35 outline-none focus:border-[#c9a227]"
            />
            <button type="submit" aria-label="بحث" className="absolute end-3 top-1/2 -translate-y-1/2 text-white/45">🔍</button>
          </form>

          <div className="ms-auto flex items-center gap-2">
            <Link href="/admin/orders?status=new" className="relative rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-lg" aria-label="تنبيهات">
              🔔
              <span className="absolute -left-1 -top-1 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-red-600 px-1 text-[10px] font-bold">!</span>
            </Link>
            <Link href="/admin/settings" className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-lg" aria-label="الإعدادات">⚙️</Link>
            <Link href="/" target="_blank" className="hidden rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs font-bold text-white/75 sm:block">
              🌐 عرض الموقع
            </Link>
            <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-1.5">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg gold-bg text-sm font-black text-[#0b1526]">
                {admin?.name?.[0] || "م"}
              </div>
              <div className="hidden leading-4 sm:block">
                <div className="text-xs font-bold">{admin?.name || "مدير النظام"}</div>
                <div className="text-[10px] text-[#e8c766]">مدير النظام</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto flex max-w-[1600px]">
        {/* ── sidebar ── */}
        <aside className={`fixed inset-y-0 right-0 z-40 w-[240px] transform overflow-hidden border-l border-white/8 bg-[#060b16] transition-transform lg:static lg:translate-x-0 ${menuOpen ? "translate-x-0" : "translate-x-full"}`}>
          <div className="flex h-full flex-col">
            <nav className="flex-1 space-y-0.5 overflow-y-auto p-3 pt-20 lg:pt-4">
              {MENU.map((m) => {
                const active = pathname === m.href;
                return (
                  <Link
                    key={m.href}
                    href={m.href}
                    onClick={() => setMenuOpen(false)}
                    className={`flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-[14px] font-bold transition ${
                      active ? "text-[#0b1526] shadow-[0_8px_22px_rgba(201,162,39,0.35)]" : "text-white/70 hover:bg-white/8 hover:text-white"
                    }`}
                    style={active ? { background: "linear-gradient(135deg,#f3dc92,#c9a227 55%,#e8c766)" } : undefined}
                  >
                    <span className="w-5 text-center">{m.icon}</span>
                    <span className="flex-1">{m.label}</span>
                    {m.badge && <span className="rounded-full bg-red-600 px-2 py-0.5 text-[10px] font-bold text-white">جديد</span>}
                  </Link>
                );
              })}
              <button onClick={logout} className="mt-3 flex w-full items-center gap-3 rounded-xl bg-red-600/12 px-3.5 py-2.5 text-[14px] font-bold text-red-400 hover:bg-red-600/25">
                <span className="w-5 text-center">🚪</span> تسجيل الخروج
              </button>
            </nav>
            <div className="relative hidden h-[150px] shrink-0 items-end p-4 lg:flex">
              <div className="absolute inset-0 opacity-40" style={{ backgroundImage: "url('/images/showroom-shelf.jpg')", backgroundSize: "cover", backgroundPosition: "center" }} />
              <div className="absolute inset-0 bg-gradient-to-t from-[#060b16] via-[#060b16]/85 to-transparent" />
              <div className="relative">
                <div className="text-lg font-black"><span className="gold-text">معرض المصطفي</span></div>
                <div className="font-lux text-[13px] text-white/70">جودة .. تنافسية .. خدمة أفضل</div>
              </div>
            </div>
          </div>
        </aside>
        {menuOpen && <div className="fixed inset-0 z-30 bg-black/55 lg:hidden" onClick={() => setMenuOpen(false)} />}

        {/* ── content ── */}
        <main className={`min-w-0 flex-1 ${noPad ? "" : "p-4 sm:p-6"}`}>
          {!noPad && <h1 className="mb-4 text-[19px] font-black text-white sm:text-[22px]">{title}</h1>}
          <div className="text-white">{children}</div>
        </main>
      </div>
    </div>
  );
}

export function StatCard({ icon, label, value, sub, trend }: { icon: string; label: string; value: string | number; sub?: string; trend?: string }) {
  return (
    <div className="rounded-2xl border border-white/8 bg-gradient-to-b from-white/[0.07] to-white/[0.02] p-4">
      <div className="flex items-center gap-3">
        <span className="flex h-12 w-12 items-center justify-center rounded-xl border border-[#c9a2740] text-2xl" style={{ background: "linear-gradient(135deg,#c9a22733,#c9a22712)", borderColor: "#c9a22755" }}>
          {icon}
        </span>
        <div>
          <div className="text-xs text-white/55">{label}</div>
          <div className="text-[20px] font-black leading-6 text-white">{value}</div>
          {trend && <div className="text-[11px] font-bold text-emerald-400">{trend}</div>}
          {sub && <div className="text-[11px] text-white/40">{sub}</div>}
        </div>
      </div>
    </div>
  );
}

export function Panel({ title, children, action }: { title: string; children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-white/8 bg-white/[0.035] p-4 sm:p-5">
      <div className="mb-4 flex items-center justify-between gap-3">
        <h3 className="flex items-center gap-2 font-black text-white">
          <span className="text-[#e8c766]">◆</span> {title}
        </h3>
        {action}
      </div>
      {children}
    </div>
  );
}

export const inputCls = "w-full rounded-xl border border-white/12 bg-white/[0.07] px-4 py-2.5 text-sm text-white placeholder:text-white/32 outline-none focus:border-[#c9a227]";
export const btnGold = "rounded-xl px-5 py-2.5 text-sm font-black text-[#0b1526] transition hover:brightness-110 disabled:opacity-50";
export const btnGoldStyle = { background: "linear-gradient(135deg,#f3dc92,#c9a227 55%,#e8c766)" } as const;
export const btnDark = "rounded-xl border border-white/15 bg-white/8 px-5 py-2.5 text-sm font-bold text-white hover:bg-white/15";
