"use client";
import React, { createContext, useContext, useEffect, useMemo, useState } from "react";

export type CartItem = {
  id: number;
  name: string;
  code: string;
  company?: string;
  price: number;
  oldPrice?: number | null;
  image?: string;
  qty: number;
  size?: string;
  color?: string;
};

type CartCtx = {
  items: CartItem[];
  count: number;
  subtotal: number;
  discount: number;
  total: number;
  add: (item: Omit<CartItem, "qty">, qty?: number) => void;
  remove: (id: number) => void;
  setQty: (id: number, qty: number) => void;
  clear: () => void;
  open: boolean;
  setOpen: (v: boolean) => void;
};

const Ctx = createContext<CartCtx | null>(null);
const KEY = "am_cart_v1";

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [open, setOpen] = useState(false);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setItems(JSON.parse(raw));
    } catch {}
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (loaded) {
      try {
        localStorage.setItem(KEY, JSON.stringify(items));
      } catch {}
    }
  }, [items, loaded]);

  const value = useMemo<CartCtx>(() => {
    const count = items.reduce((a, b) => a + b.qty, 0);
    const subtotal = items.reduce((a, b) => a + (b.oldPrice && b.oldPrice > b.price ? b.oldPrice : b.price) * b.qty, 0);
    const total = items.reduce((a, b) => a + b.price * b.qty, 0);
    const discount = Math.max(0, subtotal - total);
    return {
      items,
      count,
      subtotal,
      discount,
      total,
      add: (item, qty = 1) => {
        setItems((prev) => {
          const ex = prev.find((p) => p.id === item.id);
          if (ex) return prev.map((p) => (p.id === item.id ? { ...p, qty: Math.min(999, p.qty + qty) } : p));
          return [...prev, { ...item, qty }];
        });
        setOpen(true);
      },
      remove: (id) => setItems((prev) => prev.filter((p) => p.id !== id)),
      setQty: (id, qty) => {
        if (qty <= 0) setItems((prev) => prev.filter((p) => p.id !== id));
        else setItems((prev) => prev.map((p) => (p.id === id ? { ...p, qty: Math.min(999, qty) } : p)));
      },
      clear: () => setItems([]),
      open,
      setOpen,
    };
  }, [items, open]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCart() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useCart must be used within CartProvider");
  return c;
}
