"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useCart } from "./CartProvider";
import { formatPrice } from "@/lib/utils";
import Logo from "./Logo";

export type ChromeSettings = {
  store_name: string;
  phone: string;
  whatsapp: string;
  manager: string;
};

const NAV = [
  { href: "/", label: "الرئيسية", icon: "🏠" },
  { href: "/categories", label: "الأقسام", icon: "▢" },
  { href: "/products", label: "المنتجات", icon: "▤" },
  { href: "/offers", label: "العروض", icon: "◈" },
  { href: "/about", label: "من نحن", icon: "ℹ" },
  { href: "/contact", label: "اتصل بنا", icon: "✆" },
];

function waIntlFrom(raw: string) {
  const d = (raw || "01147104601").replace(/[^0-9]/g, "");
  return d.startsWith("20") ? d : "20" + d.replace(/^0/, "");
}

export function Header({ s, categories }: { s: ChromeSettings; categories: Array<{ id: number; name: string; slug: string }> }) {
  const cart = useCart();
  const router = useRouter();
  const pathname = usePathname();
  const [q, setQ] = useState("");
  const [mobileMenu, setMobileMenu] = useState(false);
  const [me, setMe] = useState<{ name: string } | null>(null);

  useEffect(() => {
    fetch("/api/auth/me").then((r) => r.json()).then((j) => { if (j.ok && j.customer) setMe(j.customer); }).catch(() => {});
  }, [pathname]);

  const waIntl = waIntlFrom(s.whatsapp);

  return (
    <>
      {/* ── top utility bar ── */}
      <div className="bg-[#060b16] text-white">
        <div className="mx-auto flex max-w-[1320px] items-center gap-4 px-4 py-1.5 text-[12.5px]">
          <div className="flex items-center gap-2 text-white/70">
            <span>📞</span>
            <span dir="ltr" className="tracking-wide">{s.phone}</span>
            <span className="mx-2 h-3 w-px bg-white/20" />
            <span>🕘 يومياً 9 ص – 11 م</span>
          </div>
          <div className="ms-auto flex items-center gap-3">
            <Link href={me ? "/account" : "/login"} className="flex items-center gap-1.5 text-white/80 hover:text-[#e8c766]">
              <span>👤</span> {me ? "حسابي" : "تسجيل الدخول"}
            </Link>
            <span className="h-3 w-px bg-white/20" />
            <Link href="/register" className="flex items-center gap-1.5 text-white/80 hover:text-[#e8c766]">
              <span>✦</span> إنشاء حساب
            </Link>
          </div>
        </div>
      </div>

      {/* ── main header ── */}
      <header className="sticky top-0 z-40 border-b border-[#c9a227]/25 bg-gradient-to-l from-[#0b1526] via-[#0c1a30] to-[#0b1526] shadow-[0_10px_30px_rgba(6,11,22,0.35)]">
        <div className="mx-auto flex max-w-[1320px] items-center gap-4 px-4 py-3">
          {/* logo */}
          <Link href="/" className="flex shrink-0 items-center gap-3">
            <Logo size={54} />
            <div>
              <div className="text-[22px] font-black leading-6">
                <span className="gold-text">معرض</span> <span className="text-white">المصطفى</span>
              </div>
              <div className="text-[11px] font-semibold text-white/70">للأدوات الصحية والسباكة</div>
              <div className="text-[9.5px] text-[#e8c766]/80">إدارة / محمد محمود طلبة</div>
            </div>
          </Link>

          {/* desktop nav */}
          <nav className="hidden items-center gap-1 xl:flex">
            {NAV.map((n) => {
              const active = n.href === "/" ? pathname === "/" : pathname?.startsWith(n.href);
              return (
                <Link key={n.href} href={n.href} className="relative px-3 py-2 text-[15px] font-bold text-white/85 transition hover:text-[#e8c766]">
                  <span className="ms-1 text-[11px] opacity-60">{n.icon}</span>
                  {n.label}
                  {active && <span className="absolute inset-x-3 -bottom-[13px] h-[3px] rounded-full gold-bg" />}
                </Link>
              );
            })}
          </nav>

          {/* search */}
          <form
            onSubmit={(e) => { e.preventDefault(); router.push(`/search?q=${encodeURIComponent(q)}`); }}
            className="relative hidden min-w-[220px] flex-1 md:block"
          >
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="ابحث عن منتج: علامة تجارية، أو كود ..."
              className="w-full rounded-full border border-white/12 bg-white/[0.07] py-3 pe-4 ps-11 text-[13.5px] text-white placeholder:text-white/45 outline-none transition focus:border-[#c9a227] focus:bg-white/10"
            />
            <button type="submit" aria-label="بحث" className="absolute start-3 top-1/2 -translate-y-1/2 text-white/60 hover:text-[#e8c766]">🔍</button>
          </form>

          {/* cart */}
          <button onClick={() => cart.setOpen(true)} aria-label="السلة" className="relative shrink-0 rounded-2xl border border-white/12 bg-white/[0.06] px-3.5 py-2.5 text-xl transition hover:border-[#c9a227]">
            🛒
            {cart.count > 0 && (
              <span className="absolute -right-1.5 -top-1.5 flex h-[22px] min-w-[22px] items-center justify-center rounded-full bg-red-600 px-1 text-[11px] font-bold text-white shadow">
                {cart.count}
              </span>
            )}
          </button>

          <button onClick={() => setMobileMenu(!mobileMenu)} className="rounded-2xl border border-white/12 bg-white/[0.06] px-3 py-2.5 text-xl xl:hidden" aria-label="القائمة">
            ☰
          </button>
        </div>

        {/* mobile search */}
        <div className="px-4 pb-3 md:hidden">
          <form onSubmit={(e) => { e.preventDefault(); router.push(`/search?q=${encodeURIComponent(q)}`); }} className="relative">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="ابحث عن منتج: خلاط حوض، كود 12345 ..."
              className="w-full rounded-full border border-white/12 bg-white/[0.07] py-2.5 pe-4 ps-11 text-[13px] text-white placeholder:text-white/45 outline-none focus:border-[#c9a227]"
            />
            <button type="submit" aria-label="بحث" className="absolute start-3 top-1/2 -translate-y-1/2 text-white/60">🔍</button>
          </form>
        </div>

        {mobileMenu && (
          <div className="border-t border-white/10 bg-[#060b16] p-4 animate-fade-in xl:hidden">
            <div className="grid grid-cols-2 gap-2 text-sm font-bold">
              {NAV.map((n) => (
                <Link key={n.href} href={n.href} onClick={() => setMobileMenu(false)} className="rounded-xl bg-white/5 px-4 py-3 text-white/85">
                  {n.icon} {n.label}
                </Link>
              ))}
              <Link href="/cart" onClick={() => setMobileMenu(false)} className="rounded-xl bg-white/5 px-4 py-3 text-white/85">🛒 السلة</Link>
              <Link href={me ? "/account" : "/login"} onClick={() => setMobileMenu(false)} className="rounded-xl bg-[#c9a227]/15 px-4 py-3 text-[#e8c766]">👤 {me ? "حسابي" : "تسجيل الدخول"}</Link>
            </div>
            <div className="mt-3 text-xs text-white/50">الأقسام:</div>
            <div className="mt-2 flex flex-wrap gap-2">
              {categories.slice(0, 10).map((c) => (
                <Link key={c.id} href={`/categories/${c.slug}`} onClick={() => setMobileMenu(false)} className="rounded-full border border-white/15 px-3 py-1.5 text-xs text-white/80">
                  {c.name}
                </Link>
              ))}
            </div>
          </div>
        )}
      </header>
      <CartDrawer />
    </>
  );
}

function CartDrawer() {
  const cart = useCart();
  if (!cart.open) return null;
  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/65 backdrop-blur-sm" onClick={() => cart.setOpen(false)} />
      <aside className="absolute bottom-0 left-0 right-0 max-h-[92vh] overflow-hidden rounded-t-3xl bg-[#0b1526] shadow-2xl sm:bottom-0 sm:left-auto sm:right-0 sm:top-0 sm:h-full sm:w-[420px] sm:rounded-none animate-fade-up">
        <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
          <div className="flex items-center gap-2 font-black text-white">🛒 <span className="gold-text">السلة</span> ({cart.count})</div>
          <button onClick={() => cart.setOpen(false)} className="rounded-lg bg-white/10 px-3 py-1.5 font-bold text-white">✕</button>
        </div>
        <div className="max-h-[52vh] overflow-y-auto p-4 sm:max-h-[calc(100vh-280px)]">
          {cart.items.length === 0 ? (
            <div className="py-16 text-center">
              <div className="text-6xl">🛒</div>
              <div className="mt-4 font-bold text-white/80">سلتك فارغة</div>
              <div className="mt-1 text-sm text-white/45">تصفح المنتجات وأضف ما يعجبك</div>
              <Link href="/products" onClick={() => cart.setOpen(false)} className="mt-6 inline-block rounded-2xl gold-bg px-7 py-3 font-black text-[#0b1526]">تصفح المنتجات</Link>
            </div>
          ) : (
            <div className="space-y-3">
              {cart.items.map((it) => (
                <div key={it.id} className="flex gap-3 rounded-2xl border border-white/10 bg-white/[0.05] p-3">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={it.image || ""} alt={it.name} className="h-16 w-16 rounded-xl object-cover" />
                  <div className="min-w-0 flex-1">
                    <div className="line-clamp-1 text-sm font-bold text-white">{it.name}</div>
                    <div className="text-xs text-white/45" dir="ltr">{it.code}</div>
                    <div className="mt-1 flex items-center justify-between">
                      <div className="text-sm font-black text-[#e8c766]">{formatPrice(it.price)}</div>
                      <div className="flex items-center gap-2">
                        <button onClick={() => cart.setQty(it.id, it.qty - 1)} className="flex h-7 w-7 items-center justify-center rounded-lg bg-white/10 font-bold text-white">−</button>
                        <span className="min-w-6 text-center text-sm font-bold text-white">{it.qty}</span>
                        <button onClick={() => cart.setQty(it.id, it.qty + 1)} className="flex h-7 w-7 items-center justify-center rounded-lg gold-bg font-bold text-[#0b1526]">+</button>
                      </div>
                    </div>
                  </div>
                  <button onClick={() => cart.remove(it.id)} className="self-start text-red-400" aria-label="حذف">🗑</button>
                </div>
              ))}
            </div>
          )}
        </div>
        {cart.items.length > 0 && (
          <div className="border-t border-white/10 bg-[#0b1526] p-4">
            <div className="flex justify-between text-sm text-white/60"><span>المجموع الفرعي</span><span>{formatPrice(cart.subtotal)}</span></div>
            {cart.discount > 0 && <div className="flex justify-between text-sm text-emerald-400"><span>الخصم</span><span>− {formatPrice(cart.discount)}</span></div>}
            <div className="mt-1 flex justify-between text-lg font-black text-white"><span>الإجمالي</span><span className="gold-text">{formatPrice(cart.total)}</span></div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <Link href="/cart" onClick={() => cart.setOpen(false)} className="rounded-2xl border border-white/20 px-4 py-3 text-center font-bold text-white">عرض السلة</Link>
              <Link href="/checkout" onClick={() => cart.setOpen(false)} className="rounded-2xl gold-bg px-4 py-3 text-center font-black text-[#0b1526]">إتمام الطلب ←</Link>
            </div>
          </div>
        )}
      </aside>
    </div>
  );
}

export function Footer({ s }: { s: ChromeSettings }) {
  const waIntl = waIntlFrom(s.whatsapp);
  return (
    <footer className="mt-16 bg-[#060b16] text-white">
      <div className="mx-auto grid max-w-[1320px] gap-8 px-4 py-12 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-3">
            <Logo size={62} />
            <div>
              <div className="text-xl font-black"><span className="gold-text">معرض</span> المصطفي</div>
              <div className="text-[11px] text-white/60">للأدوات الصحية والسباكة</div>
            </div>
          </div>
          <p className="mt-4 text-sm leading-7 text-white/65">
            وجهتك الأولى للأدوات الصحية والسباكة — جودة أصلية، أسعار مميزة، وخدمة تليق بك.
          </p>
          <div className="mt-2 text-sm text-[#e8c766]">إدارة / محمد محمود طلبة</div>
        </div>
        <div>
          <div className="font-black text-[#e8c766]">روابط سريعة</div>
          <div className="mt-4 grid gap-2 text-sm text-white/65">
            {NAV.map((n) => <Link key={n.href} href={n.href} className="hover:text-white">{n.label}</Link>)}
          </div>
        </div>
        <div>
          <div className="font-black text-[#e8c766]">حسابي</div>
          <div className="mt-4 grid gap-2 text-sm text-white/65">
            <Link href="/login" className="hover:text-white">تسجيل الدخول</Link>
            <Link href="/register" className="hover:text-white">إنشاء حساب</Link>
            <Link href="/cart" className="hover:text-white">سلة التسوق</Link>
            <Link href="/account" className="hover:text-white">طلباتي</Link>
          </div>
        </div>
        <div>
          <div className="font-black text-[#e8c766]">تواصل معنا</div>
          <div className="mt-4 grid gap-2 text-sm text-white/65">
            <div>📞 {s.phone}</div>
            <div>📱 واتساب: {s.whatsapp}</div>
            <a href={`https://wa.me/${waIntl}`} target="_blank" rel="noopener noreferrer" className="mt-2 inline-block rounded-2xl bg-[#25D366] px-5 py-2.5 text-center font-bold text-white">💬 راسلنا واتساب</a>
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 py-4 text-center text-xs text-white/45">
        © {new Date().getFullYear()} {s.store_name} — جميع الحقوق محفوظة
      </div>
      <div className="h-16 md:hidden" />
    </footer>
  );
}

export function FloatingWhatsApp({ whatsapp, storeName }: { whatsapp: string; storeName: string }) {
  return (
    <a
      href={`https://wa.me/${waIntlFrom(whatsapp)}?text=${encodeURIComponent("السلام عليكم، أريد الاستفسار عن منتجات " + storeName)}`}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-20 left-4 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-2xl shadow-[0_10px_30px_rgba(37,211,102,0.45)] transition hover:scale-110 md:bottom-6 md:left-6"
      aria-label="واتساب"
    >
      💬
    </a>
  );
}

export function MobileNav() {
  const pathname = usePathname();
  const cart = useCart();
  const item = (href: string, icon: string, label: string) => (
    <Link
      key={href}
      href={href}
      className={`relative flex flex-1 flex-col items-center gap-0.5 rounded-xl px-2 py-2 text-[11px] font-bold ${pathname === href ? "text-[#e8c766]" : "text-white/65"}`}
    >
      <span className="text-xl">{icon}</span>
      {label}
      {href === "/cart" && cart.count > 0 && (
        <span className="absolute right-6 top-0 flex h-5 min-w-5 items-center justify-center rounded-full bg-red-600 px-1 text-[10px] text-white">{cart.count}</span>
      )}
    </Link>
  );
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-white/10 bg-[#060b16]/95 px-2 py-1 backdrop-blur-xl md:hidden">
      <div className="flex">
        {item("/", "🏠", "الرئيسية")}
        {item("/categories", "📦", "الأقسام")}
        {item("/search", "🔍", "البحث")}
        {item("/cart", "🛒", "السلة")}
        {item("/account", "👤", "حسابي")}
      </div>
    </nav>
  );
}
