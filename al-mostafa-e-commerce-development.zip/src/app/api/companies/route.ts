import { db } from "@/db";
import { companies, products } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { ok, serverError } from "@/lib/api-helpers";
import { ensureSeed } from "@/lib/seed";

export async function GET() {
  try {
    await ensureSeed();
    const comps = await db.select().from(companies).where(eq(companies.isActive, true));
    const counts = await db
      .select({ companyId: products.companyId, count: sql<number>`count(*)` })
      .from(products)
      .where(eq(products.isActive, true))
      .groupBy(products.companyId);
    const map = new Map<number | null, number>();
    for (const c of counts) map.set(c.companyId, Number(c.count));
    return ok({ companies: comps.map((c) => ({ ...c, productCount: map.get(c.id) ?? 0 })) });
  } catch (e) {
    return serverError(e);
  }
}
