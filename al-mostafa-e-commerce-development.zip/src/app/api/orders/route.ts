import { db } from "@/db";
import { orders, orderItems, products, customers, inventoryMovements } from "@/db/schema";
import { eq, desc, inArray } from "drizzle-orm";
import { fail, ok, serverError } from "@/lib/api-helpers";
import { getCustomerFromRequest } from "@/lib/auth";
import { generateOrderNumber, isValidPhone, sanitizeText } from "@/lib/utils";

export async function GET() {
  try {
    const c = await getCustomerFromRequest();
    if (!c) return fail("سجل الدخول أولاً", 401);
    const rows = await db.select().from(orders).where(eq(orders.customerId, c.id)).orderBy(desc(orders.id));
    return ok({ orders: rows });
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const c = await getCustomerFromRequest();
    const name = sanitizeText(body.name || c?.name, 200);
    const phone = sanitizeText(body.phone || c?.phone, 30);
    const address = sanitizeText(body.address, 1000);
    const notes = sanitizeText(body.notes, 2000);
    const items = Array.isArray(body.items) ? body.items : [];

    if (!name || name.length < 2) return fail("أدخل الاسم بالكامل");
    if (!isValidPhone(phone)) return fail("رقم الهاتف غير صالح");
    if (!address || address.length < 5) return fail("أدخل العنوان بالتفصيل");
    if (items.length === 0) return fail("السلة فارغة");
    if (items.length > 100) return fail("عدد الأصناف كبير جداً");

    const ids = items.map((i: { id: number }) => Number(i.id)).filter(Boolean);
    const dbProducts = await db.select().from(products).where(inArray(products.id, ids));
    const map = new Map(dbProducts.map((p) => [p.id, p]));

    let subtotal = 0;
    let discount = 0;
    const lines: Array<{ productId: number; productName: string; productCode: string; companyName: string; quantity: number; price: number; discount: number; total: number }> = [];

    for (const it of items) {
      const pid = Number(it.id);
      const qty = Math.min(999, Math.max(1, Number(it.qty) || 1));
      const p = map.get(pid);
      if (!p || !p.isActive) return fail(`المنتج غير متوفر: ${it.name || pid}`);
      if (p.stock < qty) return fail(`الكمية غير متوفرة: ${p.name} (المتاح ${p.stock})`);
      const base = Number(p.price) || 0;
      const discPrice = p.discountPrice ? Number(p.discountPrice) : 0;
      const oldP = p.oldPrice ? Number(p.oldPrice) : 0;
      let final = base;
      let lineOld = base;
      if (discPrice > 0 && discPrice < base) { final = discPrice; }
      else if (oldP > base) { lineOld = oldP; }
      const lineTotal = final * qty;
      const lineDisc = Math.max(0, (lineOld - final) * qty);
      subtotal += lineOld * qty;
      discount += lineDisc;
      lines.push({ productId: p.id, productName: p.name, productCode: p.code, companyName: p.companyName || "", quantity: qty, price: final, discount: lineDisc, total: lineTotal });
    }

    const total = subtotal - discount;
    const orderNumber = generateOrderNumber();

    const inserted = await db
      .insert(orders)
      .values({
        orderNumber,
        customerId: c?.id ?? null,
        customerName: name,
        customerPhone: phone,
        customerAddress: address,
        notes: notes || null,
        subtotal: String(subtotal),
        discount: String(discount),
        total: String(total),
        status: "new",
        source: "website",
      })
      .returning();

    const order = inserted[0];

    for (const l of lines) {
      await db.insert(orderItems).values({
        orderId: order.id,
        productId: l.productId,
        productName: l.productName,
        productCode: l.productCode,
        companyName: l.companyName,
        quantity: l.quantity,
        price: String(l.price),
        discount: String(l.discount),
        total: String(l.total),
      });
      const p = map.get(l.productId)!;
      const newStock = Math.max(0, p.stock - l.quantity);
      await db.update(products).set({ stock: newStock, soldCount: p.soldCount + l.quantity, updatedAt: new Date() }).where(eq(products.id, p.id));
      await db.insert(inventoryMovements).values({
        productId: p.id,
        productName: p.name,
        type: "out",
        quantity: l.quantity,
        previousStock: p.stock,
        newStock,
        reason: `طلب ${orderNumber}`,
        referenceId: orderNumber,
      });
    }

    // update customer stats
    if (c) {
      const cust = await db.select().from(customers).where(eq(customers.id, c.id)).limit(1);
      if (cust[0]) {
        await db.update(customers).set({
          totalOrders: (cust[0].totalOrders || 0) + 1,
          totalSpent: String(Number(cust[0].totalSpent || 0) + total),
          lastOrderAt: new Date(),
          address: address || cust[0].address,
        }).where(eq(customers.id, c.id));
      }
    }

    return ok({ order, items: lines });
  } catch (e) {
    return serverError(e, "تعذر إنشاء الطلب، حاول مرة أخرى");
  }
}
