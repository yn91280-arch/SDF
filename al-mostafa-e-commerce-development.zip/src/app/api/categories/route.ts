import { db } from "@/db";
import { categories, products } from "@/db/schema";
import { eq, sql, asc } from "drizzle-orm";
import { ok, serverError } from "@/lib/api-helpers";
import { ensureSeed } from "@/lib/seed";

export async function GET() {
  try {
    await ensureSeed();
    const cats = await db.select().from(categories).where(eq(categories.isActive, true)).orderBy(asc(categories.sortOrder));
    // product counts
    const counts = await db
      .select({ categoryId: products.categoryId, count: sql<number>`count(*)` })
      .from(products)
      .where(eq(products.isActive, true))
      .groupBy(products.categoryId);
    const map = new Map<number | null, number>();
    for (const c of counts) map.set(c.categoryId, Number(c.count));
    return ok({
      categories: cats.map((c) => ({ ...c, productCount: map.get(c.id) ?? 0 })),
    });
  } catch (e) {
    return serverError(e);
  }
}
