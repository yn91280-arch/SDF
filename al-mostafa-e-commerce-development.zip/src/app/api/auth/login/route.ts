import { db } from "@/db";
import { customers } from "@/db/schema";
import { eq, or, sql, ilike } from "drizzle-orm";
import { fail, ok, serverError } from "@/lib/api-helpers";
import { verifyPassword, signCustomerJWT, CUSTOMER_COOKIE, checkRateLimit, recordLoginAttempt } from "@/lib/auth";
import { sanitizeText } from "@/lib/utils";
import { ensureSeed } from "@/lib/seed";

export async function POST(req: Request) {
  try {
    await ensureSeed();
    const body = await req.json();
    const raw = sanitizeText(body.identifier || body.email || body.phone, 255);
    const password = String(body.password || "");
    if (!raw || !password) return fail("أدخل رقم الهاتف أو اسم المستخدم وكلمة المرور");

    const digits = raw.replace(/[^0-9]/g, "");
    const key = raw.toLowerCase();

    const { allowed, remaining } = await checkRateLimit("cust:" + key);
    if (!allowed) return fail("محاولات كثيرة — تم إيقاف الدخول مؤقتاً لمدة 15 دقيقة", 429);

    const rows = await db
      .select()
      .from(customers)
      .where(
        or(
          ilike(customers.email, key),
          eq(customers.phone, raw),
          digits.length >= 8 ? eq(customers.phone, digits) : sql`FALSE`,
          eq(customers.name, raw)
        )
      )
      .limit(5);
    const c = rows[0];
    if (!c || !c.passwordHash || !c.isActive) {
      await recordLoginAttempt("cust:" + key, false);
      return fail(`بيانات الدخول غير صحيحة (المحاولات المتبقية: ${Math.max(0, remaining - 1)})`, 401);
    }
    const valid = await verifyPassword(password, c.passwordHash);
    if (!valid) {
      await recordLoginAttempt("cust:" + key, false);
      return fail(`بيانات الدخول غير صحيحة (المحاولات المتبقية: ${Math.max(0, remaining - 1)})`, 401);
    }
    await recordLoginAttempt("cust:" + key, true);
    const remember = body.remember === true || body.remember === "true" || body.remember === "on";
    const token = await signCustomerJWT({ customerId: c.id });
    const res = ok({ customer: { id: c.id, name: c.name, phone: c.phone, email: c.email } });
    res.cookies.set(CUSTOMER_COOKIE, token, {
      httpOnly: true, sameSite: "lax", path: "/",
      maxAge: remember ? 30 * 24 * 3600 : 24 * 3600,
      secure: process.env.NODE_ENV === "production",
    });
    return res;
  } catch (e) {
    return serverError(e);
  }
}
