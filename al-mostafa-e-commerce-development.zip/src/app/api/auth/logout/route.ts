import { ok } from "@/lib/api-helpers";
import { CUSTOMER_COOKIE } from "@/lib/auth";

export async function POST() {
  const res = ok({});
  res.cookies.set(CUSTOMER_COOKIE, "", { path: "/", maxAge: 0 });
  return res;
}
