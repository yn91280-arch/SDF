import { db } from "@/db";
import { customers } from "@/db/schema";
import { eq, or } from "drizzle-orm";
import { fail, ok, serverError } from "@/lib/api-helpers";
import { hashPassword, signCustomerJWT, CUSTOMER_COOKIE } from "@/lib/auth";
import { isValidEmail, isValidPhone, sanitizeText, isStrongPassword } from "@/lib/utils";
import { ensureSeed } from "@/lib/seed";

export async function POST(req: Request) {
  try {
    await ensureSeed();
    const body = await req.json();
    const name = sanitizeText(body.name, 200);
    const phone = sanitizeText(body.phone, 30);
    const email = sanitizeText(body.email, 255).toLowerCase();
    const password = String(body.password || "");
    const confirm = String(body.confirm || body.confirmPassword || "");

    if (!name || name.length < 2) return fail("من فضلك أدخل الاسم بالكامل");
    if (!isValidPhone(phone)) return fail("رقم الهاتف غير صالح");
    if (email && !isValidEmail(email)) return fail("البريد الإلكتروني غير صالح");
    if (!isStrongPassword(password))
      return fail("كلمة المرور يجب أن تكون 8 أحرف على الأقل وتضم حروفاً وأرقاماً");
    if (password !== confirm) return fail("تأكيد كلمة المرور غير متطابق");

    const existing = await db
      .select()
      .from(customers)
      .where(email ? or(eq(customers.phone, phone), eq(customers.email, email)) : eq(customers.phone, phone))
      .limit(1);
    if (existing.length > 0) return fail("يوجد حساب مسجل بهذا الرقم أو البريد بالفعل");

    const hash = await hashPassword(password);
    const inserted = await db
      .insert(customers)
      .values({ name, phone, email: email || null, passwordHash: hash, address: sanitizeText(body.address, 500) || null })
      .returning({ id: customers.id, name: customers.name, phone: customers.phone, email: customers.email });

    const customer = inserted[0];
    const token = await signCustomerJWT({ customerId: customer.id });
    const res = ok({ customer });
    res.cookies.set(CUSTOMER_COOKIE, token, { httpOnly: true, sameSite: "lax", path: "/", maxAge: 30 * 24 * 3600, secure: process.env.NODE_ENV === "production" });
    return res;
  } catch (e) {
    return serverError(e, "تعذر إنشاء الحساب، حاول مرة أخرى");
  }
}
