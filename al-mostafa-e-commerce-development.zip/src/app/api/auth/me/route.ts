import { getCustomerFromRequest } from "@/lib/auth";
import { ok } from "@/lib/api-helpers";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  const c = await getCustomerFromRequest();
  if (!c) return ok({ customer: null });
  const myOrders = await db.select().from(orders).where(eq(orders.customerId, c.id)).orderBy(desc(orders.id)).limit(20);
  return ok({ customer: c, orders: myOrders });
}
