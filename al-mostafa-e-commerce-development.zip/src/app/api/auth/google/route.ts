import { db } from "@/db";
import { customers } from "@/db/schema";
import { eq } from "drizzle-orm";
import { fail, ok, serverError } from "@/lib/api-helpers";
import { signCustomerJWT, CUSTOMER_COOKIE } from "@/lib/auth";
import { sanitizeText } from "@/lib/utils";
import { ensureSeed } from "@/lib/seed";

/**
 * Google Sign-In (ID token flow).
 * Only active when GOOGLE_CLIENT_ID / NEXT_PUBLIC_GOOGLE_CLIENT_ID are configured.
 * The ID token is verified against Google's tokeninfo endpoint — no secret in the client.
 */
export async function POST(req: Request) {
  try {
    await ensureSeed();
    const clientId = process.env.GOOGLE_CLIENT_ID || process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID;
    if (!clientId) return fail("تسجيل الدخول بجوجل غير مفعّل على هذا الموقع", 404);

    const body = await req.json();
    const idToken = String(body.idToken || "");
    if (!idToken) return fail("لم يتم استلام بيانات جوجل");

    const verify = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(idToken)}`);
    if (!verify.ok) return fail("تعذر التحقق من حساب جوجل", 401);
    const info = (await verify.json()) as { aud?: string; email?: string; name?: string; sub?: string };
    if (!info || info.aud !== clientId || !info.email) return fail("بيانات جوجل غير صالحة", 401);

    const email = sanitizeText(info.email, 255).toLowerCase();
    const name = sanitizeText(info.name || email.split("@")[0], 200);
    let rows = await db.select().from(customers).where(eq(customers.email, email)).limit(1);
    if (rows.length === 0) {
      rows = await db
        .insert(customers)
        .values({ name, email, phone: "—", passwordHash: null, isActive: true })
        .returning();
    }
    const c = rows[0];
    const token = await signCustomerJWT({ customerId: c.id });
    const res = ok({ customer: { id: c.id, name: c.name, phone: c.phone, email: c.email } });
    res.cookies.set(CUSTOMER_COOKIE, token, {
      httpOnly: true, sameSite: "lax", path: "/",
      maxAge: 30 * 24 * 3600,
      secure: process.env.NODE_ENV === "production",
    });
    return res;
  } catch (e) {
    return serverError(e, "تعذر تسجيل الدخول بجوجل");
  }
}
