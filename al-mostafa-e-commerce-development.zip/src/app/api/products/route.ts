import { db } from "@/db";
import { products, categories, companies } from "@/db/schema";
import { eq, and, or, ilike, sql, desc } from "drizzle-orm";
import { ok, serverError, parsePagination } from "@/lib/api-helpers";
import { ensureSeed } from "@/lib/seed";

export async function GET(req: Request) {
  try {
    await ensureSeed();
    const url = new URL(req.url);
    const { page, limit, offset } = parsePagination(url);
    const q = (url.searchParams.get("q") || "").trim();
    const category = url.searchParams.get("category") || "";
    const company = url.searchParams.get("company") || "";
    const offer = url.searchParams.get("offer") || "";
    const featured = url.searchParams.get("featured") || "";
    const sort = url.searchParams.get("sort") || "new";
    const minPrice = url.searchParams.get("minPrice");
    const maxPrice = url.searchParams.get("maxPrice");

    const conds: ReturnType<typeof eq>[] = [eq(products.isActive, true) as never];

    if (q) {
      // Smart multi-token search across name/code/model/company/brand/category/size/color/keywords
      const tokens = q.split(/\s+/).filter((t) => t.length > 0).slice(0, 6);
      for (const tok of tokens) {
        const like = `%${tok}%`;
        conds.push(
          or(
            ilike(products.name, like),
            ilike(products.code, like),
            ilike(products.model, like),
            ilike(products.companyName, like),
            ilike(products.brand, like),
            ilike(products.size, like),
            ilike(products.color, like),
            ilike(products.keywords, like),
            ilike(products.searchText, like)
          ) as never
        );
      }
    }
    if (category) {
      // category may be slug or id
      if (/^\d+$/.test(category)) {
        conds.push(eq(products.categoryId, Number(category)) as never);
      } else {
        const cat = await db.select().from(categories).where(eq(categories.slug, category)).limit(1);
        if (cat[0]) conds.push(eq(products.categoryId, cat[0].id) as never);
        else conds.push(sql`1=0` as never);
      }
    }
    if (company) {
      if (/^\d+$/.test(company)) {
        conds.push(eq(products.companyId, Number(company)) as never);
      } else {
        const comp = await db.select().from(companies).where(eq(companies.slug, company)).limit(1);
        if (comp[0]) conds.push(eq(products.companyId, comp[0].id) as never);
        else conds.push(or(ilike(products.companyName, `%${company}%`), ilike(products.brand, `%${company}%`)) as never);
      }
    }
    if (offer === "1" || offer === "true") conds.push(eq(products.isOffer, true) as never);
    if (featured === "1" || featured === "true") conds.push(eq(products.isFeatured, true) as never);
    if (minPrice) conds.push(sql`${products.price} >= ${Number(minPrice)}` as never);
    if (maxPrice) conds.push(sql`${products.price} <= ${Number(maxPrice)}` as never);

    const where = and(...conds);

    const orderBy =
      sort === "price_asc"
        ? sql`${products.price} ASC`
        : sort === "price_desc"
          ? sql`${products.price} DESC`
          : sort === "popular"
            ? desc(products.soldCount)
            : desc(products.id);

    const rows = await db.select().from(products).where(where).orderBy(orderBy).limit(limit).offset(offset);
    const totalRes = await db.select({ c: sql<number>`count(*)` }).from(products).where(where);
    const total = Number(totalRes[0]?.c || 0);

    return ok({ products: rows, pagination: { page, limit, total, pages: Math.ceil(total / limit) } });
  } catch (e) {
    return serverError(e);
  }
}
