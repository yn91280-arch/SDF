import { db } from "@/db";
import { products } from "@/db/schema";
import { eq, and, ne, sql } from "drizzle-orm";
import { ok, fail, serverError } from "@/lib/api-helpers";
import { ensureSeed } from "@/lib/seed";

export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    await ensureSeed();
    const { id } = await params;
    const pid = Number(id);
    if (!pid) return fail("منتج غير صالح", 404);
    const rows = await db.select().from(products).where(eq(products.id, pid)).limit(1);
    const p = rows[0];
    if (!p || !p.isActive) return fail("المنتج غير موجود", 404);
    // increment views
    await db.update(products).set({ views: sql`${products.views} + 1` }).where(eq(products.id, pid));
    // related
    const related = p.categoryId
      ? await db.select().from(products).where(and(eq(products.isActive, true), eq(products.categoryId, p.categoryId), ne(products.id, pid))).limit(8)
      : [];
    return ok({ product: p, related });
  } catch (e) {
    return serverError(e);
  }
}
