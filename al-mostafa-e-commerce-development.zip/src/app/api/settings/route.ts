import { getSettings } from "@/lib/site-settings";
import { ensureSeed } from "@/lib/seed";
import { ok, serverError } from "@/lib/api-helpers";

export async function GET() {
  try {
    await ensureSeed();
    const s = await getSettings();
    // Only expose public-safe settings
    return ok({
      settings: {
        site_url: s.site_url,
        store_name: s.store_name,
        store_name_en: s.store_name_en,
        store_desc: s.store_desc,
        manager: s.manager,
        phone: s.phone,
        whatsapp: s.whatsapp,
        address: s.address,
        maps_url: s.maps_url,
        working_hours: s.working_hours,
        facebook: s.facebook,
        instagram: s.instagram,
        tiktok: s.tiktok,
        youtube: s.youtube,
        currency: s.currency,
        hero_title: s.hero_title,
        hero_subtitle: s.hero_subtitle,
      },
    });
  } catch (e) {
    return serverError(e);
  }
}
