import { db } from "@/db";
import { offers } from "@/db/schema";
import { eq, asc } from "drizzle-orm";
import { ok, serverError } from "@/lib/api-helpers";
import { ensureSeed } from "@/lib/seed";

export async function GET() {
  try {
    await ensureSeed();
    const rows = await db.select().from(offers).where(eq(offers.isActive, true)).orderBy(asc(offers.sortOrder));
    return ok({ offers: rows });
  } catch (e) {
    return serverError(e);
  }
}
