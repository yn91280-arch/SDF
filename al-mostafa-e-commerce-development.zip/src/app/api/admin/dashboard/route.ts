import { db } from "@/db";
import { orders, products, customers, orderItems } from "@/db/schema";
import { eq, sql, desc, gte, lte } from "drizzle-orm";
import { fail, ok, serverError } from "@/lib/api-helpers";
import { getAdminFromRequest } from "@/lib/auth";
import { ensureSeed } from "@/lib/seed";

export async function GET() {
  try {
    await ensureSeed();
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);

    const now = new Date();
    const startOfDay = new Date(now); startOfDay.setHours(0, 0, 0, 0);
    const startOfWeek = new Date(now); startOfWeek.setDate(now.getDate() - 7);
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    const sum = (rows: Array<{ s: string | null }>) => Number(rows[0]?.s || 0);

    const [totalSalesR, todayR, weekR, monthR, ordersCount, customersCount, productsCount, lowStockR] = await Promise.all([
      db.select({ s: sql<string>`COALESCE(SUM(${orders.total}),0)` }).from(orders).where(lte(orders.status, "zzzz")),
      db.select({ s: sql<string>`COALESCE(SUM(${orders.total}),0)` }).from(orders).where(gte(orders.createdAt, startOfDay)),
      db.select({ s: sql<string>`COALESCE(SUM(${orders.total}),0)` }).from(orders).where(gte(orders.createdAt, startOfWeek)),
      db.select({ s: sql<string>`COALESCE(SUM(${orders.total}),0)` }).from(orders).where(gte(orders.createdAt, startOfMonth)),
      db.select({ c: sql<number>`count(*)` }).from(orders),
      db.select({ c: sql<number>`count(*)` }).from(customers),
      db.select({ c: sql<number>`count(*)` }).from(products),
      db.select().from(products).where(sql`${products.stock} <= ${products.minStock}`).limit(20),
    ]);

    // exclude cancelled from sales
    const [activeSalesR] = await Promise.all([
      db.select({ s: sql<string>`COALESCE(SUM(${orders.total}),0)` }).from(orders).where(sql`${orders.status} != 'cancelled'`),
    ]);

    const recentOrders = await db.select().from(orders).orderBy(desc(orders.id)).limit(8);
    const bestSelling = await db.select().from(products).orderBy(desc(products.soldCount)).limit(6);
    const latestProducts = await db.select().from(products).orderBy(desc(products.id)).limit(6);

    // last 7 days chart
    const daily: Array<{ day: string; total: number }> = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(now.getDate() - i);
      d.setHours(0, 0, 0, 0);
      const d2 = new Date(d);
      d2.setDate(d.getDate() + 1);
      const r = await db.select({ s: sql<string>`COALESCE(SUM(${orders.total}),0)` }).from(orders).where(sql`${orders.createdAt} >= ${d} AND ${orders.createdAt} < ${d2} AND ${orders.status} != 'cancelled'`);
      daily.push({ day: d.toLocaleDateString("ar-EG", { weekday: "short" }), total: Number(r[0]?.s || 0) });
    }

    const ordersByStatus = await db.select({ status: orders.status, c: sql<number>`count(*)` }).from(orders).groupBy(orders.status);

    return ok({
      stats: {
        totalSales: sum(activeSalesR),
        totalSalesAll: sum(totalSalesR),
        todaySales: sum(todayR),
        weekSales: sum(weekR),
        monthSales: sum(monthR),
        orders: Number(ordersCount[0]?.c || 0),
        customers: Number(customersCount[0]?.c || 0),
        products: Number(productsCount[0]?.c || 0),
        lowStock: lowStockR.length,
      },
      recentOrders,
      bestSelling,
      latestProducts,
      lowStock: lowStockR,
      daily,
      ordersByStatus,
    });
  } catch (e) {
    return serverError(e);
  }
}
