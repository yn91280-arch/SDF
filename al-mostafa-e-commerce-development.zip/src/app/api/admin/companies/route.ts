import { db } from "@/db";
import { companies, products } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { fail, ok, serverError } from "@/lib/api-helpers";
import { getAdminFromRequest } from "@/lib/auth";
import { sanitizeText, slugify } from "@/lib/utils";

export async function GET() {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const comps = await db.select().from(companies);
    const counts = await db.select({ companyId: products.companyId, count: sql<number>`count(*)` }).from(products).groupBy(products.companyId);
    const map = new Map<number | null, number>();
    for (const c of counts) map.set(c.companyId, Number(c.count));
    return ok({ companies: comps.map((c) => ({ ...c, productCount: map.get(c.id) ?? 0 })) });
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const b = await req.json();
    const name = sanitizeText(b.name, 200);
    if (!name) return fail("أدخل اسم الشركة");
    let slug = sanitizeText(b.slug, 200) || slugify(name);
    const ex = await db.select().from(companies).where(eq(companies.slug, slug)).limit(1);
    if (ex.length > 0) slug = `${slug}-${Date.now().toString().slice(-4)}`;
    const inserted = await db.insert(companies).values({
      name, slug,
      logo: b.logo || null,
      description: sanitizeText(b.description, 2000) || null,
      contactPhone: sanitizeText(b.contactPhone, 50) || null,
      contactEmail: sanitizeText(b.contactEmail, 255) || null,
      isActive: b.isActive !== false,
    }).returning();
    return ok({ company: inserted[0] });
  } catch (e) {
    return serverError(e);
  }
}

export async function PUT(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const b = await req.json();
    const id = Number(b.id);
    if (!id) return fail("شركة غير صالحة");
    await db.update(companies).set({
      name: b.name !== undefined ? sanitizeText(b.name, 200) : undefined,
      logo: b.logo !== undefined ? b.logo : undefined,
      description: b.description !== undefined ? sanitizeText(b.description, 2000) : undefined,
      contactPhone: b.contactPhone !== undefined ? sanitizeText(b.contactPhone, 50) : undefined,
      contactEmail: b.contactEmail !== undefined ? sanitizeText(b.contactEmail, 255) : undefined,
      isActive: b.isActive !== undefined ? !!b.isActive : undefined,
      updatedAt: new Date(),
    }).where(eq(companies.id, id));
    return ok({});
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const url = new URL(req.url);
    const id = Number(url.searchParams.get("id"));
    if (!id) return fail("شركة غير صالحة");
    await db.update(products).set({ companyId: null }).where(eq(products.companyId, id));
    await db.delete(companies).where(eq(companies.id, id));
    return ok({});
  } catch (e) {
    return serverError(e);
  }
}
