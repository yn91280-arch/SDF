import { db } from "@/db";
import { priceLists, priceListItems, products, companies, inventoryMovements } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { fail, ok, serverError } from "@/lib/api-helpers";
import { getAdminFromRequest } from "@/lib/auth";
import { sanitizeText } from "@/lib/utils";

export async function GET(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const url = new URL(req.url);
    const id = Number(url.searchParams.get("id"));
    if (!id) return fail("قائمة غير صالحة");
    const lists = await db.select().from(priceLists).where(eq(priceLists.id, id)).limit(1);
    if (!lists[0]) return fail("القائمة غير موجودة", 404);
    const items = await db.select().from(priceListItems).where(eq(priceListItems.priceListId, id)).limit(2000);
    return ok({ list: lists[0], items });
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const b = await req.json();
    const listId = Number(b.listId);
    const mode = String(b.mode || "selected"); // selected | new | existing | all
    const selectedIds: number[] = Array.isArray(b.selectedIds) ? b.selectedIds.map(Number).filter(Boolean) : [];
    const updatePrices = b.updatePrices !== false;
    const createNew = b.createNew !== false;
    const confirmMajor = b.confirmMajor === true;

    if (!listId) return fail("قائمة غير صالحة");
    const lists = await db.select().from(priceLists).where(eq(priceLists.id, listId)).limit(1);
    const list = lists[0];
    if (!list) return fail("القائمة غير موجودة", 404);
    if (list.status === "applied") return fail("تم تطبيق هذه القائمة من قبل");

    let items = await db.select().from(priceListItems).where(and(eq(priceListItems.priceListId, listId), eq(priceListItems.isApplied, false)));
    if (mode === "selected" && selectedIds.length > 0) items = items.filter((i) => selectedIds.includes(i.id));
    if (mode === "new") items = items.filter((i) => i.matchStatus === "new");
    if (mode === "existing") items = items.filter((i) => i.matchStatus === "existing");

    if (items.length === 0) return fail("لا توجد أصناف للتطبيق");
    if (items.length > 300 && !confirmMajor) {
      return fail(`تحذير: سيتم تطبيق ${items.length} صنف — أكّد العملية أولاً`, 400, { requireConfirm: true, count: items.length });
    }

    let created = 0, updated = 0;
    for (const it of items) {
      if (it.matchedProductId && updatePrices && (it.matchStatus === "existing" || it.matchStatus === "review")) {
        const rows = await db.select().from(products).where(eq(products.id, it.matchedProductId)).limit(1);
        const p = rows[0];
        if (p) {
          const newPrice = Number(it.price) || 0;
          if (newPrice > 0) {
            // keep old price as previous for discount display
            await db.update(products).set({
              price: String(newPrice),
              oldPrice: p.price !== String(newPrice) ? String(p.price) : p.oldPrice,
              model: it.model || p.model,
              size: it.size || p.size,
              color: it.color || p.color,
              searchText: `${p.name} ${p.code} ${it.model || p.model || ""} ${p.companyName} ${p.brand || ""} ${it.size || p.size || ""} ${it.color || p.color || ""} ${p.keywords || ""}`.toLowerCase(),
              updatedAt: new Date(),
            }).where(eq(products.id, p.id));
            updated++;
            await db.update(priceListItems).set({ isApplied: true }).where(eq(priceListItems.id, it.id));
          }
        }
      } else if (!it.matchedProductId && createNew && (it.matchStatus === "new" || it.matchStatus === "review")) {
        const name = sanitizeText(it.name, 300) || `صنف ${it.code}`;
        let code = sanitizeText(it.code, 100);
        if (!code) code = `IMP-${listId}-${it.id}`;
        const ex = await db.select().from(products).where(eq(products.code, code)).limit(1);
        if (ex.length > 0) continue;
        let companyId = list.companyId;
        if (!companyId && it.companyName) {
          const comp = await db.select().from(companies).where(eq(companies.name, it.companyName)).limit(1);
          if (comp[0]) companyId = comp[0].id;
        }
        const searchText = `${name} ${code} ${it.model || ""} ${it.companyName || ""} ${it.size || ""} ${it.color || ""}`.toLowerCase();
        const inserted = await db.insert(products).values({
          name, code,
          model: it.model,
          companyId,
          companyName: it.companyName || list.companyName,
          price: String(Number(it.price) || 0),
          stock: 0, minStock: 5,
          size: it.size, color: it.color,
          images: [],
          searchText,
          isActive: true,
        }).returning();
        await db.insert(inventoryMovements).values({
          productId: inserted[0].id, productName: name, type: "in", quantity: 0,
          previousStock: 0, newStock: 0, reason: `استيراد قائمة ${list.fileName}`, createdBy: a.id,
        });
        created++;
        await db.update(priceListItems).set({ isApplied: true }).where(eq(priceListItems.id, it.id));
      }
    }

    // update company last price update
    if (list.companyId) {
      await db.update(companies).set({ lastPriceUpdate: new Date() }).where(eq(companies.id, list.companyId));
    }
    const remaining = await db.select().from(priceListItems).where(and(eq(priceListItems.priceListId, listId), eq(priceListItems.isApplied, false)));
    await db.update(priceLists).set({ status: remaining.length === 0 ? "applied" : "partial" }).where(eq(priceLists.id, listId));

    return ok({ created, updated, remaining: remaining.length });
  } catch (e) {
    return serverError(e);
  }
}
