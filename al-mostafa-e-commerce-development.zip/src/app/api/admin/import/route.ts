import { db } from "@/db";
import { priceLists, priceListItems, products, companies } from "@/db/schema";
import { eq, desc, ilike, sql } from "drizzle-orm";
import { fail, ok, serverError } from "@/lib/api-helpers";
import { getAdminFromRequest } from "@/lib/auth";
import { sanitizeText } from "@/lib/utils";
import * as XLSX from "xlsx";

export async function GET() {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const lists = await db.select().from(priceLists).orderBy(desc(priceLists.id)).limit(20);
    return ok({ lists });
  } catch (e) {
    return serverError(e);
  }
}

// Parse uploaded file -> preview
export async function POST(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const form = await req.formData();
    const file = form.get("file") as File | null;
    const companyId = form.get("companyId") ? Number(form.get("companyId")) : null;
    const companyNameInput = sanitizeText(form.get("companyName"), 200);
    if (!file) return fail("اختر ملفاً أولاً");
    const allowed = [".xlsx", ".xls", ".csv", ".txt"];
    const lower = file.name.toLowerCase();
    const isPdf = lower.endsWith(".pdf");
    const isImage = /\.(png|jpe?g|webp)$/i.test(lower);
    if (isPdf) return fail("ملفات PDF تحتاج مراجعة يدوية — حوّلها إلى Excel/CSV ثم ارفعها (دعم الاستخراج التلقائي من PDF قريباً)");
    if (isImage) return fail("الصور تحتاج مراجعة يدوية — حوّل قائمة الأسعار إلى Excel/CSV ثم ارفعها");
    if (!allowed.some((e) => lower.endsWith(e))) return fail("صيغة غير مدعومة — المدعوم: Excel / CSV");
    if (file.size > 10 * 1024 * 1024) return fail("حجم الملف كبير (الحد 10MB)");

    const buf = Buffer.from(await file.arrayBuffer());
    // CSV/TXT: decode as UTF-8 ourselves so Arabic headers are read correctly
    let wb: XLSX.WorkBook;
    if (lower.endsWith(".csv") || lower.endsWith(".txt")) {
      let text = buf.toString("utf8").replace(/^\uFEFF/, "");
      if (/[\u00c0-\u00ff]{2,}/.test(text)) text = Buffer.from(text, "latin1").toString("utf8");
      wb = XLSX.read(text, { type: "string" });
    } else {
      wb = XLSX.read(buf, { type: "buffer" });
    }
    const sheet = wb.Sheets[wb.SheetNames[0]];
    const rows: unknown[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: true });

    if (rows.length < 2) return fail("الملف فارغ أو بدون بيانات");

    // detect header row (first row with >=2 non-empty cells)
    let headerIdx = 0;
    for (let i = 0; i < Math.min(5, rows.length); i++) {
      const nonEmpty = (rows[i] as unknown[]).filter((c) => c !== null && c !== undefined && String(c).trim() !== "").length;
      if (nonEmpty >= 2) { headerIdx = i; break; }
    }
    const headers = (rows[headerIdx] as unknown[]).map((h) => String(h ?? "").trim());

    const findCol = (...names: string[]) => {
      for (let i = 0; i < headers.length; i++) {
        const h = headers[i].toLowerCase().replace(/\s+/g, "");
        for (const n of names) {
          if (h.includes(n.toLowerCase().replace(/\s+/g, ""))) return i;
        }
      }
      return -1;
    };

    const cName = findCol("name", "product", "الاسم", "المنتج", "الصنف", "item", "description");
    const cCode = findCol("code", "الكود", "كود", "sku", "باركود", "رقم");
    const cModel = findCol("model", "الموديل", "موديل");
    const cSize = findCol("size", "المقاس", "مقاس", "الحجم");
    const cColor = findCol("color", "اللون", "لون");
    const cPrice = findCol("price", "السعر", "سعر", "قيمة");
    const cCompany = findCol("company", "الشركة", "شركة", "brand", "الماركة");

    if (cName === -1 && cCode === -1) return fail("تعذر التعرف على الأعمدة — تأكد أن الملف يحتوي على عمود الاسم أو الكود");
    if (cPrice === -1) return fail("تعذر العثور على عمود السعر");

    let companyName = companyNameInput;
    if (companyId) {
      const comp = await db.select().from(companies).where(eq(companies.id, companyId)).limit(1);
      if (comp[0]) companyName = comp[0].name;
    }

    type Parsed = { name: string; code: string; model: string; size: string; color: string; price: number; companyName: string; raw: Record<string, unknown> };
    const parsed: Parsed[] = [];
    for (let r = headerIdx + 1; r < rows.length && parsed.length < 2000; r++) {
      const row = rows[r] as unknown[];
      if (!row || row.every((c) => c === null || c === undefined || String(c).trim() === "")) continue;
      const get = (idx: number) => (idx >= 0 && row[idx] !== undefined && row[idx] !== null ? String(row[idx]).trim() : "");
      const priceRaw = get(cPrice).replace(/[^0-9.]/g, "");
      const price = parseFloat(priceRaw) || 0;
      const name = get(cName) || "";
      const code = get(cCode) || "";
      if (!name && !code) continue;
      parsed.push({
        name: name || code,
        code,
        model: get(cModel),
        size: get(cSize),
        color: get(cColor),
        price,
        companyName: get(cCompany) || companyName,
        raw: Object.fromEntries(headers.map((h, i) => [h || `col${i}`, row[i]])),
      });
    }

    if (parsed.length === 0) return fail("لم يتم استخراج أي أصناف من الملف");

    // Match against DB
    let newCount = 0, existingCount = 0, reviewCount = 0;
    const items: Array<Parsed & { matchStatus: string; matchedProductId: number | null; matchedName?: string; matchedPrice?: string }> = [];
    for (const p of parsed) {
      let matched = null;
      if (p.code) {
        const r = await db.select().from(products).where(eq(products.code, p.code)).limit(1);
        if (r[0]) matched = r[0];
      }
      if (!matched && p.name) {
        const r = await db.select().from(products).where(ilike(products.name, p.name)).limit(1);
        if (r[0]) matched = r[0];
      }
      if (matched) {
        // confident match? price differs a lot or name differs -> review
        const priceDiff = matched.price ? Math.abs(Number(matched.price) - p.price) / Math.max(1, Number(matched.price)) : 0;
        if (priceDiff > 1.5 || (!p.code && matched.name !== p.name)) {
          reviewCount++;
          items.push({ ...p, matchStatus: "review", matchedProductId: matched.id, matchedName: matched.name, matchedPrice: String(matched.price) });
        } else {
          existingCount++;
          items.push({ ...p, matchStatus: "existing", matchedProductId: matched.id, matchedName: matched.name, matchedPrice: String(matched.price) });
        }
      } else {
        if (!p.code || !p.price) {
          reviewCount++;
          items.push({ ...p, matchStatus: "review", matchedProductId: null });
        } else {
          newCount++;
          items.push({ ...p, matchStatus: "new", matchedProductId: null });
        }
      }
    }

    const inserted = await db.insert(priceLists).values({
      companyId, companyName,
      fileName: file.name.slice(0, 300),
      fileType: lower.endsWith(".csv") ? "csv" : "excel",
      totalItems: parsed.length, newCount, existingCount, reviewCount,
      status: "preview", createdBy: a.id,
    }).returning();

    const listId = inserted[0].id;
    for (const it of items) {
      await db.insert(priceListItems).values({
        priceListId: listId,
        name: it.name.slice(0, 300),
        code: it.code.slice(0, 100) || null,
        model: it.model.slice(0, 200) || null,
        size: it.size.slice(0, 100) || null,
        color: it.color.slice(0, 100) || null,
        price: String(it.price),
        companyName: it.companyName?.slice(0, 200) || null,
        matchStatus: it.matchStatus,
        matchedProductId: it.matchedProductId,
        rawData: it.raw,
      });
    }

    return ok({ list: inserted[0], items: items.slice(0, 500), totalParsed: items.length });
  } catch (e) {
    console.error(e);
    return serverError(e, "تعذر قراءة الملف — تأكد من الصيغة");
  }
}
