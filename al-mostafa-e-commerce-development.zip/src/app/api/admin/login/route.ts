import { db } from "@/db";
import { adminUsers } from "@/db/schema";
import { eq, ilike } from "drizzle-orm";
import { fail, ok, serverError } from "@/lib/api-helpers";
import { verifyPassword, signAdminJWT, ADMIN_COOKIE, checkRateLimit, recordLoginAttempt } from "@/lib/auth";
import { sanitizeText } from "@/lib/utils";
import { ensureSeed } from "@/lib/seed";

export async function POST(req: Request) {
  try {
    await ensureSeed();
    const body = await req.json();
    const email = sanitizeText(body.email || body.username, 255).toLowerCase();
    const password = String(body.password || "");
    if (!email || !password) return fail("أدخل البريد وكلمة المرور");

    const { allowed, remaining } = await checkRateLimit("admin:" + email);
    if (!allowed) return fail("محاولات كثيرة — تم إيقاف الدخول مؤقتاً لمدة 15 دقيقة", 429);

    // case-insensitive match (account may be stored as Admin@gmail.com)
    const rows = await db.select().from(adminUsers).where(ilike(adminUsers.email, email)).limit(1);
    const admin = rows[0];
    if (!admin || !admin.isActive) {
      await recordLoginAttempt("admin:" + email, false);
      return fail(`بيانات الدخول غير صحيحة (المحاولات المتبقية: ${remaining - 1})`, 401);
    }
    const valid = await verifyPassword(password, admin.passwordHash);
    if (!valid) {
      await recordLoginAttempt("admin:" + email, false);
      return fail(`بيانات الدخول غير صحيحة (المحاولات المتبقية: ${remaining - 1})`, 401);
    }
    await recordLoginAttempt("admin:" + email, true);
    await db.update(adminUsers).set({ lastLoginAt: new Date() }).where(eq(adminUsers.id, admin.id));

    const token = await signAdminJWT({ adminId: admin.id, email: admin.email, role: admin.role });
    const res = ok({ admin: { id: admin.id, name: admin.name, email: admin.email, role: admin.role } });
    res.cookies.set(ADMIN_COOKIE, token, { httpOnly: true, sameSite: "lax", path: "/", maxAge: 7 * 24 * 3600, secure: process.env.NODE_ENV === "production" });
    return res;
  } catch (e) {
    return serverError(e);
  }
}
