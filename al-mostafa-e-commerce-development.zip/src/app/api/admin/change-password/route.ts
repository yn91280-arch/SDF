import { db } from "@/db";
import { adminUsers } from "@/db/schema";
import { eq } from "drizzle-orm";
import { fail, ok, serverError } from "@/lib/api-helpers";
import { getAdminFromRequest, hashPassword, verifyPassword } from "@/lib/auth";

export async function POST(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const body = await req.json();
    const current = String(body.current || "");
    const next = String(body.next || body.newPassword || "");
    if (next.length < 6) return fail("كلمة المرور الجديدة 6 أحرف على الأقل");
    const rows = await db.select().from(adminUsers).where(eq(adminUsers.id, a.id)).limit(1);
    const admin = rows[0];
    if (!admin) return fail("غير مصرح", 401);
    const valid = await verifyPassword(current, admin.passwordHash);
    if (!valid) return fail("كلمة المرور الحالية غير صحيحة");
    await db.update(adminUsers).set({ passwordHash: await hashPassword(next), updatedAt: new Date() }).where(eq(adminUsers.id, a.id));
    return ok({ message: "تم تغيير كلمة المرور بنجاح" });
  } catch (e) {
    return serverError(e);
  }
}
