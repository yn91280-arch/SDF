import { ok } from "@/lib/api-helpers";
import { ADMIN_COOKIE } from "@/lib/auth";

export async function POST() {
  const res = ok({});
  res.cookies.set(ADMIN_COOKIE, "", { path: "/", maxAge: 0 });
  return res;
}
