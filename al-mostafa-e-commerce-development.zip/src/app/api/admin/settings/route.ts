import { fail, ok, serverError } from "@/lib/api-helpers";
import { getAdminFromRequest } from "@/lib/auth";
import { getSettings, setSettingsBulk } from "@/lib/site-settings";

const ALLOWED = [
  "site_url", "store_name", "store_name_en", "store_desc", "manager", "phone", "whatsapp",
  "address", "maps_url", "working_hours", "facebook", "instagram", "tiktok", "youtube",
  "currency", "tax_enabled", "tax_percent", "invoice_prefix", "invoice_notes",
  "hero_title", "hero_subtitle",
];

export async function GET() {
  const a = await getAdminFromRequest();
  if (!a) return fail("غير مصرح", 401);
  const s = await getSettings();
  return ok({ settings: s });
}

export async function POST(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const b = await req.json();
    const obj: Record<string, string> = {};
    for (const k of ALLOWED) {
      if (b[k] !== undefined) obj[k] = String(b[k] ?? "").slice(0, 2000);
    }
    if (obj.whatsapp) {
      const digits = obj.whatsapp.replace(/[^0-9]/g, "");
      if (digits.length < 10 || digits.length > 15) return fail("رقم الواتساب غير صالح");
    }
    await setSettingsBulk(obj);
    return ok({});
  } catch (e) {
    return serverError(e);
  }
}
