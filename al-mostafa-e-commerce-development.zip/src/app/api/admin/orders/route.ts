import { db } from "@/db";
import { orders, orderItems } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { fail, ok, serverError, parsePagination } from "@/lib/api-helpers";
import { getAdminFromRequest } from "@/lib/auth";

export async function GET(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const url = new URL(req.url);
    const { page, limit, offset } = parsePagination(url);
    const status = url.searchParams.get("status") || "";
    const q = (url.searchParams.get("q") || "").trim();
    let conds: string[] = [];
    // build with drizzle
    const where = status
      ? q
        ? sql`${orders.status} = ${status} AND (${orders.orderNumber} ILIKE ${"%" + q + "%"} OR ${orders.customerName} ILIKE ${"%" + q + "%"} OR ${orders.customerPhone} ILIKE ${"%" + q + "%"})`
        : sql`${orders.status} = ${status}`
      : q
        ? sql`(${orders.orderNumber} ILIKE ${"%" + q + "%"} OR ${orders.customerName} ILIKE ${"%" + q + "%"} OR ${orders.customerPhone} ILIKE ${"%" + q + "%"})`
        : undefined;
    const rows = where
      ? await db.select().from(orders).where(where).orderBy(desc(orders.id)).limit(limit).offset(offset)
      : await db.select().from(orders).orderBy(desc(orders.id)).limit(limit).offset(offset);
    const totalRes = where
      ? await db.select({ c: sql<number>`count(*)` }).from(orders).where(where)
      : await db.select({ c: sql<number>`count(*)` }).from(orders);
    return ok({ orders: rows, pagination: { page, limit, total: Number(totalRes[0]?.c || 0), pages: Math.ceil(Number(totalRes[0]?.c || 0) / limit) } });
  } catch (e) {
    return serverError(e);
  }
}

export async function PUT(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const b = await req.json();
    const id = Number(b.id);
    const status = String(b.status || "");
    const valid = ["new", "processing", "preparing", "ready", "delivered", "completed", "cancelled"];
    if (!id || !valid.includes(status)) return fail("بيانات غير صالحة");
    await db.update(orders).set({ status, updatedAt: new Date() }).where(eq(orders.id, id));
    return ok({});
  } catch (e) {
    return serverError(e);
  }
}
