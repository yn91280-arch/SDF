import { db } from "@/db";
import { orders, orderItems } from "@/db/schema";
import { eq } from "drizzle-orm";
import { fail, ok, serverError } from "@/lib/api-helpers";
import { getAdminFromRequest } from "@/lib/auth";

export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const { id } = await params;
    const rows = await db.select().from(orders).where(eq(orders.id, Number(id))).limit(1);
    if (!rows[0]) return fail("الطلب غير موجود", 404);
    const items = await db.select().from(orderItems).where(eq(orderItems.orderId, Number(id)));
    return ok({ order: rows[0], items });
  } catch (e) {
    return serverError(e);
  }
}
