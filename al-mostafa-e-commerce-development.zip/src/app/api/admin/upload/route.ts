import { fail, ok, serverError } from "@/lib/api-helpers";
import { getAdminFromRequest } from "@/lib/auth";
import { writeFile, mkdir } from "fs/promises";
import path from "path";

const ALLOWED = ["image/jpeg", "image/png", "image/webp", "image/gif"];
const MAX_SIZE = 5 * 1024 * 1024;

export async function POST(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const form = await req.formData();
    const file = form.get("file") as File | null;
    if (!file) return fail("اختر صورة أولاً");
    if (!ALLOWED.includes(file.type)) return fail("صيغة غير مدعومة — JPG/PNG/WebP فقط");
    if (file.size > MAX_SIZE) return fail("حجم الصورة كبير (الحد 5MB)");

    const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
    const safeExt = ["jpg", "jpeg", "png", "webp", "gif"].includes(ext) ? ext : "jpg";
    const filename = `${Date.now()}-${Math.random().toString(36).slice(2, 9)}.${safeExt}`;
    const dir = path.join(process.cwd(), "public", "uploads");
    await mkdir(dir, { recursive: true });
    const buf = Buffer.from(await file.arrayBuffer());
    await writeFile(path.join(dir, filename), buf);
    return ok({ url: `/uploads/${filename}` });
  } catch (e) {
    return serverError(e, "تعذر رفع الصورة");
  }
}
