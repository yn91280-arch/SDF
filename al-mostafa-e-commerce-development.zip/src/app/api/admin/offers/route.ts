import { db } from "@/db";
import { offers } from "@/db/schema";
import { eq, asc } from "drizzle-orm";
import { fail, ok, serverError } from "@/lib/api-helpers";
import { getAdminFromRequest } from "@/lib/auth";
import { sanitizeText } from "@/lib/utils";

export async function GET() {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const rows = await db.select().from(offers).orderBy(asc(offers.sortOrder));
    return ok({ offers: rows });
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const b = await req.json();
    const title = sanitizeText(b.title, 300);
    if (!title) return fail("أدخل عنوان العرض");
    const inserted = await db.insert(offers).values({
      title,
      subtitle: sanitizeText(b.subtitle, 500) || null,
      image: b.image || null,
      linkType: sanitizeText(b.linkType, 30) || "products",
      linkValue: sanitizeText(b.linkValue, 300) || null,
      discountPercent: b.discountPercent ? String(Number(b.discountPercent)) : null,
      isActive: b.isActive !== false,
      sortOrder: Number(b.sortOrder) || 0,
    }).returning();
    return ok({ offer: inserted[0] });
  } catch (e) {
    return serverError(e);
  }
}

export async function PUT(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const b = await req.json();
    const id = Number(b.id);
    if (!id) return fail("عرض غير صالح");
    await db.update(offers).set({
      title: b.title !== undefined ? sanitizeText(b.title, 300) : undefined,
      subtitle: b.subtitle !== undefined ? sanitizeText(b.subtitle, 500) : undefined,
      image: b.image !== undefined ? b.image : undefined,
      linkType: b.linkType !== undefined ? sanitizeText(b.linkType, 30) : undefined,
      linkValue: b.linkValue !== undefined ? sanitizeText(b.linkValue, 300) : undefined,
      discountPercent: b.discountPercent !== undefined ? (b.discountPercent ? String(Number(b.discountPercent)) : null) : undefined,
      isActive: b.isActive !== undefined ? !!b.isActive : undefined,
      sortOrder: b.sortOrder !== undefined ? Number(b.sortOrder) : undefined,
    }).where(eq(offers.id, id));
    return ok({});
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const url = new URL(req.url);
    await db.delete(offers).where(eq(offers.id, Number(url.searchParams.get("id"))));
    return ok({});
  } catch (e) {
    return serverError(e);
  }
}
