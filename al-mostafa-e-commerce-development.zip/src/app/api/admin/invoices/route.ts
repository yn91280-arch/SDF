import { db } from "@/db";
import { invoices, invoiceItems, products, inventoryMovements } from "@/db/schema";
import { eq, desc, sql, inArray } from "drizzle-orm";
import { fail, ok, serverError, parsePagination } from "@/lib/api-helpers";
import { getAdminFromRequest } from "@/lib/auth";
import { generateInvoiceNumber, sanitizeText } from "@/lib/utils";

export async function GET(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const url = new URL(req.url);
    const { page, limit, offset } = parsePagination(url);
    const q = (url.searchParams.get("q") || "").trim();
    const status = url.searchParams.get("status") || "";
    const from = url.searchParams.get("from") || "";
    const to = url.searchParams.get("to") || "";
    let where: ReturnType<typeof sql> | undefined;
    const parts: string[] = [];
    if (q) where = sql`(${invoices.invoiceNumber} ILIKE ${"%" + q + "%"} OR ${invoices.customerName} ILIKE ${"%" + q + "%"} OR ${invoices.customerPhone} ILIKE ${"%" + q + "%"})`;
    if (status) where = where ? sql`${where} AND ${invoices.status} = ${status}` : sql`${invoices.status} = ${status}`;
    if (from) where = where ? sql`${where} AND ${invoices.createdAt} >= ${from}` : sql`${invoices.createdAt} >= ${from}`;
    if (to) where = where ? sql`${where} AND ${invoices.createdAt} <= ${to}` : sql`${invoices.createdAt} <= ${to}`;
    const rows = where
      ? await db.select().from(invoices).where(where).orderBy(desc(invoices.id)).limit(limit).offset(offset)
      : await db.select().from(invoices).orderBy(desc(invoices.id)).limit(limit).offset(offset);
    const totalRes = where ? await db.select({ c: sql<number>`count(*)` }).from(invoices).where(where) : await db.select({ c: sql<number>`count(*)` }).from(invoices);
    const sums = where
      ? await db.select({ t: sql<string>`COALESCE(SUM(${invoices.total}),0)`, p: sql<string>`COALESCE(SUM(${invoices.paid}),0)`, r: sql<string>`COALESCE(SUM(${invoices.remaining}),0)` }).from(invoices).where(where)
      : await db.select({ t: sql<string>`COALESCE(SUM(${invoices.total}),0)`, p: sql<string>`COALESCE(SUM(${invoices.paid}),0)`, r: sql<string>`COALESCE(SUM(${invoices.remaining}),0)` }).from(invoices);
    return ok({ invoices: rows, sums: sums[0], pagination: { page, limit, total: Number(totalRes[0]?.c || 0), pages: Math.ceil(Number(totalRes[0]?.c || 0) / limit) } });
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const b = await req.json();
    const customerName = sanitizeText(b.customerName, 200);
    if (!customerName) return fail("أدخل اسم العميل");
    const items = Array.isArray(b.items) ? b.items : [];
    if (items.length === 0) return fail("أضف منتجاً واحداً على الأقل");

    // resolve products for stock deduction (optional)
    const ids = items.map((i: { productId: number }) => Number(i.productId)).filter(Boolean);
    const dbProds = ids.length > 0 ? await db.select().from(products).where(inArray(products.id, ids)) : [];
    const pmap = new Map(dbProds.map((p) => [p.id, p]));

    let subtotal = 0;
    const lines: Array<{ productId: number | null; productName: string; productCode: string; quantity: number; price: number; discount: number; total: number }> = [];
    for (const it of items) {
      const qty = Math.max(1, Number(it.quantity) || 1);
      const price = Math.max(0, Number(it.price) || 0);
      const disc = Math.max(0, Number(it.discount) || 0);
      const total = Math.max(0, price * qty - disc);
      subtotal += price * qty;
      lines.push({
        productId: it.productId ? Number(it.productId) : null,
        productName: sanitizeText(it.productName || pmap.get(Number(it.productId))?.name, 300) || "صنف",
        productCode: sanitizeText(it.productCode || pmap.get(Number(it.productId))?.code, 100),
        quantity: qty, price, discount: disc, total,
      });
    }
    const discountTotal = lines.reduce((s, l) => s + l.discount, 0) + Math.max(0, Number(b.extraDiscount) || 0);
    const tax = Math.max(0, Number(b.tax) || 0);
    const extraCharges = Math.max(0, Number(b.extraCharges) || 0);
    const total = Math.max(0, subtotal - discountTotal + tax + extraCharges);
    const paid = Math.max(0, Number(b.paid) || 0);
    const remaining = Math.max(0, total - paid);
    const status = remaining <= 0 ? "paid" : paid > 0 ? "partial" : "unpaid";
    const invoiceNumber = b.invoiceNumber || generateInvoiceNumber();

    // unique check
    const ex = await db.select().from(invoices).where(eq(invoices.invoiceNumber, invoiceNumber)).limit(1);
    const finalNumber = ex.length > 0 ? generateInvoiceNumber() : invoiceNumber;

    const inserted = await db.insert(invoices).values({
      invoiceNumber: finalNumber,
      customerName,
      customerPhone: sanitizeText(b.customerPhone, 30) || null,
      customerAddress: sanitizeText(b.customerAddress, 1000) || null,
      subtotal: String(subtotal),
      discount: String(discountTotal),
      tax: String(tax),
      extraCharges: String(extraCharges),
      total: String(total),
      paid: String(paid),
      remaining: String(remaining),
      status,
      notes: sanitizeText(b.notes, 2000) || null,
      templateId: sanitizeText(b.templateId, 50) || "classic",
      createdBy: a.id,
    }).returning();

    const inv = inserted[0];
    for (const l of lines) {
      await db.insert(invoiceItems).values({
        invoiceId: inv.id,
        productId: l.productId,
        productName: l.productName,
        productCode: l.productCode,
        quantity: l.quantity,
        price: String(l.price),
        discount: String(l.discount),
        total: String(l.total),
      });
      // deduct stock if linked product and requested
      if (l.productId && b.deductStock !== false) {
        const p = pmap.get(l.productId);
        if (p) {
          const newStock = Math.max(0, p.stock - l.quantity);
          await db.update(products).set({ stock: newStock, soldCount: p.soldCount + l.quantity }).where(eq(products.id, p.id));
          await db.insert(inventoryMovements).values({
            productId: p.id, productName: p.name, type: "out",
            quantity: l.quantity, previousStock: p.stock, newStock,
            reason: `فاتورة ${finalNumber}`, referenceId: finalNumber, createdBy: a.id,
          });
        }
      }
    }
    return ok({ invoice: inv });
  } catch (e) {
    return serverError(e);
  }
}

export async function PUT(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const b = await req.json();
    const id = Number(b.id);
    if (!id) return fail("فاتورة غير صالحة");
    const rows = await db.select().from(invoices).where(eq(invoices.id, id)).limit(1);
    if (!rows[0]) return fail("الفاتورة غير موجودة", 404);
    const paid = b.paid !== undefined ? Math.max(0, Number(b.paid) || 0) : Number(rows[0].paid);
    const total = Number(rows[0].total);
    const remaining = Math.max(0, total - paid);
    await db.update(invoices).set({
      paid: String(paid), remaining: String(remaining),
      status: remaining <= 0 ? "paid" : paid > 0 ? "partial" : "unpaid",
      customerName: b.customerName !== undefined ? sanitizeText(b.customerName, 200) : undefined,
      customerPhone: b.customerPhone !== undefined ? sanitizeText(b.customerPhone, 30) : undefined,
      customerAddress: b.customerAddress !== undefined ? sanitizeText(b.customerAddress, 1000) : undefined,
      notes: b.notes !== undefined ? sanitizeText(b.notes, 2000) : undefined,
      updatedAt: new Date(),
    }).where(eq(invoices.id, id));
    return ok({});
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const url = new URL(req.url);
    const id = Number(url.searchParams.get("id"));
    if (!id) return fail("فاتورة غير صالحة");
    await db.delete(invoiceItems).where(eq(invoiceItems.invoiceId, id));
    await db.delete(invoices).where(eq(invoices.id, id));
    return ok({});
  } catch (e) {
    return serverError(e);
  }
}
