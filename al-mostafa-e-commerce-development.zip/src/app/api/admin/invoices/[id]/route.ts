import { db } from "@/db";
import { invoices, invoiceItems } from "@/db/schema";
import { eq } from "drizzle-orm";
import { fail, ok, serverError } from "@/lib/api-helpers";
import { getAdminFromRequest } from "@/lib/auth";
import { getSettings } from "@/lib/site-settings";

export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const { id } = await params;
    const rows = await db.select().from(invoices).where(eq(invoices.id, Number(id))).limit(1);
    if (!rows[0]) return fail("الفاتورة غير موجودة", 404);
    const items = await db.select().from(invoiceItems).where(eq(invoiceItems.invoiceId, Number(id)));
    const settings = await getSettings();
    return ok({ invoice: rows[0], items, settings });
  } catch (e) {
    return serverError(e);
  }
}
