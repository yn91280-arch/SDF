import { db } from "@/db";
import { products, categories, companies, inventoryMovements } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { fail, ok, serverError, parsePagination } from "@/lib/api-helpers";
import { getAdminFromRequest } from "@/lib/auth";
import { sanitizeText, slugify } from "@/lib/utils";

export async function GET(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const url = new URL(req.url);
    const { page, limit, offset } = parsePagination(url);
    const q = (url.searchParams.get("q") || "").trim();
    let where: unknown = undefined;
    if (q) {
      const like = `%${q}%`;
      where = sql`(${products.name} ILIKE ${like} OR ${products.code} ILIKE ${like} OR ${products.model} ILIKE ${like} OR ${products.companyName} ILIKE ${like})`;
    }
    const rows = q
      ? await db.select().from(products).where(where as never).orderBy(desc(products.id)).limit(limit).offset(offset)
      : await db.select().from(products).orderBy(desc(products.id)).limit(limit).offset(offset);
    const totalRes = q
      ? await db.select({ c: sql<number>`count(*)` }).from(products).where(where as never)
      : await db.select({ c: sql<number>`count(*)` }).from(products);
    const cats = await db.select().from(categories);
    const comps = await db.select().from(companies);
    return ok({ products: rows, cats, comps, pagination: { page, limit, total: Number(totalRes[0]?.c || 0), pages: Math.ceil(Number(totalRes[0]?.c || 0) / limit) } });
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const b = await req.json();
    const name = sanitizeText(b.name, 300);
    const code = sanitizeText(b.code, 100);
    if (!name) return fail("أدخل اسم المنتج");
    if (!code) return fail("أدخل كود المنتج");

    const existing = await db.select().from(products).where(eq(products.code, code)).limit(1);
    if (existing.length > 0) return fail("هذا الكود مستخدم بالفعل");

    let categoryId = b.categoryId ? Number(b.categoryId) : null;
    let companyId = b.companyId ? Number(b.companyId) : null;
    let companyName = sanitizeText(b.companyName, 200);
    if (companyId) {
      const comp = await db.select().from(companies).where(eq(companies.id, companyId)).limit(1);
      if (comp[0]) companyName = comp[0].name;
    }
    const searchText = `${name} ${code} ${b.model || ""} ${companyName} ${b.brand || ""} ${b.size || ""} ${b.color || ""} ${b.keywords || ""}`.toLowerCase();
    const stock = Math.max(0, Number(b.stock) || 0);

    const inserted = await db.insert(products).values({
      name,
      code,
      model: sanitizeText(b.model, 200) || null,
      categoryId,
      companyId,
      companyName,
      brand: sanitizeText(b.brand, 200) || null,
      price: String(Number(b.price) || 0),
      oldPrice: b.oldPrice ? String(Number(b.oldPrice)) : null,
      discountPrice: b.discountPrice ? String(Number(b.discountPrice)) : null,
      stock,
      minStock: Number(b.minStock) || 5,
      size: sanitizeText(b.size, 100) || null,
      color: sanitizeText(b.color, 100) || null,
      description: sanitizeText(b.description, 5000) || null,
      specifications: (b.specifications as Record<string, string>) || null,
      images: Array.isArray(b.images) ? b.images.slice(0, 10) : [],
      keywords: sanitizeText(b.keywords, 1000) || null,
      searchText,
      isActive: b.isActive !== false,
      isFeatured: b.isFeatured === true,
      isOffer: b.isOffer === true,
    }).returning();

    await db.insert(inventoryMovements).values({
      productId: inserted[0].id, productName: name, type: "in", quantity: stock,
      previousStock: 0, newStock: stock, reason: "إضافة منتج جديد", createdBy: a.id,
    });

    return ok({ product: inserted[0] });
  } catch (e) {
    return serverError(e);
  }
}
