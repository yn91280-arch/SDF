import { db } from "@/db";
import { products, companies, inventoryMovements } from "@/db/schema";
import { eq } from "drizzle-orm";
import { fail, ok, serverError } from "@/lib/api-helpers";
import { getAdminFromRequest } from "@/lib/auth";
import { sanitizeText } from "@/lib/utils";

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const { id } = await params;
    const pid = Number(id);
    if (!pid) return fail("منتج غير صالح");
    const rows = await db.select().from(products).where(eq(products.id, pid)).limit(1);
    const old = rows[0];
    if (!old) return fail("المنتج غير موجود", 404);
    const b = await req.json();
    const name = sanitizeText(b.name ?? old.name, 300);
    const code = sanitizeText(b.code ?? old.code, 100);
    if (code !== old.code) {
      const ex = await db.select().from(products).where(eq(products.code, code)).limit(1);
      if (ex.length > 0) return fail("هذا الكود مستخدم بالفعل");
    }
    let companyName = b.companyName !== undefined ? sanitizeText(b.companyName, 200) : old.companyName;
    const companyId = b.companyId !== undefined ? (b.companyId ? Number(b.companyId) : null) : old.companyId;
    if (b.companyId) {
      const comp = await db.select().from(companies).where(eq(companies.id, Number(b.companyId))).limit(1);
      if (comp[0]) companyName = comp[0].name;
    }
    const newStock = b.stock !== undefined ? Math.max(0, Number(b.stock) || 0) : old.stock;
    const searchText = `${name} ${code} ${b.model ?? old.model ?? ""} ${companyName} ${b.brand ?? old.brand ?? ""} ${b.size ?? old.size ?? ""} ${b.color ?? old.color ?? ""} ${b.keywords ?? old.keywords ?? ""}`.toLowerCase();

    await db.update(products).set({
      name, code,
      model: b.model !== undefined ? (sanitizeText(b.model, 200) || null) : old.model,
      categoryId: b.categoryId !== undefined ? (b.categoryId ? Number(b.categoryId) : null) : old.categoryId,
      companyId, companyName,
      brand: b.brand !== undefined ? (sanitizeText(b.brand, 200) || null) : old.brand,
      price: b.price !== undefined ? String(Number(b.price) || 0) : old.price,
      oldPrice: b.oldPrice !== undefined ? (b.oldPrice ? String(Number(b.oldPrice)) : null) : old.oldPrice,
      discountPrice: b.discountPrice !== undefined ? (b.discountPrice ? String(Number(b.discountPrice)) : null) : old.discountPrice,
      stock: newStock,
      minStock: b.minStock !== undefined ? Number(b.minStock) || 5 : old.minStock,
      size: b.size !== undefined ? (sanitizeText(b.size, 100) || null) : old.size,
      color: b.color !== undefined ? (sanitizeText(b.color, 100) || null) : old.color,
      description: b.description !== undefined ? (sanitizeText(b.description, 5000) || null) : old.description,
      specifications: b.specifications !== undefined ? b.specifications : old.specifications,
      images: b.images !== undefined ? (Array.isArray(b.images) ? b.images.slice(0, 10) : old.images) : old.images,
      keywords: b.keywords !== undefined ? (sanitizeText(b.keywords, 1000) || null) : old.keywords,
      searchText,
      isActive: b.isActive !== undefined ? !!b.isActive : old.isActive,
      isFeatured: b.isFeatured !== undefined ? !!b.isFeatured : old.isFeatured,
      isOffer: b.isOffer !== undefined ? !!b.isOffer : old.isOffer,
      updatedAt: new Date(),
    }).where(eq(products.id, pid));

    if (newStock !== old.stock) {
      await db.insert(inventoryMovements).values({
        productId: pid, productName: name,
        type: newStock > old.stock ? "in" : "adjust",
        quantity: Math.abs(newStock - old.stock),
        previousStock: old.stock, newStock,
        reason: b.stockReason || "تعديل يدوي للمخزون", createdBy: a.id,
      });
    }
    return ok({});
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(_: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const { id } = await params;
    await db.delete(products).where(eq(products.id, Number(id)));
    return ok({});
  } catch (e) {
    return serverError(e);
  }
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const { id } = await params;
    const b = await req.json();
    const patch: Record<string, unknown> = { updatedAt: new Date() };
    if (b.isActive !== undefined) patch.isActive = !!b.isActive;
    if (b.isFeatured !== undefined) patch.isFeatured = !!b.isFeatured;
    if (b.isOffer !== undefined) patch.isOffer = !!b.isOffer;
    if (b.price !== undefined) patch.price = String(Number(b.price) || 0);
    if (b.stock !== undefined) patch.stock = Math.max(0, Number(b.stock) || 0);
    await db.update(products).set(patch).where(eq(products.id, Number(id)));
    return ok({});
  } catch (e) {
    return serverError(e);
  }
}
