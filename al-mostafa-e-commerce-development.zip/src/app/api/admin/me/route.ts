import { getAdminFromRequest } from "@/lib/auth";
import { ok, fail } from "@/lib/api-helpers";

export async function GET() {
  const a = await getAdminFromRequest();
  if (!a) return fail("غير مصرح", 401);
  return ok({ admin: a });
}
