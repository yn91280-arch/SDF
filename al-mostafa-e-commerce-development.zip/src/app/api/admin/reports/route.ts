import { db } from "@/db";
import { orders, orderItems, invoices, products, categories, companies } from "@/db/schema";
import { sql } from "drizzle-orm";
import { fail, ok, serverError } from "@/lib/api-helpers";
import { getAdminFromRequest } from "@/lib/auth";

export async function GET(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const url = new URL(req.url);
    const from = url.searchParams.get("from") || "";
    const to = url.searchParams.get("to") || "";
    const dateFilter = (col: unknown) => {
      if (from && to) return sql`${col} >= ${from} AND ${col} <= ${to} AND `;
      if (from) return sql`${col} >= ${from} AND `;
      if (to) return sql`${col} <= ${to} AND `;
      return sql``;
    };

    const salesByDay = await db.execute(sql`
      SELECT to_char(${orders.createdAt}, 'YYYY-MM-DD') as day, COUNT(*) as orders, COALESCE(SUM(${orders.total}),0) as total
      FROM orders WHERE ${dateFilter(orders.createdAt)} ${orders.status} != 'cancelled'
      GROUP BY 1 ORDER BY 1 DESC LIMIT 30
    `);
    const topProducts = await db.execute(sql`
      SELECT ${orderItems.productName} as name, ${orderItems.productCode} as code, SUM(${orderItems.quantity}) as qty, SUM(${orderItems.total}) as total
      FROM order_items JOIN orders ON orders.id = order_items.order_id
      WHERE ${from ? sql`${orders.createdAt} >= ${from} AND ` : sql``} ${to ? sql`${orders.createdAt} <= ${to} AND ` : sql``} ${orders.status} != 'cancelled'
      GROUP BY 1,2 ORDER BY total DESC LIMIT 20
    `);
    const companySales = await db.execute(sql`
      SELECT COALESCE(${orderItems.companyName}, '—') as company, SUM(${orderItems.quantity}) as qty, SUM(${orderItems.total}) as total
      FROM order_items JOIN orders ON orders.id = order_items.order_id
      WHERE ${from ? sql`${orders.createdAt} >= ${from} AND ` : sql``} ${to ? sql`${orders.createdAt} <= ${to} AND ` : sql``} ${orders.status} != 'cancelled'
      GROUP BY 1 ORDER BY total DESC LIMIT 20
    `);
    const invTotals = await db.execute(sql`
      SELECT COUNT(*) as count, COALESCE(SUM(${invoices.total}),0) as total, COALESCE(SUM(${invoices.paid}),0) as paid, COALESCE(SUM(${invoices.remaining}),0) as remaining
      FROM invoices WHERE ${from ? sql`${invoices.createdAt} >= ${from} AND ` : sql``} ${to ? sql`${invoices.createdAt} <= ${to} AND ` : sql``} 1=1
    `);
    const outstanding = await db.select({ id: invoices.id, invoiceNumber: invoices.invoiceNumber, customerName: invoices.customerName, customerPhone: invoices.customerPhone, total: invoices.total, paid: invoices.paid, remaining: invoices.remaining, createdAt: invoices.createdAt }).from(invoices).where(sql`${invoices.remaining} > 0`).orderBy(sql`${invoices.remaining} DESC`).limit(30);
    const lowStock = await db.select().from(products).where(sql`${products.stock} <= ${products.minStock}`).limit(30);
    const categorySales = await db.execute(sql`
      SELECT COALESCE(${categories.name}, 'بدون قسم') as category, COUNT(${products.id}) as products, COALESCE(SUM(${products.soldCount}),0) as sold
      FROM products LEFT JOIN categories ON categories.id = ${products.categoryId}
      GROUP BY 1 ORDER BY sold DESC
    `);

    return ok({
      salesByDay: salesByDay.rows,
      topProducts: topProducts.rows,
      companySales: companySales.rows,
      categorySales: categorySales.rows,
      invTotals: invTotals.rows[0],
      outstanding,
      lowStock,
    });
  } catch (e) {
    return serverError(e);
  }
}
