import { db } from "@/db";
import { products, inventoryMovements } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { fail, ok, serverError, parsePagination } from "@/lib/api-helpers";
import { getAdminFromRequest } from "@/lib/auth";
import { sanitizeText } from "@/lib/utils";

export async function GET(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const url = new URL(req.url);
    const { page, limit, offset } = parsePagination(url);
    const tab = url.searchParams.get("tab") || "products";
    const q = (url.searchParams.get("q") || "").trim();
    const lowOnly = url.searchParams.get("low") === "1";

    if (tab === "movements") {
      const where = q ? sql`(${inventoryMovements.productName} ILIKE ${"%" + q + "%"} OR ${inventoryMovements.reason} ILIKE ${"%" + q + "%"})` : undefined;
      const rows = where
        ? await db.select().from(inventoryMovements).where(where).orderBy(desc(inventoryMovements.id)).limit(limit).offset(offset)
        : await db.select().from(inventoryMovements).orderBy(desc(inventoryMovements.id)).limit(limit).offset(offset);
      const totalRes = where ? await db.select({ c: sql<number>`count(*)` }).from(inventoryMovements).where(where) : await db.select({ c: sql<number>`count(*)` }).from(inventoryMovements);
      return ok({ movements: rows, pagination: { page, limit, total: Number(totalRes[0]?.c || 0), pages: Math.ceil(Number(totalRes[0]?.c || 0) / limit) } });
    }

    let where: ReturnType<typeof sql> | undefined;
    if (q) where = sql`(${products.name} ILIKE ${"%" + q + "%"} OR ${products.code} ILIKE ${"%" + q + "%"})`;
    if (lowOnly) where = where ? sql`${where} AND ${products.stock} <= ${products.minStock}` : sql`${products.stock} <= ${products.minStock}`;
    const rows = where
      ? await db.select().from(products).where(where).orderBy(products.stock).limit(limit).offset(offset)
      : await db.select().from(products).orderBy(products.stock).limit(limit).offset(offset);
    const totalRes = where ? await db.select({ c: sql<number>`count(*)` }).from(products).where(where) : await db.select({ c: sql<number>`count(*)` }).from(products);
    return ok({ products: rows, pagination: { page, limit, total: Number(totalRes[0]?.c || 0), pages: Math.ceil(Number(totalRes[0]?.c || 0) / limit) } });
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const b = await req.json();
    const productId = Number(b.productId);
    const quantity = Number(b.quantity) || 0;
    const type = String(b.type || "in"); // in | out | adjust
    if (!productId || !quantity || quantity <= 0) return fail("أدخل المنتج والكمية");
    if (!["in", "out", "adjust"].includes(type)) return fail("نوع الحركة غير صالح");
    const rows = await db.select().from(products).where(eq(products.id, productId)).limit(1);
    const p = rows[0];
    if (!p) return fail("المنتج غير موجود", 404);
    let newStock = p.stock;
    if (type === "in") newStock = p.stock + quantity;
    else if (type === "out") newStock = Math.max(0, p.stock - quantity);
    else newStock = quantity; // adjust = set
    await db.update(products).set({ stock: newStock, minStock: b.minStock !== undefined ? Number(b.minStock) : p.minStock, updatedAt: new Date() }).where(eq(products.id, productId));
    await db.insert(inventoryMovements).values({
      productId, productName: p.name, type,
      quantity: type === "adjust" ? Math.abs(newStock - p.stock) : quantity,
      previousStock: p.stock, newStock,
      reason: sanitizeText(b.reason, 300) || (type === "in" ? "إضافة مخزون" : type === "out" ? "صرف مخزون" : "تسوية مخزون"),
      createdBy: a.id,
    });
    return ok({ newStock });
  } catch (e) {
    return serverError(e);
  }
}
