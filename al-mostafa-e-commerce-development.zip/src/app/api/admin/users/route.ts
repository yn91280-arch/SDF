import { db } from "@/db";
import { adminUsers } from "@/db/schema";
import { eq } from "drizzle-orm";
import { fail, ok, serverError } from "@/lib/api-helpers";
import { getAdminFromRequest, hashPassword } from "@/lib/auth";
import { sanitizeText } from "@/lib/utils";

export async function GET() {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const rows = await db.select({ id: adminUsers.id, name: adminUsers.name, email: adminUsers.email, role: adminUsers.role, isActive: adminUsers.isActive, lastLoginAt: adminUsers.lastLoginAt, createdAt: adminUsers.createdAt }).from(adminUsers);
    return ok({ users: rows });
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    if (a.role !== "admin") return fail("صلاحيات غير كافية", 403);
    const b = await req.json();
    const name = sanitizeText(b.name, 200);
    const email = sanitizeText(b.email, 255).toLowerCase();
    const password = String(b.password || "");
    if (!name || !email || password.length < 6) return fail("أدخل الاسم والبريد وكلمة مرور 6 أحرف على الأقل");
    const ex = await db.select().from(adminUsers).where(eq(adminUsers.email, email)).limit(1);
    if (ex.length > 0) return fail("هذا البريد مسجل بالفعل");
    const inserted = await db.insert(adminUsers).values({
      name, email, passwordHash: await hashPassword(password),
      role: b.role === "manager" ? "manager" : "staff", isActive: true,
    }).returning({ id: adminUsers.id, name: adminUsers.name, email: adminUsers.email, role: adminUsers.role });
    return ok({ user: inserted[0] });
  } catch (e) {
    return serverError(e);
  }
}

export async function PUT(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const b = await req.json();
    const id = Number(b.id);
    if (!id) return fail("مستخدم غير صالح");
    if (id === a.id && b.isActive === false) return fail("لا يمكنك تعطيل حسابك");
    await db.update(adminUsers).set({
      name: b.name !== undefined ? sanitizeText(b.name, 200) : undefined,
      role: b.role !== undefined ? String(b.role) : undefined,
      isActive: b.isActive !== undefined ? !!b.isActive : undefined,
      ...(b.password && String(b.password).length >= 6 ? { passwordHash: await hashPassword(String(b.password)) } : {}),
      updatedAt: new Date(),
    }).where(eq(adminUsers.id, id));
    return ok({});
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    if (a.role !== "admin") return fail("صلاحيات غير كافية", 403);
    const url = new URL(req.url);
    const id = Number(url.searchParams.get("id"));
    if (!id || id === a.id) return fail("لا يمكنك حذف حسابك");
    await db.delete(adminUsers).where(eq(adminUsers.id, id));
    return ok({});
  } catch (e) {
    return serverError(e);
  }
}
