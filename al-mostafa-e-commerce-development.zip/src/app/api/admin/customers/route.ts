import { db } from "@/db";
import { customers } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { fail, ok, serverError, parsePagination } from "@/lib/api-helpers";
import { getAdminFromRequest } from "@/lib/auth";

export async function GET(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const url = new URL(req.url);
    const { page, limit, offset } = parsePagination(url);
    const q = (url.searchParams.get("q") || "").trim();
    const where = q ? sql`(${customers.name} ILIKE ${"%" + q + "%"} OR ${customers.phone} ILIKE ${"%" + q + "%"} OR ${customers.email} ILIKE ${"%" + q + "%"})` : undefined;
    // Never expose password hashes
    const rows = where
      ? await db.select({ id: customers.id, name: customers.name, phone: customers.phone, email: customers.email, address: customers.address, isActive: customers.isActive, totalOrders: customers.totalOrders, totalSpent: customers.totalSpent, lastOrderAt: customers.lastOrderAt, createdAt: customers.createdAt }).from(customers).where(where).orderBy(desc(customers.id)).limit(limit).offset(offset)
      : await db.select({ id: customers.id, name: customers.name, phone: customers.phone, email: customers.email, address: customers.address, isActive: customers.isActive, totalOrders: customers.totalOrders, totalSpent: customers.totalSpent, lastOrderAt: customers.lastOrderAt, createdAt: customers.createdAt }).from(customers).orderBy(desc(customers.id)).limit(limit).offset(offset);
    const totalRes = where ? await db.select({ c: sql<number>`count(*)` }).from(customers).where(where) : await db.select({ c: sql<number>`count(*)` }).from(customers);
    return ok({ customers: rows, pagination: { page, limit, total: Number(totalRes[0]?.c || 0), pages: Math.ceil(Number(totalRes[0]?.c || 0) / limit) } });
  } catch (e) {
    return serverError(e);
  }
}

export async function PUT(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const b = await req.json();
    const id = Number(b.id);
    if (!id) return fail("عميل غير صالح");
    await db.update(customers).set({ isActive: b.isActive !== undefined ? !!b.isActive : undefined, updatedAt: new Date() }).where(eq(customers.id, id));
    return ok({});
  } catch (e) {
    return serverError(e);
  }
}
