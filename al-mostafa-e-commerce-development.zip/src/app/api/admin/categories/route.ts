import { db } from "@/db";
import { categories, products } from "@/db/schema";
import { eq, sql, asc } from "drizzle-orm";
import { fail, ok, serverError } from "@/lib/api-helpers";
import { getAdminFromRequest } from "@/lib/auth";
import { sanitizeText, slugify } from "@/lib/utils";

export async function GET() {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const cats = await db.select().from(categories).orderBy(asc(categories.sortOrder));
    const counts = await db.select({ categoryId: products.categoryId, count: sql<number>`count(*)` }).from(products).groupBy(products.categoryId);
    const map = new Map<number | null, number>();
    for (const c of counts) map.set(c.categoryId, Number(c.count));
    return ok({ categories: cats.map((c) => ({ ...c, productCount: map.get(c.id) ?? 0 })) });
  } catch (e) {
    return serverError(e);
  }
}

export async function POST(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const b = await req.json();
    const name = sanitizeText(b.name, 200);
    if (!name) return fail("أدخل اسم القسم");
    let slug = sanitizeText(b.slug, 200) || slugify(name);
    const ex = await db.select().from(categories).where(eq(categories.slug, slug)).limit(1);
    if (ex.length > 0) slug = `${slug}-${Date.now().toString().slice(-4)}`;
    const inserted = await db.insert(categories).values({
      name, slug,
      description: sanitizeText(b.description, 2000) || null,
      image: b.image || null,
      isActive: b.isActive !== false,
      sortOrder: Number(b.sortOrder) || 0,
      discountPercent: String(Number(b.discountPercent) || 0),
    }).returning();
    return ok({ category: inserted[0] });
  } catch (e) {
    return serverError(e);
  }
}

export async function PUT(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const b = await req.json();
    const id = Number(b.id);
    if (!id) return fail("قسم غير صالح");
    await db.update(categories).set({
      name: b.name !== undefined ? sanitizeText(b.name, 200) : undefined,
      description: b.description !== undefined ? sanitizeText(b.description, 2000) : undefined,
      image: b.image !== undefined ? b.image : undefined,
      isActive: b.isActive !== undefined ? !!b.isActive : undefined,
      sortOrder: b.sortOrder !== undefined ? Number(b.sortOrder) : undefined,
      discountPercent: b.discountPercent !== undefined ? String(Number(b.discountPercent) || 0) : undefined,
      updatedAt: new Date(),
    }).where(eq(categories.id, id));
    return ok({});
  } catch (e) {
    return serverError(e);
  }
}

export async function DELETE(req: Request) {
  try {
    const a = await getAdminFromRequest();
    if (!a) return fail("غير مصرح", 401);
    const url = new URL(req.url);
    const id = Number(url.searchParams.get("id"));
    if (!id) return fail("قسم غير صالح");
    await db.update(products).set({ categoryId: null }).where(eq(products.categoryId, id));
    await db.delete(categories).where(eq(categories.id, id));
    return ok({});
  } catch (e) {
    return serverError(e);
  }
}
