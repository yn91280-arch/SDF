"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Header, Footer, MobileNav } from "@/components/StoreChrome";
import { useCart } from "@/components/CartProvider";
import { formatPrice } from "@/lib/utils";

export default function CheckoutPage() {
  const cart = useCart();
  const router = useRouter();
  const [settings, setSettings] = useState({ store_name: "معرض المصطفي", phone: "01147104601", whatsapp: "01147104601", manager: "" });
  const [cats, setCats] = useState<any[]>([]);
  const [form, setForm] = useState({ name: "", phone: "", address: "", notes: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState<any>(null);

  useEffect(() => {
    fetch("/api/settings").then((r) => r.json()).then((j) => { if (j.ok) setSettings(j.settings); }).catch(() => {});
    fetch("/api/categories").then((r) => r.json()).then((j) => { if (j.ok) setCats(j.categories); }).catch(() => {});
    fetch("/api/auth/me").then((r) => r.json()).then((j) => {
      if (j.ok && j.customer) setForm((f) => ({ ...f, name: j.customer.name || "", phone: j.customer.phone || "" }));
    }).catch(() => {});
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (cart.items.length === 0) { setError("السلة فارغة"); return; }
    setLoading(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, items: cart.items.map((i) => ({ id: i.id, qty: i.qty, name: i.name })) }),
      });
      const j = await res.json();
      if (!j.ok) { setError(j.message || "تعذر إنشاء الطلب"); setLoading(false); return; }
      setDone(j.order);
      cart.clear();
    } catch {
      setError("حدث خطأ، حاول مرة أخرى");
    }
    setLoading(false);
  };

  const waNum = (settings.whatsapp || "").replace(/[^0-9]/g, "");
  const waIntl = waNum.startsWith("20") ? waNum : "20" + waNum.replace(/^0/, "");

  if (done) {
    const msg = encodeURIComponent(`🧾 طلب جديد\nرقم الطلب: ${done.orderNumber}\nالاسم: ${done.customerName}\nالهاتف: ${done.customerPhone}\nالإجمالي: ${done.total} ج.م\n🌐 الموقع: https://Sanitary-ware-store\n🏪 ${settings.store_name}`);
    return (
      <div className="min-h-screen">
        <Header s={settings} categories={cats} />
        <div className="mx-auto max-w-2xl px-4 py-12 text-center">
          <div className="rounded-3xl bg-white p-10 card-shadow">
            <div className="text-7xl">✅</div>
            <h1 className="mt-4 text-2xl font-black text-[#0b1526]">تم استلام طلبك بنجاح!</h1>
            <p className="mt-2 text-gray-500">رقم الطلب:</p>
            <div className="mx-auto mt-2 w-fit rounded-2xl bg-[#0b1526] px-6 py-3 font-mono text-xl font-black text-[#e8c766]" dir="ltr">{done.orderNumber}</div>
            <p className="mt-4 text-sm text-gray-500">سنتواصل معك قريباً لتأكيد الطلب — الإجمالي: <b>{formatPrice(done.total)}</b></p>
            <div className="mt-6 grid gap-3 sm:grid-cols-3">
              <a href={`https://wa.me/${waIntl}?text=${msg}`} target="_blank" rel="noopener noreferrer" className="rounded-xl bg-[#25D366] py-3 font-bold text-white">💬 تأكيد واتساب</a>
              <Link href="/account" className="rounded-xl bg-[#0b1526] py-3 font-bold text-white">طلباتي</Link>
              <Link href="/products" className="rounded-xl border py-3 font-bold">متابعة التسوق</Link>
            </div>
          </div>
        </div>
        <Footer s={settings} />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header s={settings} categories={cats} />
      <div className="mx-auto max-w-5xl px-4 py-8">
        <h1 className="text-3xl font-black text-[#0b1526]">إتمام الطلب 🧾</h1>
        {cart.items.length === 0 ? (
          <div className="mt-6 rounded-3xl bg-white p-12 text-center">
            <div className="text-5xl">🛒</div>
            <div className="mt-3 font-bold">سلتك فارغة</div>
            <Link href="/products" className="mt-4 inline-block rounded-xl gold-bg px-6 py-3 font-bold text-[#0b1526]">تصفح المنتجات</Link>
          </div>
        ) : (
          <div className="mt-6 grid gap-6 lg:grid-cols-5">
            <form onSubmit={submit} className="space-y-4 rounded-3xl bg-white p-6 card-shadow lg:col-span-3">
              <div className="font-black text-[#0b1526]">📝 بيانات التوصيل</div>
              {error && <div className="rounded-xl bg-red-50 p-3 text-sm font-bold text-red-600">{error}</div>}
              <div>
                <label className="text-sm font-bold">الاسم بالكامل *</label>
                <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="mt-1 w-full rounded-xl border px-4 py-3 outline-none focus:border-[#c9a227]" placeholder="مثال: أحمد محمد" />
              </div>
              <div>
                <label className="text-sm font-bold">رقم الهاتف *</label>
                <input required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="mt-1 w-full rounded-xl border px-4 py-3 outline-none focus:border-[#c9a227]" placeholder="01xxxxxxxxx" dir="ltr" />
              </div>
              <div>
                <label className="text-sm font-bold">العنوان بالتفصيل *</label>
                <textarea required value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className="mt-1 w-full rounded-xl border px-4 py-3 outline-none focus:border-[#c9a227]" rows={3} placeholder="المحافظة — المدينة — الشارع — علامة مميزة" />
              </div>
              <div>
                <label className="text-sm font-bold">ملاحظات (اختياري)</label>
                <textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="mt-1 w-full rounded-xl border px-4 py-3 outline-none focus:border-[#c9a227]" rows={2} placeholder="أي تفاصيل إضافية…" />
              </div>
              <button disabled={loading} className="w-full rounded-2xl gold-bg py-4 font-black text-[#0b1526] disabled:opacity-50">
                {loading ? "⏳ جاري إرسال الطلب…" : `تأكيد الطلب — ${formatPrice(cart.total)}`}
              </button>
              <p className="text-center text-xs text-gray-400">الدفع عند الاستلام • سنتواصل معك للتأكيد</p>
            </form>
            <div className="h-fit rounded-3xl bg-white p-6 card-shadow lg:col-span-2">
              <div className="font-black text-[#0b1526]">منتجاتك ({cart.count})</div>
              <div className="mt-3 max-h-80 space-y-2 overflow-y-auto">
                {cart.items.map((it) => (
                  <div key={it.id} className="flex items-center gap-3 rounded-xl bg-[#faf8f2] p-2">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={it.image} alt="" className="h-12 w-12 rounded-lg object-cover" />
                    <div className="min-w-0 flex-1">
                      <div className="line-clamp-1 text-sm font-bold">{it.name}</div>
                      <div className="text-xs text-gray-500">× {it.qty}</div>
                    </div>
                    <div className="text-sm font-black">{formatPrice(it.price * it.qty)}</div>
                  </div>
                ))}
              </div>
              <div className="mt-4 space-y-1 border-t pt-3 text-sm">
                <div className="flex justify-between text-gray-500"><span>المجموع الفرعي</span><span>{formatPrice(cart.subtotal)}</span></div>
                {cart.discount > 0 && <div className="flex justify-between text-emerald-600"><span>الخصم</span><span>− {formatPrice(cart.discount)}</span></div>}
                <div className="flex justify-between pt-1 text-lg font-black"><span>الإجمالي</span><span>{formatPrice(cart.total)}</span></div>
              </div>
            </div>
          </div>
        )}
      </div>
      <Footer s={settings} />
      <MobileNav />
    </div>
  );
}
