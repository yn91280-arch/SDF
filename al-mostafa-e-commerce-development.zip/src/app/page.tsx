import Link from "next/link";
import { Header, Footer, FloatingWhatsApp, MobileNav } from "@/components/StoreChrome";
import ProductCard from "@/components/ProductCard";
import HeroSlider from "@/components/HeroSlider";
import Logo from "@/components/Logo";
import { getStoreChrome } from "@/lib/store-data";
import { db } from "@/db";
import { products, categories, offers, companies } from "@/db/schema";
import { eq, and, desc, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

const FEATURES = [
  ["✅", "منتجات أصلية", "من أفضل الشركات"],
  ["🚚", "أسعار مميزة", "وفريات مستمرة"],
  ["🎧", "خدمة عملاء متميزة", "دعم دائم في خدمتك"],
  ["🛡️", "ضمان على المنتجات", "لجميع المنتجات"],
];

export default async function HomePage() {
  const { settings, categories: navCats } = await getStoreChrome();

  let featured: typeof products.$inferSelect[] = [];
  let offerProducts: typeof products.$inferSelect[] = [];
  let latest: typeof products.$inferSelect[] = [];
  let cats: typeof categories.$inferSelect[] = [];
  let banners: typeof offers.$inferSelect[] = [];
  let comps: typeof companies.$inferSelect[] = [];
  try {
    [featured, offerProducts, latest, cats, banners, comps] = await Promise.all([
      db.select().from(products).where(and(eq(products.isActive, true), eq(products.isFeatured, true))).orderBy(desc(products.id)).limit(8),
      db.select().from(products).where(and(eq(products.isActive, true), eq(products.isOffer, true))).orderBy(desc(products.id)).limit(8),
      db.select().from(products).where(eq(products.isActive, true)).orderBy(desc(products.id)).limit(8),
      db.select().from(categories).where(eq(categories.isActive, true)).orderBy(categories.sortOrder).limit(12),
      db.select().from(offers).where(eq(offers.isActive, true)).limit(4),
      db.select().from(companies).where(eq(companies.isActive, true)).limit(10),
    ]);
  } catch {}

  const counts = await db
    .select({ categoryId: products.categoryId, count: sql<number>`count(*)` })
    .from(products)
    .where(eq(products.isActive, true))
    .groupBy(products.categoryId)
    .catch(() => []);
  const countMap = new Map<number | null, number>();
  for (const c of counts as Array<{ categoryId: number | null; count: number }>) countMap.set(c.categoryId, Number(c.count));

  const waNum = (settings.whatsapp || "").replace(/[^0-9]/g, "");
  const waIntl = waNum.startsWith("20") ? waNum : "20" + waNum.replace(/^0/, "");

  const slides = [
    {
      title: settings.hero_title || "كل ما تحتاجه لتجهيز حمامك ومطبخك في مكان واحد",
      subtitle: settings.hero_subtitle || "أفضل تشكيلة من الأدوات الصحية والسباكة بأفضل الماركات وأفضل الأسعار",
      image: "/images/hero-bathroom.jpg",
      cta: "تسوق الآن",
      href: "/products",
    },
    {
      title: "عروض خاصّة على الخلاطات والأحواض",
      subtitle: "خصومات تصل إلى 25% على أفضل الماركات العالمية لفترة محدودة",
      image: "/images/showroom-shelf.jpg",
      cta: "تصفح العروض",
      href: "/offers",
    },
    {
      title: "أطقم حمامات كاملة بأسعار المعرض",
      subtitle: "جهّز حمامك بالكامل من مكان واحد مع ضمان وجودة مضمونة",
      image: "/images/hero-bathroom.jpg",
      cta: "تسوق الآن",
      href: "/categories/bathroom-sets",
    },
  ];

  return (
    <div className="min-h-screen bg-[#0b1526]">
      <Header s={settings} categories={navCats} />

      {/* ── HERO ── */}
      <section className="border-b border-white/5 bg-[#0b1526]">
        <div className="mx-auto grid max-w-[1320px] gap-4 px-4 py-5 lg:grid-cols-[300px_1fr]">
          {/* features column (right in RTL) */}
          <div className="order-1 flex flex-col justify-center gap-3 rounded-2xl border border-white/8 bg-white/[0.03] p-4">
            {FEATURES.map(([icon, t, d]) => (
              <div key={t} className="flex items-center gap-3">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-[#c9a227]/45 bg-[#c9a227]/10 text-lg shadow-[0_0_18px_rgba(201,162,39,0.18)]">
                  {icon}
                </div>
                <div>
                  <div className="text-[15px] font-bold text-white">{t}</div>
                  <div className="text-xs text-white/55">{d}</div>
                </div>
              </div>
            ))}
          </div>
          {/* slider */}
          <div className="order-2">
            <HeroSlider slides={slides} />
          </div>
        </div>
      </section>

      {/* ── CATEGORY STRIP ── */}
      <section className="bg-[#0b1526] pb-2">
        <div className="mx-auto max-w-[1320px] px-4">
          <div className="no-scrollbar flex gap-3 overflow-x-auto pb-3">
            {cats.map((c) => (
              <Link
                key={c.id}
                href={`/categories/${c.slug}`}
                className="group w-[118px] shrink-0 overflow-hidden rounded-2xl border border-white/10 bg-white/[0.05] transition hover:-translate-y-1 hover:border-[#c9a227]"
              >
                <div className="h-[86px] w-full overflow-hidden bg-[#12203c]">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={c.image || "/images/showroom-shelf.jpg"}
                    alt={c.name}
                    loading="lazy"
                    className="h-full w-full object-cover transition duration-500 group-hover:scale-110"
                  />
                </div>
                <div className="px-2 py-2 text-center text-[12.5px] font-bold text-white">{c.name}</div>
              </Link>
            ))}
            <div className="flex w-[220px] shrink-0 flex-col items-center justify-center rounded-2xl border border-[#c9a227]/35 bg-gradient-to-l from-[#12203c] to-[#0b1526] p-4 text-center">
              <div className="flex items-center gap-2 text-base font-black text-[#e8c766]">💎 أفضل الماركات العالمية</div>
              <Link href="/products" className="mt-3 rounded-full gold-bg px-5 py-2 text-xs font-black text-[#0b1526]">
                تصفح جميع المنتجات
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── PRODUCTS + SIDEBAR ── */}
      <section className="bg-[#0b1526] pb-8">
        <div className="mx-auto grid max-w-[1320px] gap-4 px-4 lg:grid-cols-[1fr_310px]">
          {/* main white card */}
          <div className="rounded-[22px] bg-white p-5 shadow-[0_18px_50px_rgba(0,0,0,0.35)]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl gold-bg text-lg">🧰</span>
                <h2 className="text-xl font-black text-[#0b1526]">أحدث المنتجات</h2>
              </div>
              <Link href="/products" className="flex items-center gap-1.5 rounded-full border border-[#0b1526]/12 px-4 py-1.5 text-[13px] font-bold text-[#0b1526] hover:bg-[#0b1526] hover:text-white">
                عرض الكل ←
              </Link>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {latest.slice(0, 8).map((p) => (
                <ProductCard
                  key={p.id}
                  whatsapp={settings.whatsapp}
                  p={{
                    id: p.id, name: p.name, code: p.code, model: p.model, companyName: p.companyName, brand: p.brand,
                    price: p.price, oldPrice: p.oldPrice, discountPrice: p.discountPrice, stock: p.stock,
                    size: p.size, color: p.color, images: p.images as string[],
                  }}
                />
              ))}
            </div>
            {latest.length === 0 && (
              <div className="rounded-2xl bg-[#f6f4ee] p-10 text-center text-gray-500">
                <div className="text-5xl">🛁</div>
                <div className="mt-3 font-bold">لا توجد منتجات حالياً</div>
                <Link href="/products" className="mt-4 inline-block rounded-xl gold-bg px-6 py-2.5 font-bold text-[#0b1526]">تصفح المنتجات</Link>
              </div>
            )}

            {/* offers row */}
            {offerProducts.length > 0 && (
              <>
                <div className="mt-7 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="flex h-9 w-9 items-center justify-center rounded-xl gold-bg text-lg">🔥</span>
                    <h2 className="text-xl font-black text-[#0b1526]">العروض الخاصة</h2>
                  </div>
                  <Link href="/offers" className="flex items-center gap-1.5 rounded-full border border-[#0b1526]/12 px-4 py-1.5 text-[13px] font-bold text-[#0b1526] hover:bg-[#0b1526] hover:text-white">
                    عرض الكل ←
                  </Link>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
                  {offerProducts.slice(0, 4).map((p) => (
                    <ProductCard
                      key={p.id}
                      whatsapp={settings.whatsapp}
                      p={{
                        id: p.id, name: p.name, code: p.code, model: p.model, companyName: p.companyName, brand: p.brand,
                        price: p.price, oldPrice: p.oldPrice, discountPrice: p.discountPrice, stock: p.stock,
                        size: p.size, color: p.color, images: p.images as string[],
                      }}
                    />
                  ))}
                </div>
              </>
            )}
          </div>

          {/* sidebar */}
          <aside className="flex flex-col gap-4">
            {banners[0] && (
              <div className="relative overflow-hidden rounded-[22px]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={banners[0].image || "/images/hero-bathroom.jpg"} alt={banners[0].title} className="h-[168px] w-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-l from-[#0b1526]/92 via-[#0b1526]/35 to-transparent" />
                <div className="absolute inset-0 flex flex-col justify-center px-5">
                  <div className="text-lg font-black text-white">{banners[0].title}</div>
                  <div className="mt-1 text-xs text-white/75">{banners[0].subtitle}</div>
                  <Link href="/offers" className="mt-3 w-fit rounded-full gold-bg px-5 py-2 text-xs font-black text-[#0b1526]">تصفح العروض</Link>
                </div>
              </div>
            )}

            <div className="rounded-[22px] border border-[#c9a227]/25 bg-gradient-to-b from-[#12203c] to-[#0b1526] p-5">
              <div className="flex items-center gap-2 text-base font-black text-[#e8c766]">
                <span>🛒</span> تصفح بالباركود السريع
              </div>
              <form action="/search" className="relative mt-3">
                <input
                  name="q"
                  placeholder="اكتب اسم المنتج أو كود المنتج ..."
                  className="w-full rounded-xl border border-white/12 bg-white/[0.07] py-2.5 pe-3 ps-9 text-[12.5px] text-white placeholder:text-white/40 outline-none focus:border-[#c9a227]"
                />
                <button type="submit" aria-label="بحث" className="absolute start-2.5 top-1/2 -translate-y-1/2 text-white/55">🔍</button>
              </form>

              <div className="mt-4 flex items-center gap-2 text-sm font-black text-[#e8c766]">🪧 معلومات المحل</div>
              <div className="mt-2 space-y-2 text-xs text-white/70">
                <div className="flex items-start gap-2"><span>📍</span><span>مصر — {settings.store_name}</span></div>
                <div className="flex items-center gap-2"><span>📞</span><span dir="ltr">{settings.phone}</span></div>
                <div className="flex items-center gap-2"><span>🕘</span><span>من 9 صباحاً إلى 11 مساءً</span></div>
              </div>

              <a
                href={`https://wa.me/${waIntl}?text=${encodeURIComponent("السلام عليكم، أريد الاستفسار عن منتجات " + settings.store_name)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#25D366] py-3 text-sm font-black text-white shadow-[0_10px_26px_rgba(37,211,102,0.35)]"
              >
                💬 تواصل معنا عبر واتساب
              </a>
            </div>

            <div className="rounded-[22px] border border-white/10 bg-white/[0.05] p-5 text-center">
              <Logo size={70} className="mx-auto" />
              <div className="mt-2 text-lg font-black text-white">
                <span className="gold-text">معرض</span> المصطفي
              </div>
              <div className="text-xs text-white/55">للأدوات الصحية والسباكة</div>
              <div className="mt-2 text-xs text-[#e8c766]">إدارة / محمد محمود طلبة</div>
            </div>
          </aside>
        </div>
      </section>

      {/* ── BOTTOM FEATURES ── */}
      <section className="relative overflow-hidden border-y border-[#c9a227]/20 bg-[#060b16] py-8">
        <div className="absolute inset-0 opacity-25" style={{ backgroundImage: "url('/images/showroom-shelf.jpg')", backgroundSize: "cover", backgroundPosition: "center" }} />
        <div className="relative mx-auto grid max-w-[1100px] grid-cols-1 gap-6 px-4 text-center sm:grid-cols-3">
          {[
            ["🛡️", "ضمان على المنتجات", "مع خدمة ما بعد البيع"],
            ["🚚", "توصيل سريع", "لكل المناطق"],
            ["💎", "جودة عالية", "منتجات مضمونة"],
          ].map(([i, t, d]) => (
            <div key={t} className="flex items-center justify-center gap-3">
              <div className="flex h-14 w-14 items-center justify-center rounded-full border-2 border-[#c9a227]/70 bg-[#0b1526] text-2xl">{i}</div>
              <div className="text-right">
                <div className="text-base font-black text-white">{t}</div>
                <div className="text-xs text-white/55">{d}</div>
              </div>
            </div>
          ))}
        </div>
        <div className="relative mt-6 text-center font-lux text-2xl text-[#e8c766]">
          المصطفي .. اختيارك الأفضل
          <svg width="220" height="12" viewBox="0 0 220 12" fill="none" className="mx-auto mt-1">
            <path d="M4 9 C60 1 160 1 216 6" stroke="#c9a227" strokeWidth="2.5" strokeLinecap="round" />
          </svg>
        </div>
      </section>

      {/* ── BRANDS ── */}
      <section className="bg-[#0b1526] py-10">
        <div className="mx-auto max-w-[1320px] px-4">
          <h2 className="text-center text-xl font-black text-white">شركاؤنا من أفضل الشركات</h2>
          <div className="mt-5 flex flex-wrap justify-center gap-3">
            {comps.map((c) => (
              <Link key={c.id} href={`/products?company=${c.slug}`} className="rounded-2xl border border-white/10 bg-white/[0.05] px-6 py-3 font-black text-white/85 transition hover:border-[#c9a227] hover:bg-[#c9a227]/10">
                {c.name}
              </Link>
            ))}
          </div>
        </div>
      </section>

      <Footer s={settings} />
      <FloatingWhatsApp whatsapp={settings.whatsapp} storeName={settings.store_name} />
      <MobileNav />
    </div>
  );
}
