"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import Logo from "@/components/Logo";
import { isStrongPassword, passwordStrength } from "@/lib/utils";

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", phone: "", email: "", address: "", password: "", confirm: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const strength = passwordStrength(form.password);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!isStrongPassword(form.password)) {
      setError("كلمة المرور يجب أن تكون 8 أحرف على الأقل وتضم حروفاً وأرقاماً");
      return;
    }
    if (form.password !== form.confirm) { setError("تأكيد كلمة المرور غير متطابق"); return; }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const j = await res.json();
      if (!j.ok) { setError(j.message); setLoading(false); return; }
      router.push("/account");
    } catch {
      setError("تعذر الاتصال بالخادم، حاول مرة أخرى");
      setLoading(false);
    }
  };

  const F = (k: string, v: string) => setForm((s) => ({ ...s, [k]: v }));

  return (
    <div dir="rtl" className="relative flex min-h-screen w-full overflow-hidden bg-[#060b16]">
      <section className="relative hidden flex-1 lg:block">
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: "url('/images/hero-bathroom.jpg')" }} />
        <div className="absolute inset-0 bg-gradient-to-l from-[#060b16] via-[#0b1526]/75 to-[#060b16]/95" />
        <div className="relative mx-auto flex h-full max-w-[720px] flex-col items-center justify-center px-10 text-center">
          <Logo size={110} className="drop-shadow-[0_10px_40px_rgba(201,162,39,0.55)]" />
          <h1 className="mt-4 text-[54px] font-black leading-[1.3]">
            <span className="gold-text">معرض</span> <span className="text-white">المصطفى</span>
          </h1>
          <div className="mt-1 text-[22px] font-extrabold text-white">للأدوات الصحية والسباكة</div>
          <div className="mt-5 rounded-full border border-[#c9a227]/70 bg-[#0b1526]/70 px-9 py-2 text-base font-bold text-[#e8c766]">
            إدارة &nbsp;<span className="text-white">محمد محمود طلبة</span>
          </div>
          <div className="mt-8 font-lux text-2xl text-[#e8c766]">انضم إلينا .. وابدأ تجربة تسوق فاخرة</div>
          <div className="mt-10 grid w-full grid-cols-3 gap-4">
            {[["🛡️", "ضمان حقيقي"], ["🚚", "توصيل سريع"], ["💰", "أسعار مميزة"]].map(([i, t]) => (
              <div key={t} className="flex flex-col items-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full border-2 border-[#c9a227]/80 bg-[#0b1526]/80 text-2xl">{i}</div>
                <div className="mt-2 text-sm font-bold text-white">{t}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="flex w-full flex-1 items-center justify-center bg-[#060b16] px-4 py-10 lg:max-w-[620px]">
        <div className="relative w-full max-w-[500px] rounded-[28px] border border-[#c9a227]/35 bg-gradient-to-b from-[#12203c] to-[#0a1428] p-8 shadow-[0_30px_90px_-20px_rgba(0,0,0,0.8)]">
          <div className="text-center">
            <div className="text-base font-bold text-white/85">أهلاً بك في</div>
            <h2 className="mt-1 text-[30px] font-black gold-text">معرض المصطفي</h2>
            <p className="mt-2 text-sm text-white/55">أنشئ حسابك — اسم المستخدم ورقم الهاتف لكلمة مرور قوية</p>
            <div className="mx-auto mt-3 h-[3px] w-14 rounded-full gold-bg" />
          </div>

          {error && <div className="mt-5 rounded-2xl border border-red-500/30 bg-red-500/15 px-4 py-3 text-center text-sm font-bold text-red-200">{error}</div>}

          <form onSubmit={submit} className="mt-6 space-y-3">
            {[
              { k: "name", label: "اسم المستخدم / الاسم بالكامل *", ph: "مثال: ahmed.mohamed", icon: "👤" },
              { k: "phone", label: "رقم الهاتف *", ph: "01xxxxxxxxx", icon: "📱" },
              { k: "email", label: "البريد الإلكتروني (اختياري)", ph: "name@mail.com", icon: "✉️" },
              { k: "address", label: "العنوان (اختياري)", ph: "المحافظة — المدينة", icon: "📍" },
            ].map((f) => (
              <div key={f.k}>
                <label className="text-xs font-bold text-white/70">{f.label}</label>
                <div className="relative mt-1">
                  <span className="absolute inset-y-0 right-4 flex items-center text-white/45">{f.icon}</span>
                  <input
                    required={f.k === "name" || f.k === "phone"}
                    value={(form as any)[f.k]}
                    onChange={(e) => F(f.k, e.target.value)}
                    placeholder={f.ph}
                    className="w-full rounded-2xl border border-white/12 bg-white/[0.07] py-3.5 pr-12 pl-4 text-white placeholder:text-white/35 outline-none focus:border-[#c9a227]"
                  />
                </div>
              </div>
            ))}

            <div>
              <label className="text-xs font-bold text-white/70">كلمة المرور (8 أحرف وأرقام على الأقل) *</label>
              <div className="relative mt-1">
                <span className="absolute inset-y-0 right-4 flex items-center text-white/45">🔒</span>
                <input
                  required
                  type={showPw ? "text" : "password"}
                  value={form.password}
                  onChange={(e) => F("password", e.target.value)}
                  placeholder="كلمة قوية: أحرف + أرقام"
                  className="w-full rounded-2xl border border-white/12 bg-white/[0.07] py-3.5 pr-12 pl-12 text-white placeholder:text-white/35 outline-none focus:border-[#c9a227]"
                />
                <button type="button" onClick={() => setShowPw(!showPw)} className="absolute inset-y-0 left-4 text-white/45 hover:text-[#e8c766]">
                  {showPw ? "🙈" : "👁"}
                </button>
              </div>
              {form.password && (
                <div className="mt-2">
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                    <div className="h-full rounded-full transition-all" style={{ width: `${(strength.score + 1) * 25}%`, background: strength.color }} />
                  </div>
                  <div className="mt-1 text-[11px] font-bold" style={{ color: strength.color }}>
                    قوة كلمة المرور: {strength.label}
                  </div>
                </div>
              )}
            </div>

            <div>
              <label className="text-xs font-bold text-white/70">تأكيد كلمة المرور *</label>
              <div className="relative mt-1">
                <span className="absolute inset-y-0 right-4 flex items-center text-white/45">🔒</span>
                <input required type="password" value={form.confirm} onChange={(e) => F("confirm", e.target.value)} placeholder="أعد كتابة كلمة المرور" className="w-full rounded-2xl border border-white/12 bg-white/[0.07] py-3.5 pr-12 pl-4 text-white placeholder:text-white/35 outline-none focus:border-[#c9a227]" />
              </div>
            </div>

            <button
              disabled={loading}
              className="w-full rounded-2xl py-4 text-lg font-black text-[#0b1526] shadow-[0_10px_30px_rgba(201,162,39,0.35)] transition hover:brightness-110 disabled:opacity-50"
              style={{ background: "linear-gradient(135deg,#f3dc92,#c9a227 45%,#e8c766 70%,#b98f1c)" }}
            >
              {loading ? "⏳ جاري إنشاء الحساب…" : "إنشاء الحساب ←"}
            </button>
          </form>

          <div className="mt-5 text-center text-sm text-white/60">
            لديك حساب بالفعل؟ <Link href="/login" className="font-bold text-[#e8c766] hover:underline">تسجيل الدخول</Link>
          </div>
          <div className="mt-3 flex items-center justify-center gap-2 text-xs text-white/45">🔒 أمان .. موقع معرض المصطفي</div>
        </div>
      </section>
    </div>
  );
}
