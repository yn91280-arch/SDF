"use client";
import { useEffect, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import AdminShell, { Panel, inputCls, btnGold, btnDark } from "@/components/AdminShell";
import { formatPrice } from "@/lib/utils";

function Body() {
  const sp = useSearchParams();
  const [comps, setComps] = useState<any[]>([]);
  const [companyId, setCompanyId] = useState(sp.get("company") || "");
  const [companyName, setCompanyName] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState<any>(null);
  const [lists, setLists] = useState<any[]>([]);
  const [msg, setMsg] = useState("");
  const [filter, setFilter] = useState("all");
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [applying, setApplying] = useState(false);

  useEffect(() => {
    fetch("/api/admin/companies").then((r) => r.json()).then((j) => { if (j.ok) setComps(j.companies); }).catch(() => {});
    fetch("/api/admin/import").then((r) => r.json()).then((j) => { if (j.ok) setLists(j.lists); }).catch(() => {});
  }, []);

  const parse = async () => {
    setMsg(""); setPreview(null);
    if (!file) { setMsg("اختر ملف Excel أو CSV أولاً"); return; }
    setLoading(true);
    const fd = new FormData();
    fd.append("file", file);
    if (companyId) fd.append("companyId", companyId);
    if (companyName) fd.append("companyName", companyName);
    const res = await fetch("/api/admin/import", { method: "POST", body: fd });
    const j = await res.json();
    setLoading(false);
    if (!j.ok) { setMsg(j.message); return; }
    setPreview(j);
    setSelected(new Set(j.items.map((_: any, i: number) => i)));
  };

  const viewList = async (id: number) => {
    const res = await fetch(`/api/admin/import/apply?id=${id}`);
    const j = await res.json();
    if (j.ok) {
      setPreview({ list: j.list, items: j.items.map((it: any) => ({ ...it, price: Number(it.price) })), totalParsed: j.items.length, fromDb: true });
      setSelected(new Set());
    }
  };

  const apply = async (mode: string, confirmMajor = false) => {
    if (!preview) return;
    setApplying(true); setMsg("");
    const ids = preview.fromDb
      ? preview.items.filter((_: any, i: number) => selected.has(i)).map((it: any) => it.id)
      : undefined;
    const res = await fetch("/api/admin/import/apply", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        listId: preview.list.id, mode: preview.fromDb ? "selected" : mode,
        selectedIds: ids, updatePrices: true, createNew: true, confirmMajor,
      }),
    });
    const j = await res.json();
    setApplying(false);
    if (!j.ok) {
      if (j.requireConfirm && confirm(`سيتم تطبيق ${j.count} صنف — هل أنت متأكد؟`)) {
        apply(mode, true);
        return;
      }
      setMsg(j.message); return;
    }
    setMsg(`✅ تم: إنشاء ${j.created} منتج جديد • تحديث ${j.updated} سعر • متبقي ${j.remaining}`);
    fetch("/api/admin/import").then((r) => r.json()).then((x) => { if (x.ok) setLists(x.lists); }).catch(() => {});
  };

  const items = preview?.items || [];
  const filtered = items.filter((it: any) => filter === "all" ? true : it.matchStatus === filter);

  return (
    <AdminShell title="استيراد قوائم الأسعار 📥">
      <div className="grid gap-4 lg:grid-cols-3">
        <Panel title="📤 رفع قائمة جديدة">
          <div className="space-y-3">
            <div>
              <label className="text-xs text-white/60">الشركة (اختياري)</label>
              <select value={companyId} onChange={(e) => setCompanyId(e.target.value)} className={inputCls}>
                <option value="">— اختر الشركة —</option>
                {comps.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <input value={companyName} onChange={(e) => setCompanyName(e.target.value)} placeholder="أو اكتب اسم الشركة يدوياً" className={inputCls} />
            <input type="file" accept=".xlsx,.xls,.csv,.txt" onChange={(e) => setFile(e.target.files?.[0] || null)} className="w-full text-sm text-white/70" />
            {file && <div className="text-xs text-white/50">📄 {file.name} ({(file.size / 1024).toFixed(0)} KB)</div>}
            <button onClick={parse} disabled={loading} className={`${btnGold} w-full`}>{loading ? "⏳ جاري التحليل…" : "🔍 تحليل وعرض المعاينة"}</button>
            {msg && <div className="rounded-xl bg-white/5 p-3 text-xs">{msg}</div>}
            <div className="rounded-xl bg-white/5 p-3 text-[11px] leading-6 text-white/50">
              المدعوم: Excel (.xlsx) و CSV حتى 10MB و 2000 صنف.<br />
              يجب أن يحتوي الملف على عمود السعر + الاسم أو الكود.<br />
              PDF والصور: حوّلها إلى Excel أولاً.
            </div>
          </div>
        </Panel>
        <div className="lg:col-span-2">
          <Panel title={`القوائم السابقة (${lists.length})`}>
            <div className="max-h-40 space-y-1 overflow-y-auto">
              {lists.map((l: any) => (
                <div key={l.id} className="flex items-center justify-between rounded-xl bg-white/5 px-3 py-2 text-xs">
                  <div>
                    <span className="font-bold">#{l.id} {l.fileName}</span>
                    <span className="ms-2 text-white/50">{l.companyName} • {l.totalItems} صنف • 🆕{l.newCount} 🔄{l.existingCount} ⚠️{l.reviewCount}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`rounded-full px-2 py-0.5 ${l.status === "applied" ? "bg-emerald-600/20 text-emerald-400" : "bg-amber-600/20 text-amber-400"}`}>{l.status}</span>
                    <button onClick={() => viewList(l.id)} className="rounded-lg bg-white/10 px-2 py-1">عرض</button>
                  </div>
                </div>
              ))}
              {lists.length === 0 && <div className="text-xs text-white/40">لا توجد قوائم بعد</div>}
            </div>
          </Panel>
        </div>
      </div>

      {preview && (
        <div className="mt-4">
          <Panel
            title={`معاينة الاستيراد: ${preview.list.fileName} (${preview.totalParsed} صنف)`}
            action={
              <div className="flex flex-wrap gap-1">
                {!preview.fromDb && (
                  <>
                    <button onClick={() => apply("new")} disabled={applying} className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-bold">إنشاء الجديد فقط</button>
                    <button onClick={() => apply("existing")} disabled={applying} className="rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-bold">تحديث الموجود فقط</button>
                    <button onClick={() => apply("all")} disabled={applying} className="rounded-lg gold-bg px-3 py-1.5 text-xs font-black text-[#0b1526]">تطبيق الكل</button>
                  </>
                )}
                {preview.fromDb && (
                  <button onClick={() => apply("selected")} disabled={applying || selected.size === 0} className="rounded-lg gold-bg px-3 py-1.5 text-xs font-black text-[#0b1526]">تطبيق المحدد ({selected.size})</button>
                )}
              </div>
            }
          >
            <div className="mb-3 flex flex-wrap gap-2 text-xs">
              <span className="rounded-full bg-emerald-600/20 px-3 py-1 text-emerald-400">🆕 جديد: {preview.list.newCount}</span>
              <span className="rounded-full bg-blue-600/20 px-3 py-1 text-blue-400">🔄 موجود: {preview.list.existingCount}</span>
              <span className="rounded-full bg-amber-600/20 px-3 py-1 text-amber-400">⚠️ مراجعة: {preview.list.reviewCount}</span>
              <select value={filter} onChange={(e) => setFilter(e.target.value)} className="rounded-full border border-white/15 bg-white/10 px-3 py-1">
                <option value="all">عرض الكل</option>
                <option value="new">جديد فقط</option>
                <option value="existing">موجود فقط</option>
                <option value="review">يحتاج مراجعة</option>
              </select>
            </div>
            {applying && <div className="mb-2 text-sm text-[#e8c766]">⏳ جاري التطبيق…</div>}
            <div className="max-h-[500px] overflow-auto">
              <table className="w-full min-w-[700px] text-xs">
                <thead className="sticky top-0 bg-[#0b1526]">
                  <tr className="text-right text-white/50">
                    {preview.fromDb && <th className="p-2">✓</th>}
                    <th className="p-2">الحالة</th><th className="p-2">الاسم</th><th className="p-2">الكود</th>
                    <th className="p-2">الموديل</th><th className="p-2">المقاس</th><th className="p-2">السعر الجديد</th><th className="p-2">السعر الحالي</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.slice(0, 300).map((it: any, i: number) => (
                    <tr key={i} className="border-b border-white/5">
                      {preview.fromDb && (
                        <td className="p-2">
                          <input type="checkbox" checked={selected.has(items.indexOf(it))} disabled={it.isApplied} onChange={(e) => {
                            const idx = items.indexOf(it);
                            const s = new Set(selected);
                            if (e.target.checked) s.add(idx); else s.delete(idx);
                            setSelected(s);
                          }} />
                        </td>
                      )}
                      <td className="p-2">
                        {it.matchStatus === "new" && <span className="rounded-full bg-emerald-600/20 px-2 py-0.5 text-emerald-400">جديد</span>}
                        {it.matchStatus === "existing" && <span className="rounded-full bg-blue-600/20 px-2 py-0.5 text-blue-400">موجود</span>}
                        {it.matchStatus === "review" && <span className="rounded-full bg-amber-600/20 px-2 py-0.5 text-amber-400">مراجعة</span>}
                        {it.isApplied && <span className="ms-1 text-emerald-400">✓</span>}
                      </td>
                      <td className="p-2">{it.name}</td>
                      <td className="p-2 font-mono" dir="ltr">{it.code}</td>
                      <td className="p-2">{it.model}</td>
                      <td className="p-2">{it.size}</td>
                      <td className="p-2 font-bold text-[#e8c766]">{formatPrice(it.price)}</td>
                      <td className="p-2 text-white/50">{it.matchedPrice ? formatPrice(it.matchedPrice) : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {filtered.length > 300 && <div className="p-3 text-center text-xs text-white/40">يعرض أول 300 من {filtered.length} — ضيّق الفلتر للمراجعة</div>}
            </div>
          </Panel>
        </div>
      )}
    </AdminShell>
  );
}

export default function ImportPage() {
  return <Suspense fallback={<div>…</div>}><Body /></Suspense>;
}
