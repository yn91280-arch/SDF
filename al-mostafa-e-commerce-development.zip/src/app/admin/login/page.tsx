"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function AdminLoginPage() {
  const router = useRouter();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(""); setLoading(true);
    try {
      const res = await fetch("/api/admin/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      const j = await res.json();
      if (!j.ok) { setError(j.message); setLoading(false); return; }
      router.push("/admin");
    } catch { setError("حدث خطأ، حاول مرة أخرى"); }
    setLoading(false);
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#060b16] p-4" dir="rtl">
      <div className="absolute inset-0 hero-pattern" />
      <div className="relative w-full max-w-md">
        <div className="rounded-3xl border border-[#c9a227]/30 bg-[#0b1526] p-8 shadow-2xl">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl gold-bg text-3xl font-black text-[#0b1526]">م</div>
          <h1 className="mt-4 text-center text-2xl font-black text-white">لوحة الإدارة 🔒</h1>
          <p className="mt-1 text-center text-sm text-white/50">معرض المصطفي — دخول المدراء فقط</p>
          {error && <div className="mt-4 rounded-xl bg-red-600/15 p-3 text-sm font-bold text-red-400">{error}</div>}
          <form onSubmit={submit} className="mt-6 space-y-4">
            <div>
              <label className="text-sm font-bold text-white/80">البريد الإلكتروني</label>
              <input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} dir="ltr" className="mt-1 w-full rounded-xl border border-white/15 bg-white/10 px-4 py-3 text-white outline-none placeholder:text-white/30 focus:border-[#c9a227]" placeholder="admin@example.com" />
            </div>
            <div>
              <label className="text-sm font-bold text-white/80">كلمة المرور</label>
              <input required type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} className="mt-1 w-full rounded-xl border border-white/15 bg-white/10 px-4 py-3 text-white outline-none focus:border-[#c9a227]" placeholder="••••••••" />
            </div>
            <button disabled={loading} className="w-full rounded-2xl gold-bg py-3.5 font-black text-[#0b1526] disabled:opacity-50">
              {loading ? "⏳ جاري التحقق…" : "🔓 دخول آمن"}
            </button>
          </form>
          <p className="mt-4 text-center text-[11px] text-white/30">محمي بنظام منع التخمين — جميع المحاولات مسجلة</p>
        </div>
      </div>
    </div>
  );
}
