"use client";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import AdminShell, { Panel, inputCls, btnGold, btnGoldStyle, btnDark } from "@/components/AdminShell";
import { getInvoiceTemplate, INVOICE_TEMPLATE_LIST } from "@/components/invoice/InvoiceTemplate";
import { formatPrice, generateInvoiceNumber, isStrongPassword } from "@/lib/utils";

export default function NewInvoicePage() {
  const router = useRouter();
  const [num, setNum] = useState("");
  const [date, setDate] = useState("");
  const [templateId, setTemplateId] = useState("classic");
  const [cust, setCust] = useState({ customerName: "", customerPhone: "", customerAddress: "", notes: "" });
  const [rows, setRows] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const [results, setResults] = useState<any[]>([]);
  const [tax, setTax] = useState(0);
  const [extra, setExtra] = useState(0);
  const [paid, setPaid] = useState(0);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");
  const [saved, setSaved] = useState<any>(null);

  useEffect(() => {
    setNum(generateInvoiceNumber());
    setDate(new Date().toISOString().slice(0, 10));
    fetch("/api/admin/settings").then((r) => r.json()).then((j) => {
      if (j.ok && j.settings?.tax_enabled === "1") setTax(Number(j.settings.tax_percent) || 0);
    }).catch(() => {});
  }, []);

  useEffect(() => {
    if (!q.trim()) { setResults([]); return; }
    const t = setTimeout(() => {
      fetch(`/api/admin/products?q=${encodeURIComponent(q)}&limit=8`).then((r) => r.json()).then((j) => { if (j.ok) setResults(j.products); }).catch(() => {});
    }, 280);
    return () => clearTimeout(t);
  }, [q]);

  const add = (p: any) => {
    setRows((r) => [
      ...r,
      {
        productId: p.id, productName: p.name, productCode: p.code,
        quantity: 1, price: Number(p.discountPrice && Number(p.discountPrice) > 0 ? p.discountPrice : p.price),
        discount: 0,
      },
    ]);
    setQ(""); setResults([]);
  };

  const subtotal = useMemo(() => rows.reduce((s, r) => s + r.price * r.quantity, 0), [rows]);
  const rowDiscount = useMemo(() => rows.reduce((s, r) => s + (Number(r.discount) || 0), 0), [rows]);
  const taxValue = (subtotal - rowDiscount) * (tax / 100);
  const total = Math.max(0, subtotal - rowDiscount + taxValue + extra);
  const remaining = Math.max(0, total - paid);

  const Template = getInvoiceTemplate(templateId);
  const previewData = {
    invoice: {
      id: 0, invoiceNumber: num, ...cust,
      subtotal, discount: rowDiscount, tax: taxValue, extraCharges: extra,
      total, paid, remaining,
      status: remaining <= 0 ? "paid" : paid > 0 ? "partial" : "unpaid",
      createdAt: date || new Date().toISOString(),
    },
    items: rows,
    settings: { store_name: "معرض المصطفي", phone: "01147104601", whatsapp: "01147104601", manager: "إدارة / محمد محمود طلبة", invoice_notes: cust.notes },
  };

  const save = async (then: "print" | "none" = "none") => {
    if (!cust.customerName.trim()) { setMsg("أدخل اسم العميل"); return; }
    if (rows.length === 0) { setMsg("أضف منتجاً واحداً على الأقل"); return; }
    setSaving(true); setMsg("");
    const res = await fetch("/api/admin/invoices", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        invoiceNumber: num, templateId, ...cust,
        items: rows, tax: taxValue, extraCharges: extra, paid, deductStock: true,
      }),
    });
    const j = await res.json();
    setSaving(false);
    if (!j.ok) { setMsg(j.message); return; }
    setSaved(j.invoice);
    setMsg(`✅ تم حفظ الفاتورة ${j.invoice.invoiceNumber}`);
    if (then === "print") setTimeout(() => window.print(), 350);
    else setTimeout(() => router.push(`/admin/invoices/${j.invoice.id}`), 700);
  };

  const share = () => {
    const text = `🧾 فاتورة ${num}\nالعميل: ${cust.customerName}\nالإجمالي: ${total} ج.م\nالمدفوع: ${paid} ج.م\nالمتبقي: ${remaining} ج.م\n🏪 معرض المصطفي`;
    window.open(`https://wa.me/201147104601?text=${encodeURIComponent(text)}`, "_blank");
  };

  return (
    <AdminShell title="إنشاء فاتورة جديدة" noPad>
      <div className="grid gap-4 p-4 sm:p-6 xl:grid-cols-[1fr_520px]">
        {/* ── left: data entry ── */}
        <div className="space-y-4">
          <Panel title="🧾 بيانات الفاتورة">
            <div className="grid gap-3 sm:grid-cols-3">
              <div>
                <label className="text-xs text-white/55">رقم الفاتورة</label>
                <input value={num} onChange={(e) => setNum(e.target.value)} className={inputCls} dir="ltr" />
              </div>
              <div>
                <label className="text-xs text-white/55">التاريخ</label>
                <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputCls} dir="ltr" />
              </div>
              <div>
                <label className="text-xs text-white/55">القالب</label>
                <select value={templateId} onChange={(e) => setTemplateId(e.target.value)} className={inputCls}>
                  {INVOICE_TEMPLATE_LIST.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
              </div>
            </div>
          </Panel>

          <Panel title="👤 بيانات العميل">
            <div className="grid gap-3 sm:grid-cols-2">
              <input value={cust.customerName} onChange={(e) => setCust({ ...cust, customerName: e.target.value })} placeholder="اسم العميل *" className={inputCls} />
              <input value={cust.customerPhone} onChange={(e) => setCust({ ...cust, customerPhone: e.target.value })} placeholder="رقم الهاتف" dir="ltr" className={inputCls} />
              <input value={cust.customerAddress} onChange={(e) => setCust({ ...cust, customerAddress: e.target.value })} placeholder="العنوان" className={`${inputCls} sm:col-span-2`} />
              <textarea value={cust.notes} onChange={(e) => setCust({ ...cust, notes: e.target.value })} placeholder="ملاحظات" rows={2} className={`${inputCls} sm:col-span-2`} />
            </div>
          </Panel>

          <Panel title="🛍 إضافة المنتجات">
            <div className="relative">
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="ابحث بالاسم أو الكود أو الموديل ..." className={`${inputCls} ps-10`} />
              <span className="absolute start-3 top-1/2 -translate-y-1/2 text-white/40">🔍</span>
              {results.length > 0 && (
                <div className="absolute z-30 mt-1 max-h-64 w-full overflow-y-auto rounded-xl border border-white/12 bg-[#0b1526] shadow-2xl">
                  {results.map((p) => (
                    <button key={p.id} onClick={() => add(p)} className="block w-full px-3 py-2 text-right hover:bg-white/10">
                      <div className="text-sm font-bold">{p.name}</div>
                      <div className="text-xs text-white/45" dir="ltr">{p.code} • {p.model || "—"} • {p.price} ج.م • مخزون {p.stock}</div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="mt-3 overflow-x-auto">
              <table className="w-full min-w-[640px] text-[12.5px]">
                <thead>
                  <tr className="border-b border-white/10 text-right text-white/45">
                    <th className="p-2">المنتج</th>
                    <th className="p-2">الكود</th>
                    <th className="p-2">الكمية</th>
                    <th className="p-2">السعر</th>
                    <th className="p-2">الخصم</th>
                    <th className="p-2">الإجمالي</th>
                    <th className="p-2" />
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r, i) => (
                    <tr key={i} className="border-b border-white/5">
                      <td className="p-2 font-bold">{r.productName}</td>
                      <td className="p-2 font-mono text-white/55" dir="ltr">{r.productCode}</td>
                      <td className="p-2">
                        <input type="number" min={1} value={r.quantity} onChange={(e) => {
                          const v = [...rows]; v[i].quantity = Math.max(1, Number(e.target.value) || 1); setRows(v);
                        }} className="w-16 rounded-lg border border-white/12 bg-white/8 px-2 py-1 text-center text-white" />
                      </td>
                      <td className="p-2">
                        <input type="number" min={0} value={r.price} onChange={(e) => {
                          const v = [...rows]; v[i].price = Math.max(0, Number(e.target.value) || 0); setRows(v);
                        }} className="w-24 rounded-lg border border-white/12 bg-white/8 px-2 py-1 text-white" />
                      </td>
                      <td className="p-2">
                        <input type="number" min={0} value={r.discount} onChange={(e) => {
                          const v = [...rows]; v[i].discount = Math.max(0, Number(e.target.value) || 0); setRows(v);
                        }} className="w-20 rounded-lg border border-white/12 bg-white/8 px-2 py-1 text-white" />
                      </td>
                      <td className="p-2 font-bold text-[#e8c766]">{formatPrice(Math.max(0, r.price * r.quantity - (r.discount || 0)))}</td>
                      <td className="p-2">
                        <button onClick={() => setRows(rows.filter((_, x) => x !== i))} className="text-red-400 hover:text-red-300">🗑</button>
                      </td>
                    </tr>
                  ))}
                  {rows.length === 0 && (
                    <tr><td colSpan={7} className="p-6 text-center text-white/35">ابحث عن منتج وأضفه للفاتورة</td></tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="mt-4 grid gap-3 sm:grid-cols-3">
              <div>
                <label className="text-xs text-white/55">الضريبة %</label>
                <input type="number" value={tax} onChange={(e) => setTax(Math.max(0, Number(e.target.value) || 0))} className={inputCls} dir="ltr" />
              </div>
              <div>
                <label className="text-xs text-white/55">رسوم إضافية</label>
                <input type="number" value={extra} onChange={(e) => setExtra(Math.max(0, Number(e.target.value) || 0))} className={inputCls} dir="ltr" />
              </div>
              <div>
                <label className="text-xs text-white/55">المبلغ المدفوع</label>
                <input type="number" value={paid} onChange={(e) => setPaid(Math.max(0, Number(e.target.value) || 0))} className={inputCls} dir="ltr" />
              </div>
            </div>

            <div className="mt-4 rounded-2xl border border-white/10 bg-white/[0.04] p-4 text-sm">
              <div className="flex justify-between text-white/65"><span>المجموع الفرعي</span><span>{formatPrice(subtotal)}</span></div>
              <div className="flex justify-between text-white/65"><span>الخصم</span><span>− {formatPrice(rowDiscount)}</span></div>
              {taxValue > 0 && <div className="flex justify-between text-white/65"><span>الضريبة</span><span>{formatPrice(taxValue)}</span></div>}
              {extra > 0 && <div className="flex justify-between text-white/65"><span>رسوم إضافية</span><span>{formatPrice(extra)}</span></div>}
              <div className="mt-2 flex justify-between text-lg font-black text-white"><span>الإجمالي</span><span className="gold-text">{formatPrice(total)}</span></div>
              <div className="flex justify-between text-white/65"><span>المدفوع</span><span>{formatPrice(paid)}</span></div>
              <div className="flex justify-between font-bold text-white"><span>المتبقي</span><span className="text-[#e8c766]">{formatPrice(remaining)}</span></div>
            </div>

            {msg && <div className="mt-3 rounded-xl bg-white/8 px-4 py-2.5 text-sm">{msg}</div>}

            <div className="mt-4 flex flex-wrap gap-2">
              <button onClick={() => save("none")} disabled={saving} className={btnGold} style={btnGoldStyle}>💾 حفظ الفاتورة</button>
              <button onClick={() => save("print")} disabled={saving} className={btnGold} style={btnGoldStyle}>🖨 طباعة</button>
              <button onClick={() => { if (!saved) save("print"); else window.print(); }} className={btnDark}>⬇ تحميل PDF</button>
              <button onClick={share} className={btnDark}>💬 مشاركة</button>
            </div>
          </Panel>
        </div>

        {/* ── right: live preview ── */}
        <div className="xl:sticky xl:top-24 xl:h-fit">
          <div className="mb-2 text-sm font-bold text-white/70">معاينة الفاتورة (القالب: {INVOICE_TEMPLATE_LIST.find((t) => t.id === templateId)?.name})</div>
          <div className="overflow-hidden rounded-2xl bg-white shadow-2xl">
            <Template {...previewData} />
          </div>
        </div>
      </div>
    </AdminShell>
  );
}
