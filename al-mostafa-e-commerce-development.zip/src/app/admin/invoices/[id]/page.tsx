"use client";
import { useEffect, useState } from "react";
import { useParams, useSearchParams } from "next/navigation";
import Link from "next/link";
import AdminShell, { Panel, inputCls, btnGold, btnGoldStyle, btnDark } from "@/components/AdminShell";
import { getInvoiceTemplate, INVOICE_TEMPLATE_LIST } from "@/components/invoice/InvoiceTemplate";
import { formatPrice, INVOICE_STATUS_AR } from "@/lib/utils";

export default function InvoiceDetailPage() {
  const { id } = useParams<{ id: string }>();
  const sp = useSearchParams();
  const [data, setData] = useState<any>(null);
  const [paid, setPaid] = useState(0);
  const [template, setTemplate] = useState("classic");
  const [msg, setMsg] = useState("");
  const [editing, setEditing] = useState(sp.get("edit") === "1");

  const load = () => {
    fetch(`/api/admin/invoices/${id}`).then((r) => r.json()).then((j) => {
      if (j.ok) {
        setData(j);
        setPaid(Number(j.invoice.paid));
        setTemplate(j.invoice.templateId || "classic");
      }
    }).catch(() => {});
  };
  useEffect(load, [id]);

  if (!data) return <AdminShell title="الفاتورة"><div className="p-6 text-white/50">جاري التحميل…</div></AdminShell>;

  const { invoice, items, settings } = data;
  const Template = getInvoiceTemplate(template);

  const save = async () => {
    const res = await fetch("/api/admin/invoices", {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: Number(id), paid }),
    });
    const j = await res.json();
    setMsg(j.ok ? "✅ تم تحديث الفاتورة" : j.message);
    if (j.ok) { load(); setEditing(false); }
    setTimeout(() => setMsg(""), 3000);
  };

  const share = () => {
    const text = `🧾 فاتورة ${invoice.invoiceNumber}\nالعميل: ${invoice.customerName}\nالإجمالي: ${invoice.total} ج.م\nالمدفوع: ${invoice.paid} ج.م\nالمتبقي: ${invoice.remaining} ج.م\n🏪 ${settings.store_name || "معرض المصطفي"}`;
    window.open(`https://wa.me/201147104601?text=${encodeURIComponent(text)}`, "_blank");
  };

  return (
    <AdminShell title={`الفاتورة ${invoice.invoiceNumber}`} noPad>
      <div className="p-4 sm:p-6">
        <div className="mb-4 flex flex-wrap items-center gap-2 print-hidden">
          <Link href="/admin/invoices" className={btnDark}>→ عودة للفواتير</Link>
          <button onClick={() => window.print()} className={btnGold} style={btnGoldStyle}>🖨 طباعة</button>
          <button onClick={() => window.print()} className={btnDark} title="استخدم خيار «حفظ كـ PDF» في نافذة الطباعة">⬇ تحميل PDF</button>
          <button onClick={share} className={btnDark}>💬 مشاركة</button>
          <select value={template} onChange={(e) => setTemplate(e.target.value)} className={`${inputCls} max-w-[200px]`}>
            {INVOICE_TEMPLATE_LIST.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
          <button onClick={() => setEditing(!editing)} className={btnDark}>✏️ تعديل الدفع</button>
          <span className={`rounded-full px-3 py-1.5 text-xs font-bold ${
            invoice.status === "paid" ? "bg-emerald-600/20 text-emerald-300" : invoice.status === "partial" ? "bg-amber-500/20 text-amber-300" : "bg-red-600/20 text-red-300"
          }`}>
            {INVOICE_STATUS_AR[invoice.status] || invoice.status}
          </span>
        </div>

        {msg && <div className="mb-3 rounded-xl bg-white/8 px-4 py-2.5 text-sm print-hidden">{msg}</div>}

        {editing && (
          <Panel title="تحديث المبلغ المدفوع">
            <div className="flex flex-wrap items-end gap-3">
              <div>
                <label className="text-xs text-white/55">المدفوع</label>
                <input type="number" value={paid} onChange={(e) => setPaid(Math.max(0, Number(e.target.value) || 0))} className={`${inputCls} w-40`} dir="ltr" />
              </div>
              <button onClick={save} className={btnGold} style={btnGoldStyle}>💾 حفظ</button>
              <div className="text-sm text-white/60">
                المتبقي: <b className="text-[#e8c766]">{formatPrice(Math.max(0, Number(invoice.total) - paid))}</b>
              </div>
            </div>
          </Panel>
        )}

        <div className="mt-4 overflow-hidden rounded-2xl bg-white shadow-2xl print-full">
          <Template
            invoice={{ ...invoice, createdAt: invoice.createdAt }}
            items={items}
            settings={settings}
          />
        </div>
      </div>
    </AdminShell>
  );
}
