"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import AdminShell, { Panel, inputCls, btnDark, btnGold, btnGoldStyle } from "@/components/AdminShell";
import { formatPrice, formatDateTime, INVOICE_STATUS_AR } from "@/lib/utils";

export default function InvoicesPage() {
  const [invoices, setInvoices] = useState<any[]>([]);
  const [sums, setSums] = useState<any>(null);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);

  const load = () => {
    const p = new URLSearchParams({ page: String(page), limit: "20", q, status, from, to });
    fetch(`/api/admin/invoices?${p}`).then((r) => r.json()).then((j) => {
      if (j.ok) { setInvoices(j.invoices); setSums(j.sums); setPages(j.pagination.pages || 1); }
    }).catch(() => {});
  };
  useEffect(load, [page, status, from, to]);
  useEffect(() => {
    const t = setTimeout(() => { setPage(1); load(); }, 400);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  const del = async (id: number) => {
    if (!confirm("حذف هذه الفاتورة نهائياً؟")) return;
    await fetch(`/api/admin/invoices?id=${id}`, { method: "DELETE" });
    load();
  };

  const exportCsv = () => {
    const head = ["رقم الفاتورة", "العميل", "الهاتف", "التاريخ", "الإجمالي", "المدفوع", "المتبقي", "الحالة"];
    const body = invoices.map((i) => [i.invoiceNumber, i.customerName, i.customerPhone, new Date(i.createdAt).toLocaleDateString("en-GB"), i.total, i.paid, i.remaining, INVOICE_STATUS_AR[i.status] || i.status]);
    const csv = "\uFEFF" + [head, ...body].map((r) => r.map((c) => `"${String(c ?? "")}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const a = document.createElement("a");
    a.href = url; a.download = `invoices-${Date.now()}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <AdminShell title="الفواتير 🧾">
      <div className="mb-4 grid gap-3 sm:grid-cols-4">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔍 بحث برقم الفاتورة / العميل…" className={inputCls} />
        <select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }} className={inputCls}>
          <option value="">كل الحالات</option>
          <option value="unpaid">غير مدفوعة</option>
          <option value="partial">مدفوعة جزئياً</option>
          <option value="paid">مدفوعة</option>
        </select>
        <input type="date" value={from} onChange={(e) => { setFrom(e.target.value); setPage(1); }} className={inputCls} dir="ltr" />
        <input type="date" value={to} onChange={(e) => { setTo(e.target.value); setPage(1); }} className={inputCls} dir="ltr" />
      </div>

      <div className="mb-4 flex flex-wrap gap-2">
        <Link href="/admin/invoices/new" className={btnGold} style={btnGoldStyle}>➕ إنشاء فاتورة</Link>
        <button onClick={exportCsv} className={btnDark}>⬇ تصدير CSV</button>
        <button onClick={() => window.print()} className={btnDark}>🖨 طباعة القائمة</button>
      </div>

      {sums && (
        <div className="mb-4 grid gap-3 sm:grid-cols-3">
          <div className="rounded-2xl border border-white/8 bg-white/5 p-4">
            <div className="text-xs text-white/55">إجمالي الفواتير</div>
            <div className="text-xl font-black text-white">{formatPrice(sums.t)}</div>
          </div>
          <div className="rounded-2xl border border-white/8 bg-white/5 p-4">
            <div className="text-xs text-white/55">المحصل</div>
            <div className="text-xl font-black text-emerald-400">{formatPrice(sums.p)}</div>
          </div>
          <div className="rounded-2xl border border-white/8 bg-white/5 p-4">
            <div className="text-xs text-white/55">المتبقي</div>
            <div className="text-xl font-black text-red-400">{formatPrice(sums.r)}</div>
          </div>
        </div>
      )}

      <Panel title={`قائمة الفواتير (${invoices.length})`}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[860px] text-[13px]">
            <thead>
              <tr className="border-b border-white/10 text-right text-white/45">
                <th className="p-2.5">رقم الفاتورة</th>
                <th className="p-2.5">العميل</th>
                <th className="p-2.5">التاريخ</th>
                <th className="p-2.5">الإجمالي</th>
                <th className="p-2.5">المدفوع</th>
                <th className="p-2.5">المتبقي</th>
                <th className="p-2.5">الحالة</th>
                <th className="p-2.5">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {invoices.map((i) => (
                <tr key={i.id} className="border-b border-white/5 hover:bg-white/[0.04]">
                  <td className="p-2.5 font-mono text-[#e8c766]" dir="ltr">{i.invoiceNumber}</td>
                  <td className="p-2.5 font-bold">{i.customerName}</td>
                  <td className="p-2.5 text-white/55">{formatDateTime(i.createdAt)}</td>
                  <td className="p-2.5 font-bold">{formatPrice(i.total)}</td>
                  <td className="p-2.5 text-emerald-400">{formatPrice(i.paid)}</td>
                  <td className="p-2.5 text-red-400">{formatPrice(i.remaining)}</td>
                  <td className="p-2.5">
                    <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${
                      i.status === "paid" ? "bg-emerald-600/20 text-emerald-300" : i.status === "partial" ? "bg-amber-500/20 text-amber-300" : "bg-red-600/20 text-red-300"
                    }`}>
                      {INVOICE_STATUS_AR[i.status] || i.status}
                    </span>
                  </td>
                  <td className="p-2.5">
                    <div className="flex gap-1">
                      <Link href={`/admin/invoices/${i.id}`} className="rounded-lg bg-white/8 px-2 py-1 text-xs hover:bg-white/15">👁</Link>
                      <Link href={`/admin/invoices/${i.id}?edit=1`} className="rounded-lg bg-white/8 px-2 py-1 text-xs hover:bg-white/15">✏️</Link>
                      <button onClick={() => window.open(`/admin/invoices/${i.id}`, "_blank")} className="rounded-lg bg-white/8 px-2 py-1 text-xs hover:bg-white/15">🖨</button>
                      <button onClick={() => del(i.id)} className="rounded-lg bg-red-600/20 px-2 py-1 text-xs text-red-300 hover:bg-red-600/35">🗑</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {invoices.length === 0 && (
            <div className="p-12 text-center">
              <div className="text-5xl">🧾</div>
              <div className="mt-3 font-bold text-white/70">لا توجد فواتير بعد</div>
              <Link href="/admin/invoices/new" className="mt-4 inline-block rounded-xl px-6 py-2.5 font-bold text-[#0b1526]" style={{ background: "linear-gradient(135deg,#f3dc92,#c9a227)" }}>
                إنشاء أول فاتورة
              </Link>
            </div>
          )}
        </div>
        {pages > 1 && (
          <div className="mt-4 flex justify-center gap-2">
            <button disabled={page <= 1} onClick={() => setPage(page - 1)} className={btnDark}>→ السابق</button>
            <span className="rounded-xl px-4 py-2 text-sm font-black text-[#0b1526]" style={{ background: "linear-gradient(135deg,#f3dc92,#c9a227)" }}>{page} / {pages}</span>
            <button disabled={page >= pages} onClick={() => setPage(page + 1)} className={btnDark}>التالي ←</button>
          </div>
        )}
      </Panel>
    </AdminShell>
  );
}
