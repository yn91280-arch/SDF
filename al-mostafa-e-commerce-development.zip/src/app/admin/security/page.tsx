"use client";
import { useEffect, useState } from "react";
import AdminShell, { Panel, inputCls, btnGold, btnGoldStyle } from "@/components/AdminShell";
import { passwordStrength, isStrongPassword, formatDateTime } from "@/lib/utils";

export default function SecurityPage() {
  const [admin, setAdmin] = useState<any>(null);
  const [pw, setPw] = useState({ current: "", next: "", confirm: "" });
  const [msg, setMsg] = useState("");
  const [saving, setSaving] = useState(false);
  const strength = passwordStrength(pw.next);

  useEffect(() => {
    fetch("/api/admin/me").then((r) => r.json()).then((j) => { if (j.ok) setAdmin(j.admin); }).catch(() => {});
  }, []);

  const save = async () => {
    setMsg("");
    if (!isStrongPassword(pw.next)) { setMsg("كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل وتضم حروفاً وأرقاماً"); return; }
    if (pw.next !== pw.confirm) { setMsg("تأكيد كلمة المرور غير متطابق"); return; }
    setSaving(true);
    const res = await fetch("/api/admin/change-password", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ current: pw.current, next: pw.next }),
    });
    const j = await res.json();
    setSaving(false);
    setMsg(j.ok ? "✅ تم تغيير كلمة المرور بنجاح" : j.message);
    if (j.ok) setPw({ current: "", next: "", confirm: "" });
    setTimeout(() => setMsg(""), 4000);
  };

  return (
    <AdminShell title="الأمان 🔒">
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel title="تغيير كلمة المرور">
          <div className="space-y-3">
            <div>
              <label className="text-xs text-white/55">كلمة المرور الحالية</label>
              <input type="password" value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} className={inputCls} placeholder="••••••••" />
            </div>
            <div>
              <label className="text-xs text-white/55">كلمة المرور الجديدة (8 أحرف وأرقام على الأقل)</label>
              <input type="password" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} className={inputCls} placeholder="كلمة قوية" />
              {pw.next && (
                <div className="mt-2">
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                    <div className="h-full rounded-full transition-all" style={{ width: `${(strength.score + 1) * 25}%`, background: strength.color }} />
                  </div>
                  <div className="mt-1 text-[11px]" style={{ color: strength.color }}>قوة كلمة المرور: {strength.label}</div>
                </div>
              )}
            </div>
            <div>
              <label className="text-xs text-white/55">تأكيد كلمة المرور</label>
              <input type="password" value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} className={inputCls} placeholder="أعد الكتابة" />
            </div>
            {msg && <div className="rounded-xl bg-white/8 px-4 py-2.5 text-sm">{msg}</div>}
            <button onClick={save} disabled={saving} className={`${btnGold} w-full py-3`} style={btnGoldStyle}>
              {saving ? "⏳ جاري التحديث…" : "🔑 تغيير كلمة المرور"}
            </button>
          </div>
        </Panel>

        <Panel title="حالة الحماية">
          <div className="space-y-3">
            {[
              ["🛡️", "تشفير كلمات المرور", "كلمات المرور مخزنة بتشفير bcrypt (12 جولة) ولا يمكن استرجاعها"],
              ["🚫", "منع التخمين (Rate Limiting)", "الحد الأقصى 8 محاولات فاشلة خلال 15 دقيقة لكل بريد/حساب"],
              ["🍪", "جلسات آمنة", "كوكيز HttpOnly + SameSite + توقيع JWT مشفّر HS256"],
              ["🔐", "حماية لوحة الإدارة", "جميع مسارات /admin و API الخاصة بها تتطلب تسجيل دخول موثّقاً على الخادم"],
              ["🧹", "تنظيف المدخلات", "جميع المدخلات يتم تعقيمها والتعامل مع القاعدة عبر Drizzle (حماية من SQL Injection)"],
              ["🙈", "عدم تسريب البيانات", "لا تُعاد كلمات المرور أو التوكنز في أي استجابة أو سجل"],
            ].map(([i, t, d]) => (
              <div key={t} className="flex gap-3 rounded-xl bg-white/[0.05] p-3">
                <span className="text-xl">{i}</span>
                <div>
                  <div className="text-sm font-bold">{t}</div>
                  <div className="mt-0.5 text-xs text-white/55">{d}</div>
                </div>
              </div>
            ))}
          </div>
          {admin && (
            <div className="mt-4 rounded-xl border border-white/10 bg-white/[0.04] p-4 text-sm">
              <div className="text-white/55">الحساب الحالي</div>
              <div className="mt-1 font-bold text-white">{admin.name}</div>
              <div className="text-white/55" dir="ltr">{admin.email}</div>
              <div className="text-xs text-[#e8c766]">الصلاحية: {admin.role === "admin" ? "مدير كامل" : admin.role}</div>
            </div>
          )}
        </Panel>
      </div>
    </AdminShell>
  );
}
