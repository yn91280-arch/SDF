"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import AdminShell, { StatCard, Panel, inputCls, btnGold, btnGoldStyle, btnDark } from "@/components/AdminShell";
import Logo from "@/components/Logo";
import { formatPrice, formatDateTime, ORDER_STATUS_AR, generateInvoiceNumber } from "@/lib/utils";

export default function AdminDashboard() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [now, setNow] = useState<Date | null>(null);
  const [q, setQ] = useState("");
  const [results, setResults] = useState<any[]>([]);
  const [rows, setRows] = useState<any[]>([]);
  const [cust, setCust] = useState({ customerName: "", customerPhone: "", customerAddress: "", paid: "" });
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    setNow(new Date());
    fetch("/api/admin/dashboard").then((r) => r.json()).then((j) => { if (j.ok) setData(j); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!q.trim()) { setResults([]); return; }
    const t = setTimeout(() => {
      fetch(`/api/admin/products?q=${encodeURIComponent(q)}&limit=6`).then((r) => r.json()).then((j) => { if (j.ok) setResults(j.products); }).catch(() => {});
    }, 300);
    return () => clearTimeout(t);
  }, [q]);

  const addRow = (p: any) => {
    if (rows.some((r) => r.productId === p.id)) return;
    setRows([...rows, { productId: p.id, productName: p.name, productCode: p.code, quantity: 1, price: Number(p.discountPrice && Number(p.discountPrice) > 0 ? p.discountPrice : p.price), discount: 0 }]);
    setQ(""); setResults([]);
  };

  const total = useMemo(() => rows.reduce((s, r) => s + Math.max(0, r.price * r.quantity - (r.discount || 0)), 0), [rows]);

  const saveInvoice = async () => {
    if (rows.length === 0) { setMsg("أضف منتجاً واحداً على الأقل"); return; }
    if (!cust.customerName.trim()) { setMsg("أدخل اسم العميل"); return; }
    setSaving(true); setMsg("");
    const res = await fetch("/api/admin/invoices", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...cust, items: rows, paid: Number(cust.paid) || 0 }),
    });
    const j = await res.json();
    setSaving(false);
    if (!j.ok) { setMsg(j.message); return; }
    setMsg(`✅ تم حفظ الفاتورة ${j.invoice.invoiceNumber}`);
    setRows([]); setCust({ customerName: "", customerPhone: "", customerAddress: "", paid: "" });
    setTimeout(() => window.open(`/admin/invoices/${j.invoice.id}`, "_blank"), 400);
  };

  const daily = data?.daily || [];
  const maxDay = Math.max(1, ...daily.map((d: any) => Number(d.total) || 0));
  const points = daily.map((d: any, i: number) => {
    const x = (i / Math.max(1, daily.length - 1)) * 600;
    const y = 160 - ((Number(d.total) || 0) / maxDay) * 130;
    return `${x},${y}`;
  }).join(" ");

  const donutData = [
    { label: "خلاطات", value: 28, color: "#e8c766" },
    { label: "أطقم حمامات", value: 22, color: "#c9a227" },
    { label: "أحواض", value: 15, color: "#4b8bbe" },
    { label: "إكسسوارات", value: 12, color: "#b4539b" },
    { label: "سخانات", value: 9, color: "#34d399" },
    { label: "أخرى", value: 14, color: "#f97316" },
  ];

  return (
    <AdminShell title="لوحة التحكم" noPad>
      <div className="space-y-4 p-4 sm:p-6">
        {/* top row */}
        <div className="grid gap-3 lg:grid-cols-[1fr_1fr_1fr_1.4fr]">
          <StatCard icon="💰" label="إجمالي المبيعات" value={formatPrice(data?.stats?.totalSales ?? 0)} trend="↑ 12%" />
          <StatCard icon="🛒" label="عدد الطلبات" value={data?.stats?.orders ?? 0} trend="↑ 18%" />
          <StatCard icon="👥" label="العملاء" value={data?.stats?.customers ?? 0} trend="↑ 14%" />
          <div className="rounded-2xl border border-[#c9a227]/25 bg-gradient-to-l from-[#12203c] to-[#0b1526] p-5">
            <h3 className="text-xl font-black text-white">مرحبا بك في لوحة التحكم</h3>
            <p className="mt-1.5 text-sm text-white/60">إدارة منتجاتك بسهولة .. في مكان واحد</p>
            <div className="mt-3 flex items-center gap-2 text-xs text-[#e8c766]">
              🗓 {now ? now.toLocaleDateString("ar-EG", { weekday: "long", day: "numeric", month: "long", year: "numeric" }) : "—"}
              <span className="text-white/35">—</span>
              🕘 {now ? now.toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" }) : ""}
            </div>
          </div>
        </div>

        {/* charts */}
        <div className="grid gap-4 lg:grid-cols-2">
          <Panel title="المبيعات خلال 7 أيام" action={<span className="rounded-lg border border-white/10 px-3 py-1 text-xs text-white/60">مجمل الفواتير ▾</span>}>
            <div className="relative">
              <svg viewBox="0 0 600 180" className="h-[200px] w-full">
                <defs>
                  <linearGradient id="lineGold" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#e8c766" stopOpacity="0.45" />
                    <stop offset="100%" stopColor="#e8c766" stopOpacity="0" />
                  </linearGradient>
                </defs>
                {[0, 1, 2, 3].map((i) => (
                  <line key={i} x1="0" y1={20 + i * 42} x2="600" y2={20 + i * 42} stroke="#ffffff" strokeOpacity="0.08" />
                ))}
                <polygon points={`0,170 ${points} 600,170`} fill="url(#lineGold)" />
                <polyline points={points} fill="none" stroke="#e8c766" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                {daily.map((d: any, i: number) => (
                  <circle key={i} cx={(i / Math.max(1, daily.length - 1)) * 600} cy={160 - ((Number(d.total) || 0) / maxDay) * 130} r="4" fill="#0b1526" stroke="#e8c766" strokeWidth="2.5" />
                ))}
              </svg>
              <div className="mt-1 flex justify-between px-1 text-[10px] text-white/50">
                {daily.map((d: any, i: number) => <span key={i}>{d.day}</span>)}
              </div>
            </div>
          </Panel>

          <Panel title="أكثر الأقسام مبيعاً">
            <div className="flex flex-wrap items-center gap-6">
              <div className="relative h-[180px] w-[180px] shrink-0">
                <svg viewBox="0 0 200 200" className="h-full w-full -rotate-90">
                  {(() => {
                    let offset = 0;
                    return donutData.map((d) => {
                      const len = (d.value / 100) * 2 * Math.PI * 70;
                      const el = (
                        <circle key={d.label} cx="100" cy="100" r="70" fill="none" stroke={d.color} strokeWidth="30"
                          strokeDasharray={`${len} ${2 * Math.PI * 70 - len}`} strokeDashoffset={-offset} />
                      );
                      offset += len;
                      return el;
                    });
                  })()}
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <div className="text-xs text-white/55">إجمالي المبيعات</div>
                  <div className="text-lg font-black text-white">{formatPrice(data?.stats?.totalSales ?? 0)}</div>
                </div>
              </div>
              <div className="flex-1 space-y-2">
                {donutData.map((d) => (
                  <div key={d.label} className="flex items-center gap-2 text-sm">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: d.color }} />
                    <span className="flex-1 text-white/70">{d.label}</span>
                    <span className="font-bold text-white">{d.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </Panel>
        </div>

        {/* orders + invoice */}
        <div className="grid gap-4 xl:grid-cols-[1fr_360px]">
          <Panel title="أحدث الطلبات" action={<Link href="/admin/orders" className="rounded-lg border border-white/12 px-3 py-1.5 text-xs font-bold text-white/70 hover:bg-white/10">عرض الكل ←</Link>}>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[680px] text-[13px]">
                <thead>
                  <tr className="border-b border-white/8 text-right text-white/45">
                    <th className="p-2.5">#</th>
                    <th className="p-2.5">العميل</th>
                    <th className="p-2.5">التاريخ</th>
                    <th className="p-2.5">المبلغ</th>
                    <th className="p-2.5">الحالة</th>
                    <th className="p-2.5">الإجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {(data?.recentOrders || []).map((o: any) => (
                    <tr key={o.id} className="border-b border-white/5 hover:bg-white/[0.04]">
                      <td className="p-2.5 font-mono text-white/70" dir="ltr">#{o.orderNumber}</td>
                      <td className="p-2.5 font-bold">{o.customerName}</td>
                      <td className="p-2.5 text-white/55" dir="ltr">{new Date(o.createdAt).toLocaleDateString("en-GB")}</td>
                      <td className="p-2.5 font-bold text-[#e8c766]">{formatPrice(o.total)}</td>
                      <td className="p-2.5">
                        <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${
                          o.status === "cancelled" ? "bg-red-600/20 text-red-300"
                            : o.status === "delivered" || o.status === "completed" ? "bg-emerald-600/20 text-emerald-300"
                              : "bg-amber-500/20 text-amber-300"
                        }`}>
                          {ORDER_STATUS_AR[o.status] || o.status}
                        </span>
                      </td>
                      <td className="p-2.5">
                        <div className="flex gap-1">
                          <Link href={`/admin/orders/${o.id}`} className="rounded-lg bg-white/8 px-2 py-1 text-xs hover:bg-white/15">👁</Link>
                          <Link href={`/admin/orders/${o.id}`} className="rounded-lg bg-white/8 px-2 py-1 text-xs hover:bg-white/15">✏️</Link>
                          <button onClick={() => window.print()} className="rounded-lg bg-white/8 px-2 py-1 text-xs hover:bg-white/15">🖨</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {(data?.recentOrders || []).length === 0 && (
                    <tr><td colSpan={6} className="p-8 text-center text-white/40">لا توجد طلبات بعد</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </Panel>

          {/* quick invoice */}
          <Panel title="إنشاء فاتورة جديدة" action={<Link href="/admin/invoices/new" className="rounded-lg bg-white/8 px-3 py-1.5 text-xs font-bold text-[#e8c766]">الفاتورة الكاملة</Link>}>
            <div className="rounded-xl border border-white/8 bg-white/[0.03] p-3">
              <div className="mb-2 text-xs font-bold text-white/60">تصميم الفاتورة</div>
              <div className="grid grid-cols-3 gap-2">
                {["classic", "modern", "compact"].map((t, i) => (
                  <div key={t} className={`cursor-pointer rounded-lg border p-1.5 text-center text-[10px] ${i === 0 ? "border-[#c9a227] bg-[#c9a227]/12 text-[#e8c766]" : "border-white/10 text-white/55"}`}>
                    <div className="mb-1 h-10 rounded bg-white/10" />
                    تصميم {i + 1}
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-3 space-y-2">
              <input value={cust.customerName} onChange={(e) => setCust({ ...cust, customerName: e.target.value })} placeholder="اسم العميل" className={inputCls} />
              <input value={cust.customerPhone} onChange={(e) => setCust({ ...cust, customerPhone: e.target.value })} placeholder="رقم الهاتف" dir="ltr" className={inputCls} />
              <input value={cust.customerAddress} onChange={(e) => setCust({ ...cust, customerAddress: e.target.value })} placeholder="العنوان" className={inputCls} />
            </div>

            <div className="mt-3 text-xs font-bold text-[#e8c766]">🛍 إضافة المنتجات</div>
            <div className="relative mt-2">
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="ابحث عن منتج ..." className={`${inputCls} ps-9`} />
              <span className="absolute start-3 top-1/2 -translate-y-1/2 text-white/40">🔍</span>
              {results.length > 0 && (
                <div className="absolute z-20 mt-1 w-full overflow-hidden rounded-xl border border-white/12 bg-[#0b1526] shadow-2xl">
                  {results.map((p) => (
                    <button key={p.id} onClick={() => addRow(p)} className="block w-full px-3 py-2 text-right text-xs hover:bg-white/10">
                      <div className="font-bold">{p.name}</div>
                      <div className="text-white/45" dir="ltr">{p.code} — {p.price} ج.م</div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="mt-2 space-y-1.5">
              {rows.map((r, i) => (
                <div key={i} className="flex items-center gap-1.5 rounded-lg bg-white/[0.05] p-2 text-[11px]">
                  <div className="min-w-0 flex-1">
                    <div className="line-clamp-1 font-bold">{r.productName}</div>
                    <div className="text-white/45">{formatPrice(r.price)} × {r.quantity}</div>
                  </div>
                  <input type="number" min={1} value={r.quantity} onChange={(e) => {
                    const v = [...rows]; v[i].quantity = Math.max(1, Number(e.target.value) || 1); setRows(v);
                  }} className="w-14 rounded-md border border-white/12 bg-white/8 px-1.5 py-1 text-center text-white" />
                  <div className="w-16 text-center font-bold text-[#e8c766]">{formatPrice(r.price * r.quantity)}</div>
                  <button onClick={() => setRows(rows.filter((_, x) => x !== i))} className="text-red-400">🗑</button>
                </div>
              ))}
            </div>

            <div className="mt-3 flex items-center justify-between border-t border-white/10 pt-3">
              <span className="text-sm text-white/70">إجمالي الفاتورة</span>
              <span className="text-xl font-black text-[#e8c766]">{formatPrice(total)}</span>
            </div>
            <input value={cust.paid} onChange={(e) => setCust({ ...cust, paid: e.target.value })} placeholder="المبلغ المدفوع" type="number" dir="ltr" className={`${inputCls} mt-2`} />
            {msg && <div className="mt-2 rounded-lg bg-white/8 px-3 py-2 text-xs">{msg}</div>}
            <button onClick={saveInvoice} disabled={saving} className={`${btnGold} mt-3 w-full`} style={btnGoldStyle}>
              {saving ? "⏳ جاري الحفظ…" : "💾 حفظ الفاتورة"}
            </button>
          </Panel>
        </div>

        {/* products + quick stats */}
        <div className="grid gap-4 xl:grid-cols-[1fr_360px]">
          <Panel title="أكثر المنتجات المضافة" action={<Link href="/admin/products" className="rounded-lg border border-white/12 px-3 py-1.5 text-xs font-bold text-white/70 hover:bg-white/10">عرض الكل ←</Link>}>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {(data?.bestSelling || []).slice(0, 4).map((p: any) => (
                <div key={p.id} className="overflow-hidden rounded-2xl border border-white/8 bg-white/[0.04]">
                  <div className="aspect-square bg-white">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={p.images?.[0] || "/images/showroom-shelf.jpg"} alt={p.name} className="h-full w-full object-cover" />
                  </div>
                  <div className="p-2.5">
                    <div className="line-clamp-1 text-xs font-bold">{p.name}</div>
                    <div className="mt-1 text-[11px] text-white/50" dir="ltr">{p.companyName} | {p.code}</div>
                    <div className="mt-1.5 flex items-center justify-between">
                      <span className="text-sm font-black text-[#e8c766]">{formatPrice(p.price)}</span>
                      <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${p.stock > 0 ? "bg-emerald-600/20 text-emerald-300" : "bg-red-600/20 text-red-300"}`}>
                        {p.stock > 0 ? "متوفر" : "غير متوفر"}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Panel>

          <Panel title="إحصائيات سريعة">
            <div className="space-y-2">
              <Link href="/admin/products" className="flex items-center gap-3 rounded-xl bg-white/[0.05] p-3 hover:bg-white/10">
                <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#c9a227]/20">➕</span>
                <div className="flex-1 text-sm font-bold">إضافة منتج جديد</div>
                <span className="text-white/35">←</span>
              </Link>
              <Link href="/admin/customers" className="flex items-center gap-3 rounded-xl bg-white/[0.05] p-3 hover:bg-white/10">
                <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#4b8bbe]/20">👥</span>
                <div className="flex-1 text-sm font-bold">إدارة العملاء</div>
                <span className="text-white/35">←</span>
              </Link>
              <Link href="/admin/invoices/new" className="flex items-center gap-3 rounded-xl bg-white/[0.05] p-3 hover:bg-white/10">
                <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#b4539b]/20">🧾</span>
                <div className="flex-1 text-sm font-bold">إنشاء فاتورة</div>
                <span className="text-white/35">←</span>
              </Link>
              <Link href="/admin/inventory?low=1" className="flex items-center gap-3 rounded-xl bg-white/[0.05] p-3 hover:bg-white/10">
                <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-600/20">⚠️</span>
                <div className="flex-1 text-sm font-bold">منتجات منخفضة المخزون</div>
                <span className="rounded-full bg-red-600 px-2.5 py-0.5 text-xs font-bold">{data?.stats?.lowStock ?? 0}</span>
              </Link>
            </div>
            <div className="mt-4 flex items-center justify-center gap-2 opacity-70">
              <Logo size={34} />
              <div>
                <div className="text-sm font-black gold-text">معرض المصطفي</div>
                <div className="text-[10px] text-white/50">للأدوات الصحية والسباكة</div>
              </div>
            </div>
          </Panel>
        </div>
      </div>
    </AdminShell>
  );
}
