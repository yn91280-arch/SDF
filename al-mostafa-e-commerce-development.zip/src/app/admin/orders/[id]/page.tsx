"use client";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import AdminShell, { Panel, btnDark } from "@/components/AdminShell";
import { formatPrice, formatDateTime, ORDER_STATUS_AR } from "@/lib/utils";

export default function OrderDetail() {
  const { id } = useParams<{ id: string }>();
  const [order, setOrder] = useState<any>(null);
  const [items, setItems] = useState<any[]>([]);

  useEffect(() => {
    fetch(`/api/admin/orders/${id}`).then((r) => r.json()).then((j) => {
      if (j.ok) { setOrder(j.order); setItems(j.items); }
    }).catch(() => {});
  }, [id]);

  const setSt = async (st: string) => {
    await fetch("/api/admin/orders", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: Number(id), status: st }) });
    setOrder({ ...order, status: st });
  };

  if (!order) return <AdminShell title="تفاصيل الطلب"><div className="text-white/50">جاري التحميل…</div></AdminShell>;

  const waMsg = encodeURIComponent(`طلب ${order.orderNumber} — ${order.customerName} — الإجمالي ${order.total} ج.م`);

  return (
    <AdminShell title={`طلب ${order.orderNumber}`}>
      <Link href="/admin/orders" className="mb-4 inline-block text-sm text-[#e8c766]">→ عودة للطلبات</Link>
      <div className="grid gap-4 lg:grid-cols-3">
        <Panel title="👤 بيانات العميل">
          <div className="space-y-2 text-sm">
            <div><span className="text-white/50">الاسم:</span> <b>{order.customerName}</b></div>
            <div><span className="text-white/50">الهاتف:</span> <b dir="ltr">{order.customerPhone}</b></div>
            <div><span className="text-white/50">العنوان:</span> {order.customerAddress || "—"}</div>
            <div><span className="text-white/50">ملاحظات:</span> {order.notes || "—"}</div>
            <div><span className="text-white/50">التاريخ:</span> {formatDateTime(order.createdAt)}</div>
            <a href={`https://wa.me/2${String(order.customerPhone).replace(/[^0-9]/g, "").replace(/^0/, "").replace(/^20/, "")}?text=${waMsg}`} target="_blank" rel="noopener noreferrer" className="mt-2 block rounded-xl bg-[#25D366] py-2.5 text-center font-bold">💬 مراسلة واتساب</a>
          </div>
        </Panel>
        <Panel title="🧾 الأصناف">
          <div className="space-y-2">
            {items.map((it: any) => (
              <div key={it.id} className="flex justify-between rounded-xl bg-white/5 p-2.5 text-sm">
                <div><b>{it.productName}</b><div className="font-mono text-xs text-white/50" dir="ltr">{it.productCode} × {it.quantity}</div></div>
                <div className="font-bold text-[#e8c766]">{formatPrice(it.total)}</div>
              </div>
            ))}
          </div>
          <div className="mt-3 space-y-1 border-t border-white/10 pt-3 text-sm">
            <div className="flex justify-between text-white/60"><span>الفرعي</span><span>{formatPrice(order.subtotal)}</span></div>
            <div className="flex justify-between text-white/60"><span>الخصم</span><span>{formatPrice(order.discount)}</span></div>
            <div className="flex justify-between text-lg font-black"><span>الإجمالي</span><span className="text-[#e8c766]">{formatPrice(order.total)}</span></div>
          </div>
        </Panel>
        <Panel title="⚙️ الحالة">
          <div className="grid gap-2">
            {Object.entries(ORDER_STATUS_AR).map(([k, v]) => (
              <button key={k} onClick={() => setSt(k)} className={`rounded-xl px-4 py-2.5 text-sm font-bold ${order.status === k ? "gold-bg text-[#0b1526]" : "bg-white/5 text-white/70 hover:bg-white/10"}`}>
                {order.status === k ? "● " : ""}{v}
              </button>
            ))}
          </div>
          <button onClick={() => window.print()} className={`${btnDark} mt-3 w-full print-hidden`}>🖨 طباعة</button>
        </Panel>
      </div>
    </AdminShell>
  );
}
