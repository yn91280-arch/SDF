"use client";
import { useEffect, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import AdminShell, { Panel, inputCls, btnDark } from "@/components/AdminShell";
import { formatPrice, formatDateTime, ORDER_STATUS_AR } from "@/lib/utils";

const STATUSES = ["", "new", "processing", "preparing", "ready", "delivered", "completed", "cancelled"];

function Body() {
  const sp = useSearchParams();
  const [orders, setOrders] = useState<any[]>([]);
  const [status, setStatus] = useState(sp.get("status") || "");
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);

  const load = () => {
    fetch(`/api/admin/orders?page=${page}&limit=20&status=${status}&q=${encodeURIComponent(q)}`).then((r) => r.json()).then((j) => {
      if (j.ok) { setOrders(j.orders); setPages(j.pagination.pages || 1); }
    }).catch(() => {});
  };
  useEffect(() => { setStatus(sp.get("status") || ""); }, [sp]);
  useEffect(load, [page, status]);
  useEffect(() => { const t = setTimeout(() => { setPage(1); load(); }, 400); return () => clearTimeout(t); }, [q]);

  const setSt = async (id: number, st: string) => {
    await fetch("/api/admin/orders", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, status: st }) });
    load();
  };

  return (
    <AdminShell title="الطلبات 🧾">
      <div className="mb-4 flex flex-wrap gap-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔍 بحث برقم الطلب / الاسم / الهاتف…" className={`${inputCls} max-w-xs`} />
        <select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }} className={`${inputCls} max-w-[200px]`}>
          {STATUSES.map((s) => <option key={s} value={s}>{s === "" ? "كل الحالات" : ORDER_STATUS_AR[s]}</option>)}
        </select>
      </div>
      <Panel title={`الطلبات (${orders.length})`}>
        <div className="space-y-2">
          {orders.map((o: any) => (
            <div key={o.id} className="rounded-xl bg-white/5 p-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <Link href={`/admin/orders/${o.id}`} className="font-mono font-bold text-[#e8c766] hover:underline" dir="ltr">{o.orderNumber}</Link>
                  <div className="mt-1 text-sm">{o.customerName} • <span dir="ltr">{o.customerPhone}</span></div>
                  <div className="text-xs text-white/40">{formatDateTime(o.createdAt)}</div>
                </div>
                <div className="text-left">
                  <div className="font-black text-[#e8c766]">{formatPrice(o.total)}</div>
                  <select value={o.status} onChange={(e) => setSt(o.id, e.target.value)} className="mt-1 rounded-lg border border-white/15 bg-white/10 px-2 py-1 text-xs">
                    {STATUSES.filter(Boolean).map((s) => <option key={s} value={s}>{ORDER_STATUS_AR[s]}</option>)}
                  </select>
                </div>
              </div>
              <div className="mt-2 flex gap-2">
                <Link href={`/admin/orders/${o.id}`} className="rounded-lg bg-white/10 px-3 py-1 text-xs">👁 التفاصيل</Link>
                <a href={`https://wa.me/2${o.customerPhone?.replace(/[^0-9]/g, "").replace(/^0/, "").replace(/^20/, "")}`} target="_blank" rel="noopener noreferrer" className="rounded-lg bg-[#25D366]/20 px-3 py-1 text-xs text-emerald-400">💬 واتساب</a>
              </div>
            </div>
          ))}
          {orders.length === 0 && <div className="p-8 text-center text-white/40">لا توجد طلبات</div>}
        </div>
        {pages > 1 && (
          <div className="mt-4 flex justify-center gap-2">
            <button disabled={page <= 1} onClick={() => setPage(page - 1)} className={btnDark}>→ السابق</button>
            <span className="rounded-xl gold-bg px-4 py-2 text-sm font-black text-[#0b1526]">{page} / {pages}</span>
            <button disabled={page >= pages} onClick={() => setPage(page + 1)} className={btnDark}>التالي ←</button>
          </div>
        )}
      </Panel>
    </AdminShell>
  );
}

export default function OrdersPage() {
  return <Suspense fallback={<div>…</div>}><Body /></Suspense>;
}
