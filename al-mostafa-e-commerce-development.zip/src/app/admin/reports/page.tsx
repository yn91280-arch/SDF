"use client";
import { useEffect, useState } from "react";
import AdminShell, { Panel, inputCls, btnGold, btnGoldStyle, btnDark } from "@/components/AdminShell";
import { formatPrice, formatDate, formatDateTime } from "@/lib/utils";

export default function ReportsPage() {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    const p = new URLSearchParams({ from, to });
    fetch(`/api/admin/reports?${p}`).then((r) => r.json()).then((j) => { if (j.ok) setData(j); setLoading(false); }).catch(() => setLoading(false));
  };
  useEffect(load, [from, to]);

  const exportCsv = (rows: any[], name: string) => {
    if (!rows?.length) return;
    const keys = Object.keys(rows[0]);
    const csv = "\uFEFF" + [keys.join(","), ...rows.map((r) => keys.map((k) => `"${String(r[k] ?? "")}"`).join(","))].join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const a = document.createElement("a");
    a.href = url; a.download = `${name}-${Date.now()}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <AdminShell title="التقارير 📊">
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <label className="text-sm text-white/60">من</label>
        <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className={`${inputCls} w-44`} dir="ltr" />
        <label className="text-sm text-white/60">إلى</label>
        <input type="date" value={to} onChange={(e) => setTo(e.target.value)} className={`${inputCls} w-44`} dir="ltr" />
        <button onClick={() => { setFrom(""); setTo(""); }} className={btnDark}>إعادة الضبط</button>
        <button onClick={() => window.print()} className={btnDark}>🖨 طباعة التقرير</button>
      </div>

      {loading ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-28 animate-pulse rounded-2xl bg-white/5" />)}
        </div>
      ) : !data ? (
        <div className="rounded-2xl bg-white/5 p-12 text-center text-white/50">تعذر تحميل التقارير</div>
      ) : (
        <div className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-4">
            {[
              ["إجمالي الفواتير", formatPrice(data.invTotals?.total || 0)],
              ["المحصل", formatPrice(data.invTotals?.paid || 0)],
              ["المستحق", formatPrice(data.invTotals?.remaining || 0)],
              ["عدد الفواتير", data.invTotals?.count || 0],
            ].map(([l, v]) => (
              <div key={l as string} className="rounded-2xl border border-white/8 bg-white/5 p-4">
                <div className="text-xs text-white/55">{l}</div>
                <div className="mt-1 text-xl font-black text-white">{v}</div>
              </div>
            ))}
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <Panel title="المبيعات اليومية" action={<button onClick={() => exportCsv(data.salesByDay, "daily-sales")} className="rounded-lg bg-white/10 px-3 py-1.5 text-xs">⬇ CSV</button>}>
              <div className="max-h-80 overflow-y-auto">
                <table className="w-full text-[12.5px]">
                  <thead><tr className="border-b border-white/10 text-right text-white/45"><th className="p-2">اليوم</th><th className="p-2">الطلبات</th><th className="p-2">الإجمالي</th></tr></thead>
                  <tbody>
                    {data.salesByDay.map((d: any, i: number) => (
                      <tr key={i} className="border-b border-white/5">
                        <td className="p-2" dir="ltr">{d.day}</td>
                        <td className="p-2">{d.orders}</td>
                        <td className="p-2 font-bold text-[#e8c766]">{formatPrice(d.total)}</td>
                      </tr>
                    ))}
                    {data.salesByDay.length === 0 && <tr><td colSpan={3} className="p-6 text-center text-white/40">لا توجد بيانات</td></tr>}
                  </tbody>
                </table>
              </div>
            </Panel>

            <Panel title="أفضل المنتجات مبيعاً" action={<button onClick={() => exportCsv(data.topProducts, "top-products")} className="rounded-lg bg-white/10 px-3 py-1.5 text-xs">⬇ CSV</button>}>
              <div className="max-h-80 overflow-y-auto">
                <table className="w-full text-[12.5px]">
                  <thead><tr className="border-b border-white/10 text-right text-white/45"><th className="p-2">المنتج</th><th className="p-2">الكود</th><th className="p-2">الكمية</th><th className="p-2">الإجمالي</th></tr></thead>
                  <tbody>
                    {data.topProducts.map((d: any, i: number) => (
                      <tr key={i} className="border-b border-white/5">
                        <td className="p-2">{d.name}</td>
                        <td className="p-2 font-mono text-white/55" dir="ltr">{d.code}</td>
                        <td className="p-2">{d.qty}</td>
                        <td className="p-2 font-bold text-[#e8c766]">{formatPrice(d.total)}</td>
                      </tr>
                    ))}
                    {data.topProducts.length === 0 && <tr><td colSpan={4} className="p-6 text-center text-white/40">لا توجد بيانات</td></tr>}
                  </tbody>
                </table>
              </div>
            </Panel>

            <Panel title="مبيعات الشركات" action={<button onClick={() => exportCsv(data.companySales, "company-sales")} className="rounded-lg bg-white/10 px-3 py-1.5 text-xs">⬇ CSV</button>}>
              <div className="max-h-80 overflow-y-auto">
                <table className="w-full text-[12.5px]">
                  <thead><tr className="border-b border-white/10 text-right text-white/45"><th className="p-2">الشركة</th><th className="p-2">الكمية</th><th className="p-2">الإجمالي</th></tr></thead>
                  <tbody>
                    {data.companySales.map((d: any, i: number) => (
                      <tr key={i} className="border-b border-white/5">
                        <td className="p-2">{d.company}</td>
                        <td className="p-2">{d.qty}</td>
                        <td className="p-2 font-bold text-[#e8c766]">{formatPrice(d.total)}</td>
                      </tr>
                    ))}
                    {data.companySales.length === 0 && <tr><td colSpan={3} className="p-6 text-center text-white/40">لا توجد بيانات</td></tr>}
                  </tbody>
                </table>
              </div>
            </Panel>

            <Panel title="المبالغ المستحقة">
              <div className="max-h-80 overflow-y-auto">
                <table className="w-full text-[12.5px]">
                  <thead><tr className="border-b border-white/10 text-right text-white/45"><th className="p-2">الفاتورة</th><th className="p-2">العميل</th><th className="p-2">المتبقي</th></tr></thead>
                  <tbody>
                    {data.outstanding.map((d: any) => (
                      <tr key={d.id} className="border-b border-white/5">
                        <td className="p-2 font-mono text-[#e8c766]" dir="ltr">{d.invoiceNumber}</td>
                        <td className="p-2">{d.customerName} <span className="text-white/45" dir="ltr">{d.customerPhone}</span></td>
                        <td className="p-2 font-bold text-red-400">{formatPrice(d.remaining)}</td>
                      </tr>
                    ))}
                    {data.outstanding.length === 0 && <tr><td colSpan={3} className="p-6 text-center text-emerald-400">✓ لا توجد مبالغ مستحقة</td></tr>}
                  </tbody>
                </table>
              </div>
            </Panel>

            <Panel title="تقرير المخزون" action={<button onClick={() => exportCsv(data.lowStock, "low-stock")} className="rounded-lg bg-white/10 px-3 py-1.5 text-xs">⬇ CSV</button>}>
              <div className="max-h-80 overflow-y-auto">
                <table className="w-full text-[12.5px]">
                  <thead><tr className="border-b border-white/10 text-right text-white/45"><th className="p-2">المنتج</th><th className="p-2">الكود</th><th className="p-2">المخزون</th></tr></thead>
                  <tbody>
                    {data.lowStock.map((p: any) => (
                      <tr key={p.id} className="border-b border-white/5">
                        <td className="p-2">{p.name}</td>
                        <td className="p-2 font-mono text-white/55" dir="ltr">{p.code}</td>
                        <td className="p-2 font-bold text-red-400">{p.stock}</td>
                      </tr>
                    ))}
                    {data.lowStock.length === 0 && <tr><td colSpan={3} className="p-6 text-center text-emerald-400">✓ المخزون بحالة جيدة</td></tr>}
                  </tbody>
                </table>
              </div>
            </Panel>

            <Panel title="المبيعات حسب الأقسام">
              <div className="max-h-80 overflow-y-auto">
                <table className="w-full text-[12.5px]">
                  <thead><tr className="border-b border-white/10 text-right text-white/45"><th className="p-2">القسم</th><th className="p-2">عدد المنتجات</th><th className="p-2">المباع</th></tr></thead>
                  <tbody>
                    {data.categorySales.map((d: any, i: number) => (
                      <tr key={i} className="border-b border-white/5">
                        <td className="p-2">{d.category}</td>
                        <td className="p-2">{d.products}</td>
                        <td className="p-2 font-bold text-[#e8c766]">{d.sold}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Panel>
          </div>
        </div>
      )}
    </AdminShell>
  );
}
