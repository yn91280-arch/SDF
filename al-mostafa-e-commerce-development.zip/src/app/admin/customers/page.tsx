"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import AdminShell, { Panel, inputCls, btnDark } from "@/components/AdminShell";
import { formatPrice, formatDate, formatDateTime } from "@/lib/utils";

export default function CustomersPage() {
  const [customers, setCustomers] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);

  const load = () => {
    fetch(`/api/admin/customers?page=${page}&limit=25&q=${encodeURIComponent(q)}`).then((r) => r.json()).then((j) => {
      if (j.ok) { setCustomers(j.customers); setPages(j.pagination.pages || 1); }
    }).catch(() => {});
  };
  useEffect(load, [page]);
  useEffect(() => {
    const t = setTimeout(() => { setPage(1); load(); }, 400);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  const toggle = async (id: number, active: boolean) => {
    await fetch("/api/admin/customers", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, isActive: !active }) });
    load();
  };

  return (
    <AdminShell title="العملاء 👥">
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔍 بحث بالاسم / الهاتف / البريد…" className={`${inputCls} mb-4 max-w-sm`} />
      <Panel title={`العملاء (${customers.length})`}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-[13px]">
            <thead>
              <tr className="border-b border-white/10 text-right text-white/45">
                <th className="p-2.5">الاسم</th><th className="p-2.5">الهاتف</th><th className="p-2.5">البريد</th>
                <th className="p-2.5">الطلبات</th><th className="p-2.5">إجمالي المشتريات</th>
                <th className="p-2.5">آخر طلب</th><th className="p-2.5">الحالة</th><th className="p-2.5">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {customers.map((c) => (
                <tr key={c.id} className="border-b border-white/5 hover:bg-white/[0.04]">
                  <td className="p-2.5 font-bold">{c.name}</td>
                  <td className="p-2.5 text-white/65" dir="ltr">{c.phone}</td>
                  <td className="p-2.5 text-white/55" dir="ltr">{c.email || "—"}</td>
                  <td className="p-2.5">{c.totalOrders}</td>
                  <td className="p-2.5 font-bold text-[#e8c766]">{formatPrice(c.totalSpent)}</td>
                  <td className="p-2.5 text-white/55">{c.lastOrderAt ? formatDateTime(c.lastOrderAt) : "—"}</td>
                  <td className="p-2.5">
                    <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${c.isActive ? "bg-emerald-600/20 text-emerald-300" : "bg-red-600/20 text-red-300"}`}>
                      {c.isActive ? "نشط" : "موقوف"}
                    </span>
                  </td>
                  <td className="p-2.5">
                    <button onClick={() => toggle(c.id, c.isActive)} className="rounded-lg bg-white/8 px-2.5 py-1 text-xs hover:bg-white/15">
                      {c.isActive ? "إيقاف" : "تفعيل"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {customers.length === 0 && (
            <div className="p-12 text-center">
              <div className="text-5xl">👥</div>
              <div className="mt-3 font-bold text-white/70">لا يوجد عملاء بعد</div>
            </div>
          )}
        </div>
        {pages > 1 && (
          <div className="mt-4 flex justify-center gap-2">
            <button disabled={page <= 1} onClick={() => setPage(page - 1)} className={btnDark}>→ السابق</button>
            <span className="rounded-xl px-4 py-2 text-sm font-black text-[#0b1526]" style={{ background: "linear-gradient(135deg,#f3dc92,#c9a227)" }}>{page} / {pages}</span>
            <button disabled={page >= pages} onClick={() => setPage(page + 1)} className={btnDark}>التالي ←</button>
          </div>
        )}
      </Panel>
    </AdminShell>
  );
}
