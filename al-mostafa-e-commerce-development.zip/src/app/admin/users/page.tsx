"use client";
import { useEffect, useState } from "react";
import AdminShell, { Panel, inputCls, btnGold, btnGoldStyle, btnDark } from "@/components/AdminShell";
import { passwordStrength, isStrongPassword, formatDateTime } from "@/lib/utils";

export default function UsersPage() {
  const [users, setUsers] = useState<any[]>([]);
  const [form, setForm] = useState({ id: 0, name: "", email: "", password: "", role: "staff", isActive: true });
  const [editing, setEditing] = useState(false);
  const [msg, setMsg] = useState("");
  const strength = passwordStrength(form.password);

  const load = () => {
    fetch("/api/admin/users").then((r) => r.json()).then((j) => { if (j.ok) setUsers(j.users); }).catch(() => {});
  };
  useEffect(() => { load(); }, []);

  const save = async () => {
    setMsg("");
    if (!form.name.trim() || !form.email.trim()) { setMsg("أدخل الاسم والبريد"); return; }
    if (!editing && !isStrongPassword(form.password)) { setMsg("كلمة المرور يجب أن تكون 8 أحرف على الأقل وتضم حروفاً وأرقاماً"); return; }
    const res = await fetch("/api/admin/users", {
      method: editing ? "PUT" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form),
    });
    const j = await res.json();
    if (!j.ok) { setMsg(j.message); return; }
    setForm({ id: 0, name: "", email: "", password: "", role: "staff", isActive: true });
    setEditing(false);
    load();
    setMsg("✅ تم الحفظ بنجاح");
    setTimeout(() => setMsg(""), 3000);
  };

  const del = async (id: number) => {
    if (!confirm("حذف هذا المستخدم؟")) return;
    const res = await fetch(`/api/admin/users?id=${id}`, { method: "DELETE" });
    const j = await res.json();
    if (!j.ok) { setMsg(j.message); return; }
    load();
  };

  return (
    <AdminShell title="المستخدمون 👤">
      <div className="grid gap-4 lg:grid-cols-3">
        <Panel title={editing ? "تعديل مستخدم" : "➕ مستخدم جديد"}>
          {msg && <div className="mb-2 rounded-xl bg-white/8 p-2.5 text-xs">{msg}</div>}
          <div className="space-y-2">
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="الاسم *" className={inputCls} />
            <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="البريد *" dir="ltr" className={inputCls} />
            <input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder={editing ? "كلمة مرور جديدة (اختياري)" : "كلمة المرور * (8 أحرف وأرقام)"} className={inputCls} />
            {form.password && (
              <div>
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                  <div className="h-full rounded-full transition-all" style={{ width: `${(strength.score + 1) * 25}%`, background: strength.color }} />
                </div>
                <div className="mt-1 text-[11px]" style={{ color: strength.color }}>{strength.label}</div>
              </div>
            )}
            <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} className={inputCls}>
              <option value="admin">مدير كامل</option>
              <option value="manager">مشرف</option>
              <option value="staff">موظف</option>
            </select>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} /> نشط</label>
            <div className="flex gap-2">
              <button onClick={save} className={btnGold} style={btnGoldStyle}>💾 حفظ</button>
              {editing && <button onClick={() => { setEditing(false); setForm({ id: 0, name: "", email: "", password: "", role: "staff", isActive: true }); }} className={btnDark}>إلغاء</button>}
            </div>
          </div>
        </Panel>
        <div className="lg:col-span-2">
          <Panel title={`المستخدمون (${users.length})`}>
            <div className="space-y-2">
              {users.map((u) => (
                <div key={u.id} className="flex items-center gap-3 rounded-xl bg-white/[0.05] p-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg gold-bg font-black text-[#0b1526]">{u.name?.[0] || "م"}</div>
                  <div className="min-w-0 flex-1">
                    <div className="font-bold">{u.name} {u.id === 1 && <span className="text-[10px] text-[#e8c766]">(المالك)</span>}</div>
                    <div className="text-xs text-white/50" dir="ltr">{u.email} • {u.role} • {u.isActive ? "نشط" : "موقوف"}</div>
                    <div className="text-[10px] text-white/35">آخر دخول: {u.lastLoginAt ? formatDateTime(u.lastLoginAt) : "—"}</div>
                  </div>
                  <button onClick={() => { setForm({ id: u.id, name: u.name, email: u.email, password: "", role: u.role, isActive: u.isActive }); setEditing(true); }} className="rounded-lg bg-white/10 px-2.5 py-1 text-xs">✏️</button>
                  {u.id !== 1 && <button onClick={() => del(u.id)} className="rounded-lg bg-red-600/20 px-2.5 py-1 text-xs text-red-300">🗑</button>}
                </div>
              ))}
              {users.length === 0 && <div className="p-10 text-center text-white/40">لا يوجد مستخدمون</div>}
            </div>
          </Panel>
        </div>
      </div>
    </AdminShell>
  );
}
