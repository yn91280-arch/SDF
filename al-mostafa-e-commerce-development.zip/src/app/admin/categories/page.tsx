"use client";
import { useEffect, useState } from "react";
import AdminShell, { Panel, inputCls, btnGold, btnDark } from "@/components/AdminShell";

export default function AdminCategories() {
  const [cats, setCats] = useState<any[]>([]);
  const [form, setForm] = useState({ id: 0, name: "", description: "", image: "", sortOrder: 0, isActive: true, discountPercent: 0 });
  const [editing, setEditing] = useState(false);
  const [msg, setMsg] = useState("");

  const load = () => {
    fetch("/api/admin/categories").then((r) => r.json()).then((j) => { if (j.ok) setCats(j.categories); }).catch(() => {});
  };
  useEffect(load, []);

  const save = async () => {
    setMsg("");
    if (!form.name.trim()) { setMsg("أدخل اسم القسم"); return; }
    const res = await fetch("/api/admin/categories", { method: editing ? "PUT" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const j = await res.json();
    if (!j.ok) { setMsg(j.message); return; }
    setForm({ id: 0, name: "", description: "", image: "", sortOrder: 0, isActive: true, discountPercent: 0 });
    setEditing(false);
    load();
  };

  const del = async (id: number) => {
    if (!confirm("حذف هذا القسم؟ (لن تُحذف المنتجات)")) return;
    await fetch(`/api/admin/categories?id=${id}`, { method: "DELETE" });
    load();
  };

  return (
    <AdminShell title="الأقسام 📦">
      <div className="grid gap-4 lg:grid-cols-3">
        <Panel title={editing ? "تعديل القسم" : "➕ قسم جديد"}>
          {msg && <div className="mb-2 rounded-xl bg-red-600/15 p-2 text-xs text-red-400">{msg}</div>}
          <div className="space-y-2">
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="اسم القسم *" className={inputCls} />
            <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="الوصف" rows={2} className={inputCls} />
            <input value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} placeholder="رابط الصورة https://…" dir="ltr" className={inputCls} />
            <div className="grid grid-cols-2 gap-2">
              <input type="number" value={form.sortOrder} onChange={(e) => setForm({ ...form, sortOrder: Number(e.target.value) })} placeholder="الترتيب" className={inputCls} />
              <input type="number" value={form.discountPercent} onChange={(e) => setForm({ ...form, discountPercent: Number(e.target.value) })} placeholder="خصم %" className={inputCls} />
            </div>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} /> نشط</label>
            <div className="flex gap-2">
              <button onClick={save} className={btnGold}>💾 حفظ</button>
              {editing && <button onClick={() => { setEditing(false); setForm({ id: 0, name: "", description: "", image: "", sortOrder: 0, isActive: true, discountPercent: 0 }); }} className={btnDark}>إلغاء</button>}
            </div>
          </div>
        </Panel>
        <div className="lg:col-span-2">
          <Panel title={`الأقسام (${cats.length})`}>
            <div className="grid gap-2 sm:grid-cols-2">
              {cats.map((c: any) => (
                <div key={c.id} className="flex items-center gap-3 rounded-xl bg-white/5 p-3">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={c.image || ""} alt="" className="h-12 w-12 rounded-xl object-cover" />
                  <div className="min-w-0 flex-1">
                    <div className="font-bold">{c.name} {!c.isActive && <span className="text-xs text-red-400">(مخفي)</span>}</div>
                    <div className="text-xs text-white/50">{c.productCount} منتج • خصم {c.discountPercent}%</div>
                  </div>
                  <button onClick={() => { setForm({ id: c.id, name: c.name, description: c.description || "", image: c.image || "", sortOrder: c.sortOrder, isActive: c.isActive, discountPercent: Number(c.discountPercent) }); setEditing(true); }} className="rounded-lg bg-white/10 px-2.5 py-1 text-xs">✏️</button>
                  <button onClick={() => del(c.id)} className="rounded-lg bg-red-600/20 px-2.5 py-1 text-xs text-red-400">🗑</button>
                </div>
              ))}
              {cats.length === 0 && <div className="text-white/40">لا توجد أقسام</div>}
            </div>
          </Panel>
        </div>
      </div>
    </AdminShell>
  );
}
