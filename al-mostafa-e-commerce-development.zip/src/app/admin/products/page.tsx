"use client";
import { useEffect, useState } from "react";
import AdminShell, { Panel, inputCls, btnGold, btnDark } from "@/components/AdminShell";
import { formatPrice } from "@/lib/utils";

const EMPTY = { name: "", code: "", model: "", categoryId: "", companyId: "", companyName: "", brand: "", price: "", oldPrice: "", discountPrice: "", stock: "0", minStock: "5", size: "", color: "", description: "", keywords: "", images: [] as string[], isActive: true, isFeatured: false, isOffer: false };

export default function AdminProducts() {
  const [products, setProducts] = useState<any[]>([]);
  const [cats, setCats] = useState<any[]>([]);
  const [comps, setComps] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({ ...EMPTY });
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [msg, setMsg] = useState("");

  const load = (pg = page, query = q) => {
    setLoading(true);
    fetch(`/api/admin/products?page=${pg}&limit=20&q=${encodeURIComponent(query)}`).then((r) => r.json()).then((j) => {
      if (j.ok) { setProducts(j.products); setCats(j.cats); setComps(j.comps); setPages(j.pagination.pages || 1); setTotal(j.pagination.total); }
      setLoading(false);
    }).catch(() => setLoading(false));
  };

  useEffect(() => { load(1, ""); }, []);
  useEffect(() => {
    const t = setTimeout(() => { setPage(1); load(1, q); }, 400);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  useEffect(() => { load(page, q); }, [page]);

  const openNew = () => { setEditing(null); setForm({ ...EMPTY }); setShowForm(true); setMsg(""); };
  const openEdit = (p: any) => {
    setEditing(p);
    setForm({
      name: p.name, code: p.code, model: p.model || "", categoryId: p.categoryId || "", companyId: p.companyId || "",
      companyName: p.companyName || "", brand: p.brand || "", price: p.price, oldPrice: p.oldPrice || "",
      discountPrice: p.discountPrice || "", stock: String(p.stock), minStock: String(p.minStock),
      size: p.size || "", color: p.color || "", description: p.description || "", keywords: p.keywords || "",
      images: p.images || [], isActive: p.isActive, isFeatured: p.isFeatured, isOffer: p.isOffer,
    });
    setShowForm(true); setMsg("");
  };

  const upload = async (f: File) => {
    setUploading(true);
    const fd = new FormData();
    fd.append("file", f);
    const res = await fetch("/api/admin/upload", { method: "POST", body: fd });
    const j = await res.json();
    if (j.ok) setForm((s: any) => ({ ...s, images: [...s.images, j.url] }));
    else setMsg(j.message);
    setUploading(false);
  };

  const save = async () => {
    setSaving(true); setMsg("");
    try {
      const url = editing ? `/api/admin/products/${editing.id}` : "/api/admin/products";
      const res = await fetch(url, { method: editing ? "PUT" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      const j = await res.json();
      if (!j.ok) { setMsg(j.message); setSaving(false); return; }
      setShowForm(false);
      load(page, q);
    } catch { setMsg("حدث خطأ"); }
    setSaving(false);
  };

  const del = async (id: number) => {
    if (!confirm("حذف هذا المنتج نهائياً؟")) return;
    await fetch(`/api/admin/products/${id}`, { method: "DELETE" });
    load(page, q);
  };

  const toggle = async (id: number, field: string, val: boolean) => {
    await fetch(`/api/admin/products/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ [field]: !val }) });
    load(page, q);
  };

  const F = (k: string, v: any) => setForm((s: any) => ({ ...s, [k]: v }));

  return (
    <AdminShell title={`المنتجات (${total})`}>
      <div className="mb-4 flex flex-wrap gap-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔍 بحث بالاسم / الكود / الشركة…" className={`${inputCls} max-w-sm`} />
        <button onClick={openNew} className={btnGold}>➕ إضافة منتج</button>
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 p-4">
          <div className="mx-auto max-w-3xl rounded-2xl bg-[#0b1526] p-6">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="font-black text-[#e8c766]">{editing ? "تعديل المنتج" : "➕ منتج جديد"}</h3>
              <button onClick={() => setShowForm(false)} className="rounded-lg bg-white/10 px-3 py-1.5">✕</button>
            </div>
            {msg && <div className="mb-3 rounded-xl bg-red-600/15 p-3 text-sm text-red-400">{msg}</div>}
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="sm:col-span-2"><label className="text-xs text-white/60">اسم المنتج *</label><input value={form.name} onChange={(e) => F("name", e.target.value)} className={inputCls} /></div>
              <div><label className="text-xs text-white/60">الكود *</label><input value={form.code} onChange={(e) => F("code", e.target.value)} dir="ltr" className={inputCls} /></div>
              <div><label className="text-xs text-white/60">الموديل</label><input value={form.model} onChange={(e) => F("model", e.target.value)} className={inputCls} /></div>
              <div><label className="text-xs text-white/60">القسم</label>
                <select value={form.categoryId} onChange={(e) => F("categoryId", e.target.value)} className={inputCls}>
                  <option value="">— بدون قسم —</option>
                  {cats.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div><label className="text-xs text-white/60">الشركة</label>
                <select value={form.companyId} onChange={(e) => F("companyId", e.target.value)} className={inputCls}>
                  <option value="">— —</option>
                  {comps.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div><label className="text-xs text-white/60">اسم الشركة (نص)</label><input value={form.companyName} onChange={(e) => F("companyName", e.target.value)} className={inputCls} /></div>
              <div><label className="text-xs text-white/60">الماركة</label><input value={form.brand} onChange={(e) => F("brand", e.target.value)} className={inputCls} /></div>
              <div><label className="text-xs text-white/60">السعر *</label><input type="number" value={form.price} onChange={(e) => F("price", e.target.value)} className={inputCls} /></div>
              <div><label className="text-xs text-white/60">السعر القديم (قبل الخصم)</label><input type="number" value={form.oldPrice} onChange={(e) => F("oldPrice", e.target.value)} className={inputCls} /></div>
              <div><label className="text-xs text-white/60">سعر الخصم</label><input type="number" value={form.discountPrice} onChange={(e) => F("discountPrice", e.target.value)} className={inputCls} /></div>
              <div><label className="text-xs text-white/60">المخزون</label><input type="number" value={form.stock} onChange={(e) => F("stock", e.target.value)} className={inputCls} /></div>
              <div><label className="text-xs text-white/60">حد التنبيه</label><input type="number" value={form.minStock} onChange={(e) => F("minStock", e.target.value)} className={inputCls} /></div>
              <div><label className="text-xs text-white/60">المقاس</label><input value={form.size} onChange={(e) => F("size", e.target.value)} className={inputCls} /></div>
              <div><label className="text-xs text-white/60">اللون</label><input value={form.color} onChange={(e) => F("color", e.target.value)} className={inputCls} /></div>
              <div><label className="text-xs text-white/60">كلمات البحث</label><input value={form.keywords} onChange={(e) => F("keywords", e.target.value)} className={inputCls} /></div>
              <div className="sm:col-span-2"><label className="text-xs text-white/60">الوصف</label><textarea value={form.description} onChange={(e) => F("description", e.target.value)} rows={3} className={inputCls} /></div>
              <div className="sm:col-span-2">
                <label className="text-xs text-white/60">الصور</label>
                <div className="mt-1 flex flex-wrap gap-2">
                  {form.images.map((u: string, i: number) => (
                    <div key={i} className="relative">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={u} alt="" className="h-16 w-16 rounded-lg object-cover" />
                      <button onClick={() => F("images", form.images.filter((_: any, x: number) => x !== i))} className="absolute -left-1 -top-1 rounded-full bg-red-600 px-1 text-xs">✕</button>
                    </div>
                  ))}
                  <label className="flex h-16 w-16 cursor-pointer items-center justify-center rounded-lg border border-dashed border-white/30 text-2xl">
                    {uploading ? "⏳" : "+"}
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => { if (e.target.files?.[0]) upload(e.target.files[0]); }} />
                  </label>
                </div>
                <input value={form.images.join(", ")} readOnly className={`${inputCls} mt-2`} placeholder="أو الصق رابط صورة…" onFocus={(e) => e.target.select()} />
                <div className="mt-1 flex gap-2">
                  <input id="imgurl" placeholder="https://… رابط صورة خارجي" className={inputCls} dir="ltr" />
                  <button type="button" onClick={() => { const el = document.getElementById("imgurl") as HTMLInputElement; if (el?.value) { F("images", [...form.images, el.value]); el.value = ""; } }} className={btnDark}>إضافة</button>
                </div>
              </div>
              <div className="flex flex-wrap gap-4 sm:col-span-2">
                <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.isActive} onChange={(e) => F("isActive", e.target.checked)} /> ظاهر</label>
                <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.isFeatured} onChange={(e) => F("isFeatured", e.target.checked)} /> مميز ⭐</label>
                <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.isOffer} onChange={(e) => F("isOffer", e.target.checked)} /> عرض 🔥</label>
              </div>
            </div>
            <div className="mt-4 flex gap-2">
              <button onClick={save} disabled={saving} className={btnGold}>{saving ? "⏳ حفظ…" : "💾 حفظ"}</button>
              <button onClick={() => setShowForm(false)} className={btnDark}>إلغاء</button>
            </div>
          </div>
        </div>
      )}

      <Panel title="قائمة المنتجات">
        {loading ? <div className="text-white/50">جاري التحميل…</div> : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[800px] text-sm">
              <thead>
                <tr className="border-b border-white/10 text-right text-xs text-white/50">
                  <th className="p-2">المنتج</th><th className="p-2">الكود</th><th className="p-2">الشركة</th>
                  <th className="p-2">السعر</th><th className="p-2">المخزون</th><th className="p-2">الحالة</th><th className="p-2">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {products.map((p: any) => (
                  <tr key={p.id} className="border-b border-white/5 hover:bg-white/5">
                    <td className="p-2">
                      <div className="flex items-center gap-2">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img src={p.images?.[0] || ""} alt="" className="h-10 w-10 rounded-lg object-cover" />
                        <span className="line-clamp-1 max-w-[200px] font-bold">{p.name}</span>
                      </div>
                    </td>
                    <td className="p-2 font-mono text-xs" dir="ltr">{p.code}</td>
                    <td className="p-2 text-xs">{p.companyName}</td>
                    <td className="p-2 font-bold text-[#e8c766]">{formatPrice(p.discountPrice && Number(p.discountPrice) > 0 ? p.discountPrice : p.price)}</td>
                    <td className="p-2"><span className={`rounded-full px-2 py-0.5 text-xs font-bold ${p.stock <= 0 ? "bg-red-600/20 text-red-400" : p.stock <= p.minStock ? "bg-amber-600/20 text-amber-400" : "bg-emerald-600/20 text-emerald-400"}`}>{p.stock}</span></td>
                    <td className="p-2">
                      <div className="flex gap-1">
                        <button onClick={() => toggle(p.id, "isActive", p.isActive)} title="ظاهر/مخفي" className={`rounded-lg px-2 py-1 text-xs ${p.isActive ? "bg-emerald-600/20 text-emerald-400" : "bg-white/10 text-white/40"}`}>{p.isActive ? "👁" : "🚫"}</button>
                        <button onClick={() => toggle(p.id, "isFeatured", p.isFeatured)} title="مميز" className={`rounded-lg px-2 py-1 text-xs ${p.isFeatured ? "bg-[#c9a227]/30 text-[#e8c766]" : "bg-white/10 text-white/40"}`}>⭐</button>
                        <button onClick={() => toggle(p.id, "isOffer", p.isOffer)} title="عرض" className={`rounded-lg px-2 py-1 text-xs ${p.isOffer ? "bg-red-600/30 text-red-400" : "bg-white/10 text-white/40"}`}>🔥</button>
                      </div>
                    </td>
                    <td className="p-2">
                      <div className="flex gap-1">
                        <button onClick={() => openEdit(p)} className="rounded-lg bg-white/10 px-2.5 py-1 text-xs hover:bg-white/20">✏️</button>
                        <button onClick={() => del(p.id)} className="rounded-lg bg-red-600/20 px-2.5 py-1 text-xs text-red-400 hover:bg-red-600/40">🗑</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {products.length === 0 && <div className="p-8 text-center text-white/40">لا توجد منتجات</div>}
          </div>
        )}
        {pages > 1 && (
          <div className="mt-4 flex justify-center gap-2">
            <button disabled={page <= 1} onClick={() => setPage(page - 1)} className={btnDark}>→ السابق</button>
            <span className="rounded-xl gold-bg px-4 py-2 text-sm font-black text-[#0b1526]">{page} / {pages}</span>
            <button disabled={page >= pages} onClick={() => setPage(page + 1)} className={btnDark}>التالي ←</button>
          </div>
        )}
      </Panel>
    </AdminShell>
  );
}
