"use client";
import { useEffect, useState } from "react";
import AdminShell, { Panel, inputCls, btnGold, btnGoldStyle } from "@/components/AdminShell";

const FIELDS: Array<{ k: string; label: string; type?: string; wide?: boolean }> = [
  { k: "site_url", label: "رابط الموقع (https://...)" },
  { k: "store_name", label: "اسم المعرض (عربي)" },
  { k: "store_name_en", label: "الاسم بالإنجليزية" },
  { k: "manager", label: "صفحة الإدارة" },
  { k: "phone", label: "رقم الهاتف" },
  { k: "whatsapp", label: "رقم الواتساب (مهم)" },
  { k: "address", label: "العنوان" },
  { k: "maps_url", label: "رابط خرائط جوجل" },
  { k: "working_hours", label: "مواعيد العمل" },
  { k: "currency", label: "العملة" },
  { k: "tax_enabled", label: "تفعيل الضريبة (1/0)" },
  { k: "tax_percent", label: "نسبة الضريبة %" },
  { k: "invoice_prefix", label: "بادئة رقم الفاتورة" },
  { k: "facebook", label: "فيسبوك" },
  { k: "instagram", label: "إنستجرام" },
  { k: "tiktok", label: "تيك توك" },
  { k: "youtube", label: "يوتيوب" },
  { k: "store_desc", label: "وصف المعرض", type: "textarea", wide: true },
  { k: "hero_title", label: "عنوان الواجهة الرئيسية", wide: true },
  { k: "hero_subtitle", label: "وصف الواجهة الرئيسية", wide: true },
  { k: "invoice_notes", label: "ملاحظات الفاتورة", type: "textarea", wide: true },
];

export default function SettingsPage() {
  const [form, setForm] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/admin/settings").then((r) => r.json()).then((j) => {
      if (j.ok) setForm(j.settings);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const save = async () => {
    setMsg("");
    const res = await fetch("/api/admin/settings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const j = await res.json();
    setMsg(j.ok ? "✅ تم حفظ الإعدادات بنجاح" : j.message);
    setTimeout(() => setMsg(""), 3500);
  };

  return (
    <AdminShell title="إعدادات الموقع ⚙️">
      {loading ? (
        <div className="grid gap-3 sm:grid-cols-2">{Array.from({ length: 8 }).map((_, i) => <div key={i} className="h-16 animate-pulse rounded-2xl bg-white/5" />)}</div>
      ) : (
        <div className="grid gap-4 lg:grid-cols-3">
          <Panel title="معلومات المعرض">
            <div className="space-y-3">
              {FIELDS.filter((f) => !f.wide).map((f) => (
                <div key={f.k}>
                  <label className="text-xs text-white/55">{f.label}</label>
                  <input value={form[f.k] ?? ""} onChange={(e) => setForm({ ...form, [f.k]: e.target.value })} className={inputCls} />
                </div>
              ))}
            </div>
          </Panel>
          <Panel title="المحتوى والتواصل">
            <div className="space-y-3">
              {FIELDS.filter((f) => f.wide).map((f) => (
                <div key={f.k}>
                  <label className="text-xs text-white/55">{f.label}</label>
                  {f.type === "textarea" ? (
                    <textarea rows={3} value={form[f.k] ?? ""} onChange={(e) => setForm({ ...form, [f.k]: e.target.value })} className={inputCls} />
                  ) : (
                    <input value={form[f.k] ?? ""} onChange={(e) => setForm({ ...form, [f.k]: e.target.value })} className={inputCls} />
                  )}
                </div>
              ))}
            </div>
          </Panel>
          <div className="space-y-4">
            <Panel title="معاينة معلومات التواصل">
              <div className="space-y-2 text-sm text-white/70">
                <div className="flex items-center gap-2 rounded-xl bg-white/5 p-3"><span>🏪</span><b className="text-white">{form.store_name || "—"}</b></div>
                <div className="flex items-center gap-2 rounded-xl bg-white/5 p-3"><span>📞</span><span dir="ltr">{form.phone || "—"}</span></div>
                <div className="flex items-center gap-2 rounded-xl bg-white/5 p-3"><span>💬</span><span dir="ltr">{form.whatsapp || "—"}</span></div>
                <div className="flex items-center gap-2 rounded-xl bg-white/5 p-3"><span>📍</span><span>{form.address || "—"}</span></div>
                <div className="flex items-center gap-2 rounded-xl bg-white/5 p-3"><span>🕘</span><span>{form.working_hours || "—"}</span></div>
              </div>
              <a
                href={`https://wa.me/2${(form.whatsapp || "01147104601").replace(/[^0-9]/g, "").replace(/^0/, "").replace(/^20/, "")}`}
                target="_blank" rel="noopener noreferrer"
                className="mt-3 block rounded-2xl bg-[#25D366] py-2.5 text-center text-sm font-bold"
              >
                💬 اختبار رابط الواتساب
              </a>
            </Panel>
            <button onClick={save} className={`${btnGold} w-full py-3 text-base`} style={btnGoldStyle}>
              💾 حفظ جميع الإعدادات
            </button>
            {msg && <div className="rounded-xl bg-white/8 px-4 py-2.5 text-sm">{msg}</div>}
          </div>
        </div>
      )}
    </AdminShell>
  );
}
