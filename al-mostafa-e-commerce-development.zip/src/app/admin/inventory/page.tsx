"use client";
import { useEffect, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import AdminShell, { Panel, inputCls, btnGold, btnGoldStyle, btnDark } from "@/components/AdminShell";
import { formatDateTime } from "@/lib/utils";

function Body() {
  const sp = useSearchParams();
  const [tab, setTab] = useState("products");
  const [low, setLow] = useState(sp.get("low") === "1");
  const [q, setQ] = useState("");
  const [products, setProducts] = useState<any[]>([]);
  const [movements, setMovements] = useState<any[]>([]);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [form, setForm] = useState({ productId: "", type: "in", quantity: "", minStock: "", reason: "" });
  const [msg, setMsg] = useState("");

  const load = () => {
    const p = new URLSearchParams({ tab, page: String(page), limit: "25", q, ...(low ? { low: "1" } : {}) });
    fetch(`/api/admin/inventory?${p}`).then((r) => r.json()).then((j) => {
      if (j.ok) {
        setProducts(j.products || []);
        setMovements(j.movements || []);
        setPages(j.pagination?.pages || 1);
      }
    }).catch(() => {});
  };
  useEffect(load, [tab, page, low]);
  useEffect(() => { const t = setTimeout(() => { setPage(1); load(); }, 400); return () => clearTimeout(t); }, [q]);

  const submit = async () => {
    setMsg("");
    const res = await fetch("/api/admin/inventory", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productId: Number(form.productId), type: form.type, quantity: Number(form.quantity), minStock: form.minStock ? Number(form.minStock) : undefined, reason: form.reason }),
    });
    const j = await res.json();
    if (!j.ok) { setMsg(j.message); return; }
    setMsg(`✅ تم تحديث المخزون إلى ${j.newStock}`);
    setForm({ productId: "", type: "in", quantity: "", minStock: "", reason: "" });
    load();
  };

  return (
    <AdminShell title="المخزون 📦">
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <button onClick={() => { setTab("products"); setPage(1); }} className={`rounded-xl px-5 py-2.5 text-sm font-bold ${tab === "products" ? "text-[#0b1526]" : "border border-white/15 bg-white/8 text-white"}`} style={tab === "products" ? { background: "linear-gradient(135deg,#f3dc92,#c9a227)" } : undefined}>المنتجات</button>
        <button onClick={() => { setTab("movements"); setPage(1); }} className={`rounded-xl px-5 py-2.5 text-sm font-bold ${tab === "movements" ? "text-[#0b1526]" : "border border-white/15 bg-white/8 text-white"}`} style={tab === "movements" ? { background: "linear-gradient(135deg,#f3dc92,#c9a227)" } : undefined}>حركات المخزون</button>
        <label className="flex items-center gap-2 text-sm text-white/70">
          <input type="checkbox" checked={low} onChange={(e) => setLow(e.target.checked)} /> المنخفض فقط
        </label>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔍 بحث…" className={`${inputCls} max-w-[240px]`} />
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        <Panel title={tab === "products" ? "المنتجات والكميات" : "حركات المخزون"}>
          {tab === "products" ? (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[620px] text-[13px]">
                <thead>
                  <tr className="border-b border-white/10 text-right text-white/45">
                    <th className="p-2.5">المنتج</th><th className="p-2.5">الكود</th>
                    <th className="p-2.5">المخزون</th><th className="p-2.5">حد التنبيه</th><th className="p-2.5">الحالة</th>
                  </tr>
                </thead>
                <tbody>
                  {products.map((p) => (
                    <tr key={p.id} className="border-b border-white/5">
                      <td className="p-2.5 font-bold">{p.name}</td>
                      <td className="p-2.5 font-mono text-white/55" dir="ltr">{p.code}</td>
                      <td className="p-2.5 font-black">{p.stock}</td>
                      <td className="p-2.5 text-white/55">{p.minStock}</td>
                      <td className="p-2.5">
                        <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${
                          p.stock <= 0 ? "bg-red-600/20 text-red-300" : p.stock <= p.minStock ? "bg-amber-500/20 text-amber-300" : "bg-emerald-600/20 text-emerald-300"
                        }`}>
                          {p.stock <= 0 ? "نافد" : p.stock <= p.minStock ? "منخفض" : "جيد"}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {products.length === 0 && <tr><td colSpan={5} className="p-10 text-center text-white/40">لا توجد بيانات</td></tr>}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[620px] text-[13px]">
                <thead>
                  <tr className="border-b border-white/10 text-right text-white/45">
                    <th className="p-2.5">المنتج</th><th className="p-2.5">النوع</th><th className="p-2.5">الكمية</th>
                    <th className="p-2.5">قبل</th><th className="p-2.5">بعد</th><th className="p-2.5">السبب</th><th className="p-2.5">التاريخ</th>
                  </tr>
                </thead>
                <tbody>
                  {movements.map((m) => (
                    <tr key={m.id} className="border-b border-white/5">
                      <td className="p-2.5 font-bold">{m.productName}</td>
                      <td className="p-2.5">
                        <span className={`rounded-full px-2 py-0.5 text-[11px] font-bold ${m.type === "in" ? "bg-emerald-600/20 text-emerald-300" : m.type === "out" ? "bg-red-600/20 text-red-300" : "bg-blue-600/20 text-blue-300"}`}>
                          {m.type === "in" ? "إضافة" : m.type === "out" ? "صرف" : "تسوية"}
                        </span>
                      </td>
                      <td className="p-2.5 font-bold">{m.quantity}</td>
                      <td className="p-2.5 text-white/55">{m.previousStock}</td>
                      <td className="p-2.5 text-white/55">{m.newStock}</td>
                      <td className="p-2.5 text-white/55">{m.reason}</td>
                      <td className="p-2.5 text-white/45">{formatDateTime(m.createdAt)}</td>
                    </tr>
                  ))}
                  {movements.length === 0 && <tr><td colSpan={7} className="p-10 text-center text-white/40">لا توجد حركات</td></tr>}
                </tbody>
              </table>
            </div>
          )}
          {pages > 1 && (
            <div className="mt-4 flex justify-center gap-2">
              <button disabled={page <= 1} onClick={() => setPage(page - 1)} className={btnDark}>→ السابق</button>
              <span className="rounded-xl px-4 py-2 text-sm font-black text-[#0b1526]" style={{ background: "linear-gradient(135deg,#f3dc92,#c9a227)" }}>{page} / {pages}</span>
              <button disabled={page >= pages} onClick={() => setPage(page + 1)} className={btnDark}>التالي ←</button>
            </div>
          )}
        </Panel>

        <Panel title="➕ حركة مخزون">
          <div className="space-y-2">
            <select value={form.productId} onChange={(e) => setForm({ ...form, productId: e.target.value })} className={inputCls}>
              <option value="">اختر المنتج</option>
              {products.map((p) => <option key={p.id} value={p.id}>{p.name} ({p.code})</option>)}
            </select>
            <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className={inputCls}>
              <option value="in">إضافة مخزون</option>
              <option value="out">صرف مخزون</option>
              <option value="adjust">تسوية (تعيين الكمية)</option>
            </select>
            <input type="number" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} placeholder="الكمية" className={inputCls} dir="ltr" />
            <input type="number" value={form.minStock} onChange={(e) => setForm({ ...form, minStock: e.target.value })} placeholder="حد التنبيه (اختياري)" className={inputCls} dir="ltr" />
            <input value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} placeholder="السبب" className={inputCls} />
            <button onClick={submit} className={`${btnGold} w-full`} style={btnGoldStyle}>💾 حفظ الحركة</button>
            {msg && <div className="rounded-xl bg-white/8 px-3 py-2 text-xs">{msg}</div>}
          </div>
        </Panel>
      </div>
    </AdminShell>
  );
}

export default function InventoryPage() {
  return <Suspense fallback={<div>…</div>}><Body /></Suspense>;
}
