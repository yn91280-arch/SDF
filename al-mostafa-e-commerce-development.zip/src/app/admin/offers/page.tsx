"use client";
import { useEffect, useState } from "react";
import AdminShell, { Panel, inputCls, btnGold, btnGoldStyle, btnDark } from "@/components/AdminShell";

export default function AdminOffers() {
  const [offers, setOffers] = useState<any[]>([]);
  const [form, setForm] = useState({ id: 0, title: "", subtitle: "", image: "", linkType: "products", linkValue: "", discountPercent: "", isActive: true, sortOrder: 0 });
  const [editing, setEditing] = useState(false);
  const [msg, setMsg] = useState("");

  const load = () => {
    fetch("/api/admin/offers").then((r) => r.json()).then((j) => { if (j.ok) setOffers(j.offers); }).catch(() => {});
  };
  useEffect(() => { load(); }, []);

  const save = async () => {
    setMsg("");
    if (!form.title.trim()) { setMsg("أدخل عنوان العرض"); return; }
    const res = await fetch("/api/admin/offers", {
      method: editing ? "PUT" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form),
    });
    const j = await res.json();
    if (!j.ok) { setMsg(j.message); return; }
    setForm({ id: 0, title: "", subtitle: "", image: "", linkType: "products", linkValue: "", discountPercent: "", isActive: true, sortOrder: 0 });
    setEditing(false);
    load();
  };

  const del = async (id: number) => {
    if (!confirm("حذف هذا العرض؟")) return;
    await fetch(`/api/admin/offers?id=${id}`, { method: "DELETE" });
    load();
  };

  return (
    <AdminShell title="العروض والخصومات 🔥">
      <div className="grid gap-4 lg:grid-cols-3">
        <Panel title={editing ? "تعديل العرض" : "➕ عرض جديد"}>
          {msg && <div className="mb-2 rounded-xl bg-red-600/15 p-2 text-xs text-red-300">{msg}</div>}
          <div className="space-y-2">
            <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="عنوان العرض *" className={inputCls} />
            <input value={form.subtitle} onChange={(e) => setForm({ ...form, subtitle: e.target.value })} placeholder="الوصف" className={inputCls} />
            <input value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} placeholder="رابط الصورة https://…" dir="ltr" className={inputCls} />
            <div className="grid grid-cols-2 gap-2">
              <select value={form.linkType} onChange={(e) => setForm({ ...form, linkType: e.target.value })} className={inputCls}>
                <option value="products">المنتجات</option>
                <option value="category">قسم</option>
                <option value="company">شركة</option>
              </select>
              <input value={form.linkValue} onChange={(e) => setForm({ ...form, linkValue: e.target.value })} placeholder="القيمة (slug)" className={inputCls} />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input type="number" value={form.discountPercent} onChange={(e) => setForm({ ...form, discountPercent: e.target.value })} placeholder="نسبة الخصم %" className={inputCls} dir="ltr" />
              <input type="number" value={form.sortOrder} onChange={(e) => setForm({ ...form, sortOrder: Number(e.target.value) })} placeholder="الترتيب" className={inputCls} dir="ltr" />
            </div>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} /> نشط</label>
            <div className="flex gap-2">
              <button onClick={save} className={btnGold} style={btnGoldStyle}>💾 حفظ</button>
              {editing && <button onClick={() => { setEditing(false); setForm({ id: 0, title: "", subtitle: "", image: "", linkType: "products", linkValue: "", discountPercent: "", isActive: true, sortOrder: 0 }); }} className={btnDark}>إلغاء</button>}
            </div>
          </div>
        </Panel>
        <div className="lg:col-span-2">
          <Panel title={`العروض (${offers.length})`}>
            <div className="space-y-2">
              {offers.map((o) => (
                <div key={o.id} className="flex items-center gap-3 rounded-xl bg-white/[0.05] p-3">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={o.image || "/images/showroom-shelf.jpg"} alt="" className="h-14 w-20 rounded-lg object-cover" />
                  <div className="min-w-0 flex-1">
                    <div className="font-bold">{o.title} {!o.isActive && <span className="text-xs text-red-400">(مخفي)</span>}</div>
                    <div className="text-xs text-white/50">{o.subtitle} • {o.linkType}: {o.linkValue}</div>
                  </div>
                  <button onClick={() => { setForm({ id: o.id, title: o.title, subtitle: o.subtitle || "", image: o.image || "", linkType: o.linkType, linkValue: o.linkValue || "", discountPercent: o.discountPercent || "", isActive: o.isActive, sortOrder: o.sortOrder }); setEditing(true); }} className="rounded-lg bg-white/10 px-2.5 py-1 text-xs">✏️</button>
                  <button onClick={() => del(o.id)} className="rounded-lg bg-red-600/20 px-2.5 py-1 text-xs text-red-300">🗑</button>
                </div>
              ))}
              {offers.length === 0 && <div className="p-10 text-center text-white/40">لا توجد عروض بعد</div>}
            </div>
          </Panel>
        </div>
      </div>
    </AdminShell>
  );
}
