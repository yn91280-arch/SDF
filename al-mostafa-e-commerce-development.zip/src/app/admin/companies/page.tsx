"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import AdminShell, { Panel, inputCls, btnGold, btnDark } from "@/components/AdminShell";
import { formatDateTime } from "@/lib/utils";

export default function AdminCompanies() {
  const [comps, setComps] = useState<any[]>([]);
  const [form, setForm] = useState({ id: 0, name: "", description: "", logo: "", contactPhone: "", contactEmail: "", isActive: true });
  const [editing, setEditing] = useState(false);
  const [msg, setMsg] = useState("");

  const load = () => {
    fetch("/api/admin/companies").then((r) => r.json()).then((j) => { if (j.ok) setComps(j.companies); }).catch(() => {});
  };
  useEffect(load, []);

  const save = async () => {
    setMsg("");
    if (!form.name.trim()) { setMsg("أدخل اسم الشركة"); return; }
    const res = await fetch("/api/admin/companies", { method: editing ? "PUT" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const j = await res.json();
    if (!j.ok) { setMsg(j.message); return; }
    setForm({ id: 0, name: "", description: "", logo: "", contactPhone: "", contactEmail: "", isActive: true });
    setEditing(false);
    load();
  };

  const del = async (id: number) => {
    if (!confirm("حذف هذه الشركة؟")) return;
    await fetch(`/api/admin/companies?id=${id}`, { method: "DELETE" });
    load();
  };

  return (
    <AdminShell title="الشركات 🏭">
      <div className="grid gap-4 lg:grid-cols-3">
        <Panel title={editing ? "تعديل الشركة" : "➕ شركة جديدة"}>
          {msg && <div className="mb-2 rounded-xl bg-red-600/15 p-2 text-xs text-red-400">{msg}</div>}
          <div className="space-y-2">
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="اسم الشركة *" className={inputCls} />
            <input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="الوصف" className={inputCls} />
            <input value={form.logo} onChange={(e) => setForm({ ...form, logo: e.target.value })} placeholder="رابط الشعار" dir="ltr" className={inputCls} />
            <input value={form.contactPhone} onChange={(e) => setForm({ ...form, contactPhone: e.target.value })} placeholder="هاتف التواصل" className={inputCls} />
            <input value={form.contactEmail} onChange={(e) => setForm({ ...form, contactEmail: e.target.value })} placeholder="البريد" dir="ltr" className={inputCls} />
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} /> نشطة</label>
            <div className="flex gap-2">
              <button onClick={save} className={btnGold}>💾 حفظ</button>
              {editing && <button onClick={() => { setEditing(false); setForm({ id: 0, name: "", description: "", logo: "", contactPhone: "", contactEmail: "", isActive: true }); }} className={btnDark}>إلغاء</button>}
            </div>
          </div>
        </Panel>
        <div className="lg:col-span-2">
          <Panel title={`الشركات (${comps.length})`}>
            <div className="grid gap-2 sm:grid-cols-2">
              {comps.map((c: any) => (
                <div key={c.id} className="rounded-xl bg-white/5 p-3">
                  <div className="flex items-center gap-3">
                    <span className="flex h-11 w-11 items-center justify-center rounded-xl gold-bg font-black text-[#0b1526]">{c.name[0]}</span>
                    <div className="min-w-0 flex-1">
                      <div className="font-bold">{c.name}</div>
                      <div className="text-xs text-white/50">{c.productCount} منتج • آخر تحديث: {c.lastPriceUpdate ? formatDateTime(c.lastPriceUpdate) : "—"}</div>
                    </div>
                  </div>
                  <div className="mt-2 flex gap-1">
                    <Link href={`/admin/import?company=${c.id}`} className="rounded-lg bg-[#c9a227]/20 px-2.5 py-1 text-xs text-[#e8c766]">📥 استيراد قائمة</Link>
                    <button onClick={() => { setForm({ id: c.id, name: c.name, description: c.description || "", logo: c.logo || "", contactPhone: c.contactPhone || "", contactEmail: c.contactEmail || "", isActive: c.isActive }); setEditing(true); }} className="rounded-lg bg-white/10 px-2.5 py-1 text-xs">✏️</button>
                    <button onClick={() => del(c.id)} className="rounded-lg bg-red-600/20 px-2.5 py-1 text-xs text-red-400">🗑</button>
                  </div>
                </div>
              ))}
              {comps.length === 0 && <div className="text-white/40">لا توجد شركات</div>}
            </div>
          </Panel>
        </div>
      </div>
    </AdminShell>
  );
}
