"use client";
import { useEffect, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Header, Footer, FloatingWhatsApp, MobileNav } from "@/components/StoreChrome";
import ProductCard from "@/components/ProductCard";

function Body() {
  const sp = useSearchParams();
  const initial = sp.get("q") || "";
  const [q, setQ] = useState(initial);
  const [products, setProducts] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [settings, setSettings] = useState({ store_name: "معرض المصطفي", phone: "01147104601", whatsapp: "01147104601", manager: "" });
  const [cats, setCats] = useState<any[]>([]);

  useEffect(() => {
    fetch("/api/settings").then((r) => r.json()).then((j) => { if (j.ok) setSettings(j.settings); }).catch(() => {});
    fetch("/api/categories").then((r) => r.json()).then((j) => { if (j.ok) setCats(j.categories); }).catch(() => {});
  }, []);

  useEffect(() => { setQ(sp.get("q") || ""); }, [sp]);

  useEffect(() => {
    if (!q.trim()) { setProducts([]); setTotal(0); return; }
    setLoading(true);
    const t = setTimeout(() => {
      fetch(`/api/products?q=${encodeURIComponent(q)}&limit=48`).then((r) => r.json()).then((j) => {
        if (j.ok) { setProducts(j.products); setTotal(j.pagination.total); }
        setLoading(false);
      }).catch(() => setLoading(false));
    }, 350);
    return () => clearTimeout(t);
  }, [q]);

  const examples = ["خلاط حوض", "خلاط حوض أسود", "سيفون 2 بوصة", "سخان", "طقم حمام", "ماسورة"];

  return (
    <div className="min-h-screen">
      <Header s={settings} categories={cats} />
      <div className="bg-[#0b1526] py-10">
        <div className="mx-auto max-w-3xl px-4">
          <h1 className="text-center text-2xl font-black text-white sm:text-3xl">🔍 البحث الذكي</h1>
          <p className="mt-2 text-center text-sm text-white/60">ابحث بالاسم أو الكود أو الموديل أو الشركة أو المقاس أو اللون</p>
          <div className="relative mt-5">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="مثال: خلاط حوض أسود، سيفون 2 بوصة، GRO-1001…"
              autoFocus
              className="w-full rounded-2xl border border-[#c9a227]/40 bg-white/10 py-4 pe-4 ps-14 text-white placeholder:text-white/40 outline-none backdrop-blur focus:bg-white/15"
            />
            <span className="absolute start-4 top-1/2 -translate-y-1/2 text-xl">{loading ? "⏳" : "🔍"}</span>
          </div>
          <div className="mt-3 flex flex-wrap justify-center gap-2">
            {examples.map((e) => (
              <button key={e} onClick={() => setQ(e)} className="rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-xs text-white/80 hover:border-[#c9a227] hover:text-[#e8c766]">{e}</button>
            ))}
          </div>
        </div>
      </div>
      <div className="mx-auto max-w-7xl px-4 py-8">
        {!q.trim() ? (
          <div className="rounded-3xl bg-white p-16 text-center text-gray-500">
            <div className="text-6xl">🔍</div>
            <div className="mt-3 font-bold">اكتب كلمة البحث لعرض النتائج</div>
          </div>
        ) : loading ? (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => <div key={i} className="skeleton h-80 rounded-2xl" />)}
          </div>
        ) : products.length === 0 ? (
          <div className="rounded-3xl bg-white p-16 text-center">
            <div className="text-6xl">😕</div>
            <div className="mt-3 text-xl font-black">لا توجد نتائج لـ “{q}”</div>
            <p className="mt-2 text-gray-500">جرب كلمات أخرى أو تواصل معنا على الواتساب وسنساعدك</p>
            <a href={`https://wa.me/201147104601?text=${encodeURIComponent("السلام عليكم، أبحث عن: " + q)}`} target="_blank" rel="noopener noreferrer" className="mt-5 inline-block rounded-xl bg-[#25D366] px-6 py-3 font-bold text-white">💬 اسألنا واتساب</a>
          </div>
        ) : (
          <>
            <div className="mb-4 text-sm text-gray-500">تم العثور على <b className="text-[#0b1526]">{total}</b> نتيجة لـ “{q}”</div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {products.map((p) => <ProductCard key={p.id} whatsapp={settings.whatsapp} p={p} />)}
            </div>
          </>
        )}
      </div>
      <Footer s={settings} />
      <FloatingWhatsApp whatsapp={settings.whatsapp} storeName={settings.store_name} />
      <MobileNav />
    </div>
  );
}

export default function SearchPage() {
  return <Suspense fallback={<div className="p-10 text-center">جاري التحميل…</div>}><Body /></Suspense>;
}
