"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Header, Footer, FloatingWhatsApp, MobileNav } from "@/components/StoreChrome";
import { formatPrice, formatDateTime, ORDER_STATUS_AR } from "@/lib/utils";

export default function AccountPage() {
  const router = useRouter();
  const [customer, setCustomer] = useState<any>(null);
  const [orders, setOrders] = useState<any[]>([]);
  const [settings, setSettings] = useState({ store_name: "معرض المصطفي", phone: "01147104601", whatsapp: "01147104601", manager: "" });
  const [cats, setCats] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/settings").then((r) => r.json()).then((j) => { if (j.ok) setSettings(j.settings); }).catch(() => {});
    fetch("/api/categories").then((r) => r.json()).then((j) => { if (j.ok) setCats(j.categories); }).catch(() => {});
    fetch("/api/auth/me").then((r) => r.json()).then((j) => {
      if (j.ok && j.customer) { setCustomer(j.customer); setOrders(j.orders || []); }
      else router.push("/login");
      setLoading(false);
    }).catch(() => { router.push("/login"); });
  }, [router]);

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
  };

  if (loading) return <div className="min-h-screen p-10 text-center">جاري التحميل…</div>;
  if (!customer) return null;

  return (
    <div className="min-h-screen">
      <Header s={settings} categories={cats} />
      <div className="mx-auto max-w-5xl px-4 py-8">
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-3xl bg-[#0b1526] p-6 text-white">
          <div className="flex items-center gap-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl gold-bg text-2xl font-black text-[#0b1526]">{customer.name?.[0]}</div>
            <div>
              <div className="text-xl font-black">{customer.name}</div>
              <div className="text-sm text-white/60" dir="ltr">{customer.phone} {customer.email ? `• ${customer.email}` : ""}</div>
            </div>
          </div>
          <button onClick={logout} className="rounded-xl border border-white/20 px-5 py-2.5 text-sm font-bold hover:bg-white/10">تسجيل الخروج</button>
        </div>
        <h2 className="mt-8 text-xl font-black text-[#0b1526]">📦 طلباتي ({orders.length})</h2>
        {orders.length === 0 ? (
          <div className="mt-4 rounded-3xl bg-white p-12 text-center">
            <div className="text-5xl">📦</div>
            <div className="mt-3 font-bold">لم تقم بأي طلبات بعد</div>
            <Link href="/products" className="mt-4 inline-block rounded-xl gold-bg px-6 py-3 font-bold text-[#0b1526]">ابدأ التسوق</Link>
          </div>
        ) : (
          <div className="mt-4 space-y-3">
            {orders.map((o: any) => (
              <div key={o.id} className="rounded-2xl border bg-white p-4 card-shadow">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="font-mono font-bold" dir="ltr">{o.orderNumber}</div>
                  <span className="rounded-full bg-[#0b1526]/5 px-3 py-1 text-xs font-bold">{ORDER_STATUS_AR[o.status] || o.status}</span>
                </div>
                <div className="mt-2 flex flex-wrap justify-between gap-2 text-sm text-gray-500">
                  <span>{formatDateTime(o.createdAt)}</span>
                  <span className="font-black text-[#0b1526]">{formatPrice(o.total)}</span>
                </div>
                {o.customerAddress && <div className="mt-1 text-xs text-gray-400">📍 {o.customerAddress}</div>}
              </div>
            ))}
          </div>
        )}
      </div>
      <Footer s={settings} />
      <FloatingWhatsApp whatsapp={settings.whatsapp} storeName={settings.store_name} />
      <MobileNav />
    </div>
  );
}
