"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Header, Footer, FloatingWhatsApp, MobileNav } from "@/components/StoreChrome";
import { useCart } from "@/components/CartProvider";
import { formatPrice } from "@/lib/utils";

export default function CartPage() {
  const cart = useCart();
  const [settings, setSettings] = useState({ store_name: "معرض المصطفي", phone: "01147104601", whatsapp: "01147104601", manager: "" });
  const [cats, setCats] = useState<any[]>([]);

  useEffect(() => {
    fetch("/api/settings").then((r) => r.json()).then((j) => { if (j.ok) setSettings(j.settings); }).catch(() => {});
    fetch("/api/categories").then((r) => r.json()).then((j) => { if (j.ok) setCats(j.categories); }).catch(() => {});
  }, []);

  const waNum = (settings.whatsapp || "").replace(/[^0-9]/g, "");
  const waIntl = waNum.startsWith("20") ? waNum : "20" + waNum.replace(/^0/, "");
  const waMsg = encodeURIComponent(
    `🧾 طلب من الموقع\n———————————\n${cart.items.map((it, i) => `${i + 1}) ${it.name} × ${it.qty} = ${it.price * it.qty} ج.م`).join("\n")}\n———————————\nالإجمالي: ${cart.total} ج.م\n🏪 ${settings.store_name}`
  );

  return (
    <div className="min-h-screen">
      <Header s={settings} categories={cats} />
      <div className="mx-auto max-w-5xl px-4 py-8">
        <h1 className="text-3xl font-black text-[#0b1526]">🛒 سلة التسوق</h1>
        {cart.items.length === 0 ? (
          <div className="mt-6 rounded-3xl bg-white p-16 text-center">
            <div className="text-7xl">🛒</div>
            <div className="mt-4 text-xl font-black">سلتك فارغة</div>
            <p className="mt-2 text-gray-500">تصفح المنتجات وأضف ما يعجبك</p>
            <div className="mt-6 flex justify-center gap-3">
              <Link href="/products" className="rounded-xl gold-bg px-6 py-3 font-bold text-[#0b1526]">تصفح المنتجات</Link>
              <Link href="/offers" className="rounded-xl border px-6 py-3 font-bold">العروض 🔥</Link>
            </div>
          </div>
        ) : (
          <div className="mt-6 grid gap-6 lg:grid-cols-3">
            <div className="space-y-3 lg:col-span-2">
              {cart.items.map((it) => (
                <div key={it.id} className="flex gap-4 rounded-2xl border bg-white p-4 card-shadow">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={it.image} alt={it.name} className="h-24 w-24 shrink-0 rounded-xl object-cover" />
                  <div className="min-w-0 flex-1">
                    <Link href={`/products/${it.id}`} className="line-clamp-2 font-bold hover:text-[#a87f14]">{it.name}</Link>
                    <div className="mt-1 text-xs text-gray-500" dir="ltr">{it.code} • {it.company}</div>
                    <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
                      <div className="font-black text-[#0b1526]">{formatPrice(it.price)} <span className="text-xs font-normal text-gray-400">× {it.qty} = {formatPrice(it.price * it.qty)}</span></div>
                      <div className="flex items-center gap-2">
                        <button onClick={() => cart.setQty(it.id, it.qty - 1)} className="flex h-8 w-8 items-center justify-center rounded-lg border font-bold">−</button>
                        <span className="min-w-8 text-center font-black">{it.qty}</span>
                        <button onClick={() => cart.setQty(it.id, it.qty + 1)} className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#0b1526] font-bold text-white">+</button>
                        <button onClick={() => cart.remove(it.id)} className="ms-2 text-sm text-red-500">🗑 حذف</button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              <div className="flex justify-between">
                <Link href="/products" className="text-sm font-bold text-[#a87f14]">→ متابعة التسوق</Link>
                <button onClick={() => cart.clear()} className="text-sm text-red-500">إفراغ السلة</button>
              </div>
            </div>
            <div className="h-fit rounded-3xl bg-[#0b1526] p-6 text-white card-shadow">
              <div className="text-lg font-black text-[#e8c766]">ملخص الطلب</div>
              <div className="mt-4 space-y-2 text-sm">
                <div className="flex justify-between text-white/80"><span>عدد القطع</span><span>{cart.count}</span></div>
                <div className="flex justify-between text-white/80"><span>المجموع الفرعي</span><span>{formatPrice(cart.subtotal)}</span></div>
                {cart.discount > 0 && <div className="flex justify-between text-emerald-400"><span>إجمالي الخصم</span><span>− {formatPrice(cart.discount)}</span></div>}
                <div className="my-3 border-t border-white/15" />
                <div className="flex justify-between text-xl font-black"><span>الإجمالي</span><span className="text-[#e8c766]">{formatPrice(cart.total)}</span></div>
              </div>
              <Link href="/checkout" className="mt-5 block rounded-2xl gold-bg py-3.5 text-center font-black text-[#0b1526]">إتمام الطلب ←</Link>
              <a href={`https://wa.me/${waIntl}?text=${waMsg}`} target="_blank" rel="noopener noreferrer" className="mt-2 block rounded-2xl bg-[#25D366] py-3 text-center font-bold text-white">💬 إرسال الطلب واتساب</a>
            </div>
          </div>
        )}
      </div>
      <Footer s={settings} />
      <FloatingWhatsApp whatsapp={settings.whatsapp} storeName={settings.store_name} />
      <MobileNav />
    </div>
  );
}
