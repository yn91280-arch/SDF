"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Header, Footer, FloatingWhatsApp, MobileNav } from "@/components/StoreChrome";
import ProductCard from "@/components/ProductCard";

export default function OffersPage() {
  const [products, setProducts] = useState<any[]>([]);
  const [banners, setBanners] = useState<any[]>([]);
  const [settings, setSettings] = useState({ store_name: "معرض المصطفي", phone: "01147104601", whatsapp: "01147104601", manager: "" });
  const [cats, setCats] = useState<any[]>([]);

  useEffect(() => {
    fetch("/api/settings").then((r) => r.json()).then((j) => { if (j.ok) setSettings(j.settings); }).catch(() => {});
    fetch("/api/categories").then((r) => r.json()).then((j) => { if (j.ok) setCats(j.categories); }).catch(() => {});
    fetch("/api/offers").then((r) => r.json()).then((j) => { if (j.ok) setBanners(j.offers); }).catch(() => {});
    fetch("/api/products?offer=1&limit=48").then((r) => r.json()).then((j) => { if (j.ok) setProducts(j.products); }).catch(() => {});
  }, []);

  return (
    <div className="min-h-screen">
      <Header s={settings} categories={cats} />
      <div className="bg-gradient-to-l from-[#7a1010] to-[#0b1526] py-12 text-center text-white">
        <div className="text-5xl">🔥</div>
        <h1 className="mt-2 text-3xl font-black sm:text-4xl">العروض والخصومات</h1>
        <p className="mt-2 text-white/70">أقوى الخصومات لفترة محدودة — الكمية محدودة</p>
      </div>
      <div className="mx-auto max-w-7xl px-4 py-8">
        {banners.length > 0 && (
          <div className="grid gap-4 md:grid-cols-2">
            {banners.map((b: any) => (
              <div key={b.id} className="relative overflow-hidden rounded-3xl">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={b.image} alt={b.title} className="h-48 w-full object-cover sm:h-56" />
                <div className="absolute inset-0 bg-gradient-to-l from-black/80 to-transparent" />
                <div className="absolute inset-0 flex flex-col justify-center p-6">
                  <div className="text-xl font-black text-white sm:text-2xl">{b.title}</div>
                  {b.subtitle && <div className="text-sm text-white/75">{b.subtitle}</div>}
                </div>
              </div>
            ))}
          </div>
        )}
        {products.length === 0 ? (
          <div className="mt-6 rounded-3xl bg-white p-16 text-center text-gray-500">لا توجد عروض حالياً — تابعنا قريباً 🔥</div>
        ) : (
          <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {products.map((p) => <ProductCard key={p.id} whatsapp={settings.whatsapp} p={p} />)}
          </div>
        )}
        <div className="mt-8 text-center">
          <Link href="/products" className="rounded-xl border px-6 py-3 font-bold hover:bg-[#0b1526] hover:text-white">تصفح كل المنتجات</Link>
        </div>
      </div>
      <Footer s={settings} />
      <FloatingWhatsApp whatsapp={settings.whatsapp} storeName={settings.store_name} />
      <MobileNav />
    </div>
  );
}
