"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import Logo from "@/components/Logo";

declare global {
  interface Window {
    google?: any;
    __gsiReady?: boolean;
  }
}

export default function LoginPage() {
  const router = useRouter();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [remember, setRemember] = useState(true);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [googleReady, setGoogleReady] = useState(false);
  const googleBtn = useRef<HTMLDivElement>(null);

  const googleClientId = process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID || "";

  useEffect(() => {
    if (!googleClientId) return;
    const s = document.createElement("script");
    s.src = "https://accounts.google.com/gsi/client";
    s.async = true;
    s.defer = true;
    s.onload = () => {
      if (!window.google) return;
      window.google.accounts.id.initialize({
        client_id: googleClientId,
        callback: async (resp: { credential: string }) => {
          setLoading(true);
          const r = await fetch("/api/auth/google", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ idToken: resp.credential }),
          });
          const j = await r.json();
          if (j.ok) router.push("/account");
          else { setError(j.message || "تعذر تسجيل الدخول بجوجل"); setLoading(false); }
        },
      });
      if (googleBtn.current) {
        window.google.accounts.id.renderButton(googleBtn.current, { theme: "outline", size: "large", width: 320, locale: "ar", text: "signin_with" });
      }
      setGoogleReady(true);
    };
    document.body.appendChild(s);
  }, [googleClientId, router]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(""); setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier, password, remember }),
      });
      const j = await res.json();
      if (!j.ok) { setError(j.message); setLoading(false); return; }
      router.push("/account");
    } catch {
      setError("تعذر الاتصال بالخادم، حاول مرة أخرى");
      setLoading(false);
    }
  };

  const waLink = `https://wa.me/201147104601?text=${encodeURIComponent("السلام عليكم، نسيت كلمة المرور لحسابي في معرض المصطفي")}`;

  return (
    <div dir="rtl" className="relative flex min-h-screen w-full overflow-hidden bg-[#060b16]">
      {/* ============ LEFT / BRAND PANEL ============ */}
      <section className="relative hidden flex-1 lg:block">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: "url('/images/hero-bathroom.jpg')" }}
        />
        <div className="absolute inset-0 bg-gradient-to-l from-[#060b16] via-[#0b1526]/70 to-[#060b16]/95" />
        <div className="absolute inset-0 hero-pattern" />

        {/* corner script */}
        <div className="absolute left-8 top-8 text-right">
          <div className="font-lux text-[22px] leading-9 text-white drop-shadow-[0_2px_10px_rgba(0,0,0,0.8)]">
            جودة عالية ..<br />أسعار مناسبة ..<br />رضائك هدفنا
          </div>
          <svg width="150" height="12" viewBox="0 0 150 12" fill="none" className="mt-1">
            <path d="M2 9 C40 1 110 1 148 6" stroke="#c9a227" strokeWidth="2.5" strokeLinecap="round" />
          </svg>
        </div>

        {/* brand lockup */}
        <div className="relative mx-auto flex h-full max-w-[720px] flex-col items-center justify-center px-10 text-center">
          <Logo size={120} className="drop-shadow-[0_10px_40px_rgba(201,162,39,0.55)]" />
          <h1 className="mt-4 text-[62px] font-black leading-[1.25] tracking-tight">
            <span className="gold-text">معرض</span> <span className="text-white">المصطفى</span>
          </h1>
          <div className="mt-1 text-[26px] font-extrabold text-white">للأدوات الصحية والسباكة</div>
          <div className="mt-5 rounded-full border border-[#c9a227]/70 bg-[#0b1526]/70 px-10 py-2.5 text-lg font-bold text-[#e8c766] shadow-[0_0_30px_rgba(201,162,39,0.25)]">
            إدارة &nbsp;<span className="text-white">محمد محمود طلبة</span>
          </div>
          <div className="relative mt-8">
            <div className="font-lux text-3xl text-[#e8c766]">كل ما تحتاجه لراحة بيتك .. في مكان واحد</div>
            <svg width="360" height="14" viewBox="0 0 360 14" fill="none" className="mx-auto mt-1">
              <path d="M4 11 C90 2 270 2 356 8" stroke="#c9a227" strokeWidth="3" strokeLinecap="round" />
            </svg>
          </div>

          {/* feature icons */}
          <div className="mt-12 grid w-full grid-cols-4 gap-4">
            {[
              ["🛡️", "ضمان على المنتجات", "لجميع المنتجات"],
              ["⚙️", "خدمة عملاء متميزة", "دعم دائم في خدمتك"],
              ["🚚", "أسعار مميزة", "وفريات مستمرة"],
              ["✅", "منتجات أصلية", "من أفضل الشركات"],
            ].map(([i, t, s]) => (
              <div key={t} className="flex flex-col items-center">
                <div className="flex h-[68px] w-[68px] items-center justify-center rounded-full border-2 border-[#c9a227]/80 bg-[#0b1526]/80 text-2xl shadow-[0_0_24px_rgba(201,162,39,0.35)]">
                  {i}
                </div>
                <div className="mt-2 text-[15px] font-bold text-white">{t}</div>
                <div className="text-[12px] text-white/60">{s}</div>
              </div>
            ))}
          </div>
        </div>

        {/* product strip */}
        <div className="absolute bottom-0 left-0 right-0">
          <div className="h-[190px] w-full bg-cover bg-bottom opacity-90" style={{ backgroundImage: "url('/images/showroom-shelf.jpg')" }} />
          <svg viewBox="0 0 1440 60" preserveAspectRatio="none" className="absolute bottom-0 left-0 w-full">
            <path d="M0 40 C240 0 480 60 720 34 C960 8 1200 52 1440 24 L1440 60 L0 60 Z" fill="#c9a227" opacity="0.9" />
          </svg>
        </div>
      </section>

      {/* ============ RIGHT / LOGIN CARD ============ */}
      <section className="flex w-full flex-1 items-center justify-center bg-[#060b16] px-4 py-10 lg:max-w-[560px] lg:px-8">
        <div className="relative w-full max-w-[470px] rounded-[28px] border border-[#c9a227]/35 bg-gradient-to-b from-[#12203c] to-[#0a1428] p-8 shadow-[0_30px_90px_-20px_rgba(0,0,0,0.8)] sm:p-10">
          <div className="absolute left-7 top-7 text-4xl">🪔</div>
          <div className="text-center">
            <div className="text-lg font-bold text-white/85">مرحبا بك في</div>
            <h2 className="mt-1 text-[34px] font-black leading-tight">
              <span className="gold-text">معرض المصطفي</span>
            </h2>
            <div className="mt-1 text-[17px] font-bold text-white/85">للأدوات الصحية والسباكة</div>
            <p className="mx-auto mt-3 max-w-[300px] text-sm leading-6 text-white/55">
              سجل دخول للوصول إلى حسابك وإدارة الطلبات
            </p>
            <div className="mx-auto mt-4 h-[3px] w-16 rounded-full gold-bg" />
          </div>

          {error && (
            <div className="mt-5 rounded-2xl border border-red-500/30 bg-red-500/15 px-4 py-3 text-center text-sm font-bold text-red-200">
              {error}
            </div>
          )}

          <form onSubmit={submit} className="mt-7 space-y-4">
            <div className="relative">
              <span className="absolute inset-y-0 right-4 flex items-center text-white/45">👤</span>
              <input
                required
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder="رقم الهاتف أو اسم المستخدم"
                className="w-full rounded-2xl border border-white/12 bg-white/[0.07] py-4 pr-12 pl-4 text-white placeholder:text-white/40 outline-none transition focus:border-[#c9a227] focus:bg-white/[0.1]"
              />
            </div>
            <div className="relative">
              <span className="absolute inset-y-0 right-4 flex items-center text-white/45">🔒</span>
              <input
                required
                type={showPw ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="كلمة المرور"
                className="w-full rounded-2xl border border-white/12 bg-white/[0.07] py-4 pr-12 pl-12 text-white placeholder:text-white/40 outline-none transition focus:border-[#c9a227] focus:bg-white/[0.1]"
              />
              <button
                type="button"
                onClick={() => setShowPw(!showPw)}
                aria-label="إظهار كلمة المرور"
                className="absolute inset-y-0 left-4 flex items-center text-white/45 hover:text-[#e8c766]"
              >
                {showPw ? "🙈" : "👁"}
              </button>
            </div>
            <div className="flex items-center justify-between text-sm">
              <a href={waLink} target="_blank" rel="noopener noreferrer" className="font-semibold text-[#e8c766] hover:underline">
                نسيت كلمة المرور؟
              </a>
              <label className="flex cursor-pointer items-center gap-2 text-white/70">
                <input
                  type="checkbox"
                  checked={remember}
                  onChange={(e) => setRemember(e.target.checked)}
                  className="h-[18px] w-[18px] rounded accent-[#c9a227]"
                />
                تذكرني
              </label>
            </div>

            <button
              disabled={loading}
              className="w-full rounded-2xl py-4 text-lg font-black text-[#0b1526] shadow-[0_10px_30px_rgba(201,162,39,0.35)] transition hover:brightness-110 disabled:opacity-50"
              style={{ background: "linear-gradient(135deg,#f3dc92,#c9a227 45%,#e8c766 70%,#b98f1c)" }}
            >
              {loading ? "⏳ جاري الدخول…" : "تسجيل الدخول ←"}
            </button>
          </form>

          <div className="my-6 flex items-center gap-3 text-white/40">
            <div className="h-px flex-1 bg-white/15" />
            <span>أو</span>
            <div className="h-px flex-1 bg-white/15" />
          </div>

          {googleClientId ? (
            <div ref={googleBtn} className="flex justify-center [&_div]:!rounded-2xl" />
          ) : (
            <Link
              href="/register"
              className="flex w-full items-center justify-center gap-3 rounded-2xl bg-white py-3.5 text-base font-bold text-[#0b1526] transition hover:brightness-95"
            >
              <span className="text-xl">✨</span> إنشاء حساب جديد
            </Link>
          )}

          {googleClientId && (
            <div className="mt-3 text-center text-sm text-white/60">
              ليس لديك حساب؟ <Link href="/register" className="font-bold text-[#e8c766] hover:underline">إنشاء حساب جديد</Link>
            </div>
          )}

          <div className="mt-7 flex items-center justify-center gap-2 text-center text-xs text-white/45">
            🔒 أمان .. موقع معرض المصطفي
          </div>
          <div className="mt-3 text-center text-xs">
            <Link href="/" className="text-white/40 hover:text-[#e8c766]">→ العودة للموقع</Link>
          </div>
        </div>
      </section>
    </div>
  );
}
