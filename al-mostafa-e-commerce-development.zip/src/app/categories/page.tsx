"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Header, Footer, FloatingWhatsApp, MobileNav } from "@/components/StoreChrome";

export default function CategoriesPage() {
  const [cats, setCats] = useState<any[]>([]);
  const [settings, setSettings] = useState({ store_name: "معرض المصطفي", phone: "01147104601", whatsapp: "01147104601", manager: "" });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/settings").then((r) => r.json()).then((j) => { if (j.ok) setSettings(j.settings); }).catch(() => {});
    fetch("/api/categories").then((r) => r.json()).then((j) => { if (j.ok) setCats(j.categories); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen">
      <Header s={settings} categories={cats} />
      <div className="mx-auto max-w-7xl px-4 py-8">
        <h1 className="text-3xl font-black text-[#0b1526]">جميع الأقسام 📦</h1>
        <p className="mt-2 text-gray-500">اختر القسم المناسب وتصفح منتجاته</p>
        {loading ? (
          <div className="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => <div key={i} className="skeleton aspect-video rounded-2xl" />)}
          </div>
        ) : cats.length === 0 ? (
          <div className="mt-6 rounded-3xl bg-white p-16 text-center text-gray-500">لا توجد أقسام حالياً</div>
        ) : (
          <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {cats.map((c) => (
              <Link key={c.id} href={`/categories/${c.slug}`} className="group relative overflow-hidden rounded-3xl card-shadow">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={c.image || "https://images.unsplash.com/photo-1585704032915-c3400ca199e7?w=600&q=70"} alt={c.name} loading="lazy" className="aspect-video w-full object-cover transition duration-500 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#060b16]/90 via-[#060b16]/30 to-transparent" />
                <div className="absolute bottom-0 w-full p-5">
                  <div className="text-xl font-black text-white">{c.name}</div>
                  {c.description && <div className="mt-1 line-clamp-1 text-sm text-white/70">{c.description}</div>}
                  <div className="mt-2 flex items-center justify-between">
                    <span className="text-sm text-[#e8c766]">{c.productCount ?? 0} منتج</span>
                    <span className="rounded-xl gold-bg px-4 py-1.5 text-sm font-bold text-[#0b1526]">تصفح ←</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
      <Footer s={settings} />
      <FloatingWhatsApp whatsapp={settings.whatsapp} storeName={settings.store_name} />
      <MobileNav />
    </div>
  );
}
