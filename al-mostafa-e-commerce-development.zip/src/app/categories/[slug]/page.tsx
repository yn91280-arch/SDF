"use client";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { Header, Footer, FloatingWhatsApp, MobileNav } from "@/components/StoreChrome";
import ProductCard from "@/components/ProductCard";

export default function CategoryDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const [products, setProducts] = useState<any[]>([]);
  const [cat, setCat] = useState<any>(null);
  const [cats, setCats] = useState<any[]>([]);
  const [settings, setSettings] = useState({ store_name: "معرض المصطفي", phone: "01147104601", whatsapp: "01147104601", manager: "" });
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);

  useEffect(() => {
    fetch("/api/settings").then((r) => r.json()).then((j) => { if (j.ok) setSettings(j.settings); }).catch(() => {});
    fetch("/api/categories").then((r) => r.json()).then((j) => {
      if (j.ok) {
        setCats(j.categories);
        setCat(j.categories.find((c: any) => c.slug === slug));
      }
    }).catch(() => {});
  }, [slug]);

  useEffect(() => {
    setLoading(true);
    fetch(`/api/products?category=${encodeURIComponent(slug)}&page=${page}&limit=24`).then((r) => r.json()).then((j) => {
      if (j.ok) { setProducts(j.products); setPages(j.pagination.pages || 1); }
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [slug, page]);

  return (
    <div className="min-h-screen">
      <Header s={settings} categories={cats} />
      <div className="relative overflow-hidden bg-[#0b1526] py-12">
        <div className="absolute inset-0 hero-pattern" />
        <div className="relative mx-auto max-w-7xl px-4">
          <div className="flex items-center gap-2 text-sm text-white/60">
            <Link href="/" className="hover:text-white">الرئيسية</Link><span>/</span>
            <Link href="/categories" className="hover:text-white">الأقسام</Link><span>/</span>
            <span className="text-[#e8c766]">{cat?.name || slug}</span>
          </div>
          <h1 className="mt-2 text-3xl font-black text-white sm:text-4xl">{cat?.name || "القسم"}</h1>
          {cat?.description && <p className="mt-2 text-white/70">{cat.description}</p>}
        </div>
      </div>
      <div className="mx-auto max-w-7xl px-4 py-8">
        {loading ? (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => <div key={i} className="skeleton h-80 rounded-2xl" />)}
          </div>
        ) : products.length === 0 ? (
          <div className="rounded-3xl bg-white p-16 text-center">
            <div className="text-6xl">📦</div>
            <div className="mt-4 text-xl font-black">لا توجد منتجات في هذا القسم بعد</div>
            <Link href="/products" className="mt-4 inline-block rounded-xl gold-bg px-6 py-3 font-bold text-[#0b1526]">تصفح كل المنتجات</Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {products.map((p) => <ProductCard key={p.id} whatsapp={settings.whatsapp} p={p} />)}
          </div>
        )}
        {pages > 1 && (
          <div className="mt-8 flex justify-center gap-2">
            <button disabled={page <= 1} onClick={() => setPage(page - 1)} className="rounded-xl border bg-white px-4 py-2 font-bold disabled:opacity-40">→ السابق</button>
            <span className="rounded-xl bg-[#0b1526] px-4 py-2 font-bold text-white">{page} / {pages}</span>
            <button disabled={page >= pages} onClick={() => setPage(page + 1)} className="rounded-xl border bg-white px-4 py-2 font-bold disabled:opacity-40">التالي ←</button>
          </div>
        )}
      </div>
      <Footer s={settings} />
      <FloatingWhatsApp whatsapp={settings.whatsapp} storeName={settings.store_name} />
      <MobileNav />
    </div>
  );
}
