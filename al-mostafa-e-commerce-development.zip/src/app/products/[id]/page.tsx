"use client";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { Header, Footer, FloatingWhatsApp, MobileNav } from "@/components/StoreChrome";
import ProductCard from "@/components/ProductCard";
import { useCart } from "@/components/CartProvider";
import { effectivePrice, formatPrice } from "@/lib/utils";

export default function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const cart = useCart();
  const [p, setP] = useState<any>(null);
  const [related, setRelated] = useState<any[]>([]);
  const [settings, setSettings] = useState({ store_name: "معرض المصطفي", phone: "01147104601", whatsapp: "01147104601", manager: "" });
  const [cats, setCats] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [qty, setQty] = useState(1);
  const [imgIdx, setImgIdx] = useState(0);
  const [zoom, setZoom] = useState(false);

  useEffect(() => {
    fetch("/api/settings").then((r) => r.json()).then((j) => { if (j.ok) setSettings(j.settings); }).catch(() => {});
    fetch("/api/categories").then((r) => r.json()).then((j) => { if (j.ok) setCats(j.categories); }).catch(() => {});
    fetch(`/api/products/${id}`).then((r) => r.json()).then((j) => {
      if (j.ok) { setP(j.product); setRelated(j.related || []); }
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [id]);

  if (loading) {
    return <div className="min-h-screen bg-[#f6f4ee]"><div className="mx-auto max-w-7xl p-8"><div className="skeleton h-96 rounded-3xl" /></div></div>;
  }
  if (!p) {
    return (
      <div className="min-h-screen bg-[#f6f4ee] p-10 text-center">
        <div className="text-6xl">😕</div>
        <div className="mt-4 text-xl font-black">المنتج غير موجود</div>
        <Link href="/products" className="mt-4 inline-block rounded-xl gold-bg px-6 py-3 font-bold text-[#0b1526]">عودة للمنتجات</Link>
      </div>
    );
  }

  const images: string[] = p.images?.length > 0 ? p.images : ["https://images.unsplash.com/photo-1585704032915-c3400ca199e7?w=800&q=70"];
  const { final, old, pct } = effectivePrice({ price: p.price, discountPrice: p.discountPrice, oldPrice: p.oldPrice });
  const out = p.stock <= 0;
  const waNum = (settings.whatsapp || "").replace(/[^0-9]/g, "");
  const waIntl = waNum.startsWith("20") ? waNum : "20" + waNum.replace(/^0/, "");
  const waMsg = encodeURIComponent(`🛁 طلب جديد\n———————————\n📦 المنتج: ${p.name}\n🔢 الكود: ${p.code}\n🏭 الشركة: ${p.companyName || ""}\n💰 السعر: ${final} ج.م\n🔢 الكمية: ${qty}\n———————————\n🌐 الموقع: https://Sanitary-ware-store\n🏪 ${settings.store_name}`);

  return (
    <div className="min-h-screen">
      <Header s={settings} categories={cats} />
      <div className="mx-auto max-w-7xl px-4 py-8">
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <Link href="/" className="hover:text-[#a87f14]">الرئيسية</Link><span>/</span>
          <Link href="/products" className="hover:text-[#a87f14]">المنتجات</Link><span>/</span>
          <span className="font-bold text-[#0b1526]">{p.name}</span>
        </div>
        <div className="mt-6 grid gap-8 lg:grid-cols-2">
          <div>
            <div className="relative overflow-hidden rounded-3xl bg-white card-shadow">
              {pct > 0 && <span className="absolute left-4 top-4 z-10 rounded-full gold-bg px-4 py-1.5 font-black text-[#0b1526]">خصم {pct}%</span>}
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={images[imgIdx]} alt={p.name}
                onClick={() => setZoom(!zoom)}
                className={`aspect-square w-full cursor-zoom-in object-cover transition-transform duration-500 ${zoom ? "scale-150" : ""}`}
              />
            </div>
            {images.length > 1 && (
              <div className="mt-3 flex gap-2 overflow-x-auto">
                {images.map((im, i) => (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img key={i} src={im} alt="" onClick={() => setImgIdx(i)} className={`h-20 w-20 cursor-pointer rounded-xl object-cover ${i === imgIdx ? "ring-2 ring-[#c9a227]" : "opacity-70"}`} />
                ))}
              </div>
            )}
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="rounded-full bg-[#0b1526] px-3 py-1 font-bold text-white">{p.companyName || p.brand}</span>
              {p.model && <span className="rounded-full bg-gray-100 px-3 py-1">الموديل: {p.model}</span>}
              <span className="rounded-full bg-gray-100 px-3 py-1 font-mono" dir="ltr">{p.code}</span>
            </div>
            <h1 className="mt-3 text-2xl font-black leading-relaxed text-[#0b1526] sm:text-3xl">{p.name}</h1>
            <div className="mt-2 flex flex-wrap gap-3 text-sm text-gray-500">
              {p.size && <span>📐 المقاس: <b className="text-[#0b1526]">{p.size}</b></span>}
              {p.color && <span>🎨 اللون: <b className="text-[#0b1526]">{p.color}</b></span>}
              {p.brand && <span>🏷 الماركة: <b className="text-[#0b1526]">{p.brand}</b></span>}
            </div>
            <div className="mt-4 flex items-end gap-3">
              <div className="text-4xl font-black text-[#0b1526]">{formatPrice(final)}</div>
              {old && <div className="pb-1 text-lg text-gray-400 line-through">{formatPrice(old)}</div>}
            </div>
            <div className={`mt-2 w-fit rounded-full px-3 py-1 text-sm font-bold ${out ? "bg-red-50 text-red-600" : "bg-emerald-50 text-emerald-700"}`}>
              {out ? "✕ غير متوفر حالياً" : p.stock <= 5 ? `⚠ باقي ${p.stock} قطع فقط — اطلب الآن` : `✓ متوفر (${p.stock} قطعة)`}
            </div>
            {p.description && <p className="mt-4 leading-8 text-gray-600">{p.description}</p>}
            {p.specifications && Object.keys(p.specifications).length > 0 && (
              <div className="mt-4 rounded-2xl border bg-white p-4">
                <div className="font-black text-[#0b1526]">📋 المواصفات</div>
                <div className="mt-2 grid gap-2 text-sm">
                  {Object.entries(p.specifications as Record<string, string>).map(([k, v]) => (
                    <div key={k} className="flex justify-between border-b border-dashed py-1.5 last:border-0">
                      <span className="text-gray-500">{k}</span><span className="font-bold">{v}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
            <div className="mt-6 flex items-center gap-3">
              <span className="font-bold">الكمية:</span>
              <div className="flex items-center gap-2">
                <button onClick={() => setQty(Math.max(1, qty - 1))} className="flex h-10 w-10 items-center justify-center rounded-xl border bg-white text-xl font-bold">−</button>
                <span className="min-w-10 text-center text-lg font-black">{qty}</span>
                <button onClick={() => setQty(Math.min(p.stock || 99, qty + 1))} className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#0b1526] text-xl font-bold text-white">+</button>
              </div>
            </div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <button
                disabled={out}
                onClick={() => cart.add({ id: p.id, name: p.name, code: p.code, company: p.companyName, price: Number(final), oldPrice: old ? Number(old) : null, image: images[0] }, qty)}
                className="rounded-2xl bg-[#0b1526] py-4 font-black text-white transition hover:bg-[#1a2c52] disabled:opacity-40"
              >
                🛒 أضف إلى السلة
              </button>
              <a href={`https://wa.me/${waIntl}?text=${waMsg}`} target="_blank" rel="noopener noreferrer" className="rounded-2xl bg-[#25D366] py-4 text-center font-black text-white">
                💬 اطلب عبر واتساب
              </a>
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2 text-center text-xs text-gray-500">
              <div className="rounded-xl bg-white p-3">🚚<br />توصيل سريع</div>
              <div className="rounded-xl bg-white p-3">✅<br />منتج أصلي</div>
              <div className="rounded-xl bg-white p-3">🔄<br />إمكانية الاستبدال</div>
            </div>
          </div>
        </div>
        {related.length > 0 && (
          <div className="mt-12">
            <h2 className="text-2xl font-black text-[#0b1526]">منتجات مشابهة</h2>
            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {related.map((r: any) => <ProductCard key={r.id} whatsapp={settings.whatsapp} p={r} />)}
            </div>
          </div>
        )}
      </div>
      <Footer s={settings} />
      <FloatingWhatsApp whatsapp={settings.whatsapp} storeName={settings.store_name} />
      <MobileNav />
    </div>
  );
}
