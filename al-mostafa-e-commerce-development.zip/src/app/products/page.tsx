"use client";
import { useEffect, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { Header, Footer, FloatingWhatsApp, MobileNav } from "@/components/StoreChrome";
import ProductCard from "@/components/ProductCard";

type P = { id: number; name: string; code: string; model?: string | null; companyName?: string | null; brand?: string | null; price: string; oldPrice?: string | null; discountPrice?: string | null; stock: number; size?: string | null; color?: string | null; images: string[] };

function Body() {
  const sp = useSearchParams();
  const [products, setProducts] = useState<P[]>([]);
  const [cats, setCats] = useState<Array<{ id: number; name: string; slug: string }>>([]);
  const [comps, setComps] = useState<Array<{ id: number; name: string; slug: string }>>([]);
  const [settings, setSettings] = useState({ store_name: "معرض المصطفي", phone: "01147104601", whatsapp: "01147104601", manager: "" });
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [category, setCategory] = useState(sp.get("category") || "");
  const [company, setCompany] = useState(sp.get("company") || "");
  const [sort, setSort] = useState("new");
  const [q, setQ] = useState(sp.get("q") || "");

  useEffect(() => {
    fetch("/api/settings").then((r) => r.json()).then((j) => { if (j.ok) setSettings(j.settings); }).catch(() => {});
    fetch("/api/categories").then((r) => r.json()).then((j) => { if (j.ok) setCats(j.categories); }).catch(() => {});
    fetch("/api/companies").then((r) => r.json()).then((j) => { if (j.ok) setComps(j.companies); }).catch(() => {});
  }, []);

  useEffect(() => {
    setCategory(sp.get("category") || "");
    setCompany(sp.get("company") || "");
    setQ(sp.get("q") || "");
    setPage(1);
  }, [sp]);

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams({ page: String(page), limit: "24", sort });
    if (category) params.set("category", category);
    if (company) params.set("company", company);
    if (q) params.set("q", q);
    if (sp.get("featured")) params.set("featured", "1");
    fetch(`/api/products?${params}`).then((r) => r.json()).then((j) => {
      if (j.ok) { setProducts(j.products); setPages(j.pagination.pages || 1); }
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [page, category, company, sort, q, sp]);

  return (
    <div className="min-h-screen">
      <Header s={settings} categories={cats} />
      <div className="mx-auto max-w-7xl px-4 py-8">
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <Link href="/" className="hover:text-[#a87f14]">الرئيسية</Link>
          <span>/</span>
          <span className="font-bold text-[#0b1526]">المنتجات</span>
        </div>
        <h1 className="mt-2 text-3xl font-black text-[#0b1526]">تصفح المنتجات 🛁</h1>
        <div className="mt-6 grid gap-3 rounded-2xl border bg-white p-4 sm:grid-cols-4">
          <input value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} placeholder="بحث سريع…" className="rounded-xl border px-4 py-2.5 text-sm outline-none focus:border-[#c9a227]" />
          <select value={category} onChange={(e) => { setCategory(e.target.value); setPage(1); }} className="rounded-xl border px-4 py-2.5 text-sm">
            <option value="">كل الأقسام</option>
            {cats.map((c) => <option key={c.id} value={c.slug}>{c.name}</option>)}
          </select>
          <select value={company} onChange={(e) => { setCompany(e.target.value); setPage(1); }} className="rounded-xl border px-4 py-2.5 text-sm">
            <option value="">كل الشركات</option>
            {comps.map((c) => <option key={c.id} value={c.slug}>{c.name}</option>)}
          </select>
          <select value={sort} onChange={(e) => setSort(e.target.value)} className="rounded-xl border px-4 py-2.5 text-sm">
            <option value="new">الأحدث</option>
            <option value="popular">الأكثر مبيعاً</option>
            <option value="price_asc">السعر: من الأقل</option>
            <option value="price_desc">السعر: من الأعلى</option>
          </select>
        </div>
        {loading ? (
          <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="overflow-hidden rounded-2xl bg-white">
                <div className="skeleton aspect-[4/3]" />
                <div className="space-y-2 p-4"><div className="skeleton h-4 rounded" /><div className="skeleton h-4 w-2/3 rounded" /></div>
              </div>
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="mt-6 rounded-3xl bg-white p-16 text-center">
            <div className="text-6xl">🔍</div>
            <div className="mt-4 text-xl font-black">لا توجد منتجات مطابقة</div>
            <p className="mt-2 text-gray-500">جرب كلمات بحث مختلفة أو تصفح الأقسام</p>
            <Link href="/products" className="mt-6 inline-block rounded-xl gold-bg px-6 py-3 font-bold text-[#0b1526]">عرض كل المنتجات</Link>
          </div>
        ) : (
          <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {products.map((p) => <ProductCard key={p.id} whatsapp={settings.whatsapp} p={p} />)}
          </div>
        )}
        {pages > 1 && (
          <div className="mt-8 flex justify-center gap-2">
            <button disabled={page <= 1} onClick={() => setPage(page - 1)} className="rounded-xl border bg-white px-4 py-2 font-bold disabled:opacity-40">→ السابق</button>
            <span className="rounded-xl bg-[#0b1526] px-4 py-2 font-bold text-white">{page} / {pages}</span>
            <button disabled={page >= pages} onClick={() => setPage(page + 1)} className="rounded-xl border bg-white px-4 py-2 font-bold disabled:opacity-40">التالي ←</button>
          </div>
        )}
      </div>
      <Footer s={settings} />
      <FloatingWhatsApp whatsapp={settings.whatsapp} storeName={settings.store_name} />
      <MobileNav />
    </div>
  );
}

export default function ProductsPage() {
  return <Suspense fallback={<div className="p-10 text-center">جاري التحميل…</div>}><Body /></Suspense>;
}
