import Link from "next/link";
import { Header, Footer, FloatingWhatsApp, MobileNav } from "@/components/StoreChrome";
import { getStoreChrome } from "@/lib/store-data";

export const dynamic = "force-dynamic";

export default async function AboutPage() {
  const { settings, categories } = await getStoreChrome();
  return (
    <div className="min-h-screen">
      <Header s={settings} categories={categories} />
      <div className="marble-bg py-16 text-center text-white">
        <h1 className="text-4xl font-black">من نحن</h1>
        <p className="mt-2 text-[#e8c766]">{settings.manager}</p>
      </div>
      <div className="mx-auto max-w-4xl px-4 py-10">
        <div className="rounded-3xl bg-white p-8 card-shadow">
          <h2 className="text-2xl font-black text-[#0b1526]">🏛 {settings.store_name}</h2>
          <p className="mt-4 leading-9 text-gray-600">
            {settings.store_desc} — نحن معرض متخصص في الأدوات الصحية ومستلزمات السباكة، نوفر لعملائنا أفضل المنتجات
            من أفضل الشركات العالمية والمحلية بأسعار مميزة وجودة مضمونة.
          </p>
          <p className="mt-3 leading-9 text-gray-600">
            منذ تأسيسنا ونحن نضع ثقة العميل في المقدمة: منتجات أصلية 100%، ضمان حقيقي، أسعار منافسة،
            وخدمة ما بعد بيع محترمة. سواء كنت تجهز حمامك أو مطبخك أو مشروعك بالكامل — ستجد كل ما تحتاجه في مكان واحد.
          </p>
          <div className="mt-6 grid gap-3 sm:grid-cols-3">
            {[
              ["✅", "منتجات أصلية", "وكيل معتمد"],
              ["💰", "أسعار مميزة", "عروض مستمرة"],
              ["🚚", "توصيل سريع", "لجميع المحافظات"],
            ].map(([i, t, d]) => (
              <div key={t} className="rounded-2xl bg-[#faf8f2] p-5 text-center">
                <div className="text-3xl">{i}</div>
                <div className="mt-1 font-black">{t}</div>
                <div className="text-xs text-gray-500">{d}</div>
              </div>
            ))}
          </div>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link href="/products" className="rounded-xl gold-bg px-6 py-3 font-bold text-[#0b1526]">تصفح المنتجات</Link>
            <Link href="/contact" className="rounded-xl border px-6 py-3 font-bold">تواصل معنا</Link>
          </div>
        </div>
      </div>
      <Footer s={settings} />
      <FloatingWhatsApp whatsapp={settings.whatsapp} storeName={settings.store_name} />
      <MobileNav />
    </div>
  );
}
