import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { CartProvider } from "@/components/CartProvider";
import { getSettings } from "@/lib/site-settings";

export async function generateMetadata(): Promise<Metadata> {
  let storeName = "معرض المصطفي";
  let desc = "كل ما تحتاجه لتجهيز حمامك ومطبخك في مكان واحد";
  try {
    const s = await getSettings();
    storeName = s.store_name || storeName;
    desc = s.store_desc || desc;
  } catch {}
  return {
    title: {
      default: `${storeName} | أدوات صحية وسباكة`,
      template: `%s | ${storeName}`,
    },
    description: desc,
    keywords: ["أدوات صحية", "سباكة", "خلاطات", "أحواض", "حمامات", "معرض المصطفي", "سخانات", "دش"],
    openGraph: {
      title: storeName,
      description: desc,
      type: "website",
      locale: "ar_EG",
    },
    robots: "index, follow",
  };
}

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800;900&family=Amiri:wght@400;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen antialiased">
        <CartProvider>{children}</CartProvider>
      </body>
    </html>
  );
}
