import { Header, Footer, FloatingWhatsApp, MobileNav } from "@/components/StoreChrome";
import { getStoreChrome } from "@/lib/store-data";
import { getSettings } from "@/lib/site-settings";

export const dynamic = "force-dynamic";

export default async function ContactPage() {
  const { settings, categories } = await getStoreChrome();
  const full = await getSettings();
  const waNum = (settings.whatsapp || "").replace(/[^0-9]/g, "");
  const waIntl = waNum.startsWith("20") ? waNum : "20" + waNum.replace(/^0/, "");
  return (
    <div className="min-h-screen">
      <Header s={settings} categories={categories} />
      <div className="bg-[#0b1526] py-14 text-center text-white">
        <h1 className="text-4xl font-black">اتصل بنا 📞</h1>
        <p className="mt-2 text-white/60">يسعدنا خدمتك في أي وقت</p>
      </div>
      <div className="mx-auto grid max-w-5xl gap-4 px-4 py-10 md:grid-cols-2">
        <div className="rounded-3xl bg-white p-6 card-shadow">
          <div className="font-black text-[#0b1526]">معلومات التواصل</div>
          <div className="mt-4 space-y-3 text-sm">
            <div className="flex items-center gap-3 rounded-2xl bg-[#faf8f2] p-4"><span className="text-2xl">📞</span><div><div className="text-gray-500">الهاتف</div><div className="font-black" dir="ltr">{settings.phone}</div></div></div>
            <div className="flex items-center gap-3 rounded-2xl bg-[#faf8f2] p-4"><span className="text-2xl">💬</span><div><div className="text-gray-500">واتساب</div><div className="font-black" dir="ltr">{settings.whatsapp}</div></div></div>
            <div className="flex items-center gap-3 rounded-2xl bg-[#faf8f2] p-4"><span className="text-2xl">📍</span><div><div className="text-gray-500">العنوان</div><div className="font-bold">{full.address}</div></div></div>
            <div className="flex items-center gap-3 rounded-2xl bg-[#faf8f2] p-4"><span className="text-2xl">🕘</span><div><div className="text-gray-500">مواعيد العمل</div><div className="font-bold">{full.working_hours}</div></div></div>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-2">
            <a href={`https://wa.me/${waIntl}`} target="_blank" rel="noopener noreferrer" className="rounded-xl bg-[#25D366] py-3 text-center font-bold text-white">💬 واتساب</a>
            <a href={`tel:${settings.phone}`} className="rounded-xl bg-[#0b1526] py-3 text-center font-bold text-white">📞 اتصال</a>
          </div>
        </div>
        <div className="rounded-3xl bg-white p-6 card-shadow">
          <div className="font-black text-[#0b1526]">أرسل استفسارك عبر واتساب</div>
          <p className="mt-2 text-sm text-gray-500">اكتب رسالتك وسنرد عليك في أسرع وقت</p>
          <form
            className="mt-4 space-y-3"
            onSubmit={(e) => {
              e.preventDefault();
            }}
            action={`https://wa.me/${waIntl}`}
          >
            <ContactForm waIntl={waIntl} storeName={settings.store_name} />
          </form>
        </div>
      </div>
      <Footer s={settings} />
      <FloatingWhatsApp whatsapp={settings.whatsapp} storeName={settings.store_name} />
      <MobileNav />
    </div>
  );
}

function ContactForm({ waIntl, storeName }: { waIntl: string; storeName: string }) {
  return (
    <div className="space-y-3">
      <input id="cf-name" required placeholder="الاسم" className="w-full rounded-xl border px-4 py-3 outline-none focus:border-[#c9a227]" />
      <input id="cf-phone" required placeholder="رقم الهاتف" className="w-full rounded-xl border px-4 py-3 outline-none focus:border-[#c9a227]" />
      <textarea id="cf-msg" required placeholder="اكتب استفسارك…" rows={4} className="w-full rounded-xl border px-4 py-3 outline-none focus:border-[#c9a227]" />
      <button
        type="button"
        onClick={() => {
          const n = (document.getElementById("cf-name") as HTMLInputElement)?.value || "";
          const p = (document.getElementById("cf-phone") as HTMLInputElement)?.value || "";
          const m = (document.getElementById("cf-msg") as HTMLTextAreaElement)?.value || "";
          const text = `استفسار من موقع ${storeName}\n———————————\nالاسم: ${n}\nالهاتف: ${p}\nالرسالة: ${m}`;
          window.open(`https://wa.me/${waIntl}?text=${encodeURIComponent(text)}`, "_blank");
        }}
        className="w-full rounded-xl bg-[#25D366] py-3.5 font-black text-white"
      >
        إرسال عبر واتساب 💬
      </button>
    </div>
  );
}
