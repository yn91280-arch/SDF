export function cn(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

export function formatPrice(value: number | string | null | undefined, currency = "ج.م"): string {
  const n = typeof value === "string" ? parseFloat(value) : value ?? 0;
  if (isNaN(n as number)) return `${currency} 0`;
  return `${currency} ${Number(n).toLocaleString("ar-EG", { maximumFractionDigits: 2 })}`;
}

export function formatNumber(n: number | string | null | undefined): string {
  const v = typeof n === "string" ? parseFloat(n) : n ?? 0;
  return Number(v || 0).toLocaleString("ar-EG");
}

export function formatDate(d: Date | string | null | undefined): string {
  if (!d) return "—";
  try {
    const date = typeof d === "string" ? new Date(d) : d;
    return date.toLocaleDateString("ar-EG", { year: "numeric", month: "long", day: "numeric" });
  } catch {
    return "—";
  }
}

export function formatDateTime(d: Date | string | null | undefined): string {
  if (!d) return "—";
  try {
    const date = typeof d === "string" ? new Date(d) : d;
    return date.toLocaleString("ar-EG", { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
  } catch {
    return "—";
  }
}

export function slugify(input: string): string {
  return input
    .trim()
    .replace(/\s+/g, "-")
    .replace(/[^\u0600-\u06FFa-zA-Z0-9\-_]/g, "")
    .slice(0, 180) || `item-${Date.now()}`;
}

export function discountPercent(price: number | string, oldPrice?: number | string | null): number {
  const p = Number(price) || 0;
  const o = Number(oldPrice) || 0;
  if (!o || o <= p) return 0;
  return Math.round(((o - p) / o) * 100);
}

export function effectivePrice(p: { price: number | string; discountPrice?: number | string | null; oldPrice?: number | string | null }): { final: number; old: number | null; pct: number } {
  const base = Number(p.price) || 0;
  const disc = p.discountPrice ? Number(p.discountPrice) : 0;
  const old = p.oldPrice ? Number(p.oldPrice) : 0;
  if (disc > 0 && disc < base) {
    return { final: disc, old: base, pct: discountPercent(disc, base) };
  }
  if (old > base) {
    return { final: base, old, pct: discountPercent(base, old) };
  }
  return { final: base, old: null, pct: 0 };
}

export function sanitizeText(s: unknown, max = 2000): string {
  if (typeof s !== "string") return "";
  return s.replace(/[<>"'`]/g, "").trim().slice(0, max);
}

export function isValidPhone(phone: string): boolean {
  return /^[0-9+\-\s]{8,20}$/.test(phone.trim());
}

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

/** Strong password: at least 8 chars, contains letters and digits */
export function isStrongPassword(pw: string): boolean {
  return typeof pw === "string" && pw.length >= 8 && /[a-zA-Z\u0600-\u06FF]/.test(pw) && /[0-9]/.test(pw);
}

export function passwordStrength(pw: string): { score: number; label: string; color: string } {
  if (!pw) return { score: 0, label: "أدخل كلمة المرور", color: "#6b7280" };
  let score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (/[0-9]/.test(pw) && /[a-zA-Z\u0600-\u06FF]/.test(pw)) score++;
  if (/[^A-Za-z0-9\u0600-\u06FF]/.test(pw)) score++;
  const labels = ["ضعيفة جداً", "ضعيفة", "متوسطة", "قوية", "قوية جداً"];
  const colors = ["#dc2626", "#ea580c", "#ca8a04", "#16a34a", "#059669"];
  return { score: Math.min(score, 4), label: labels[Math.min(score, 4)], color: colors[Math.min(score, 4)] };
}

export function generateOrderNumber(): string {
  const d = new Date();
  const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `ORD-${ymd}-${rand}`;
}

export function generateInvoiceNumber(): string {
  const d = new Date();
  const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `INV-${ymd}-${rand}`;
}

export const ORDER_STATUS_AR: Record<string, string> = {
  new: "جديد",
  processing: "قيد المعالجة",
  preparing: "قيد التجهيز",
  ready: "جاهز",
  delivered: "تم التوصيل",
  completed: "مكتمل",
  cancelled: "ملغي",
};

export const INVOICE_STATUS_AR: Record<string, string> = {
  unpaid: "غير مدفوعة",
  partial: "مدفوعة جزئياً",
  paid: "مدفوعة",
};
