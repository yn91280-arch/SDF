import { getSettings } from "./site-settings";
import { ensureSeed } from "./seed";
import { db } from "@/db";
import { categories } from "@/db/schema";
import { eq, asc } from "drizzle-orm";

export async function getStoreChrome() {
  await ensureSeed();
  const s = await getSettings();
  let cats: Array<{ id: number; name: string; slug: string }> = [];
  try {
    const rows = await db.select().from(categories).where(eq(categories.isActive, true)).orderBy(asc(categories.sortOrder));
    cats = rows.map((c) => ({ id: c.id, name: c.name, slug: c.slug }));
  } catch {}
  return {
    settings: {
      store_name: s.store_name,
      phone: s.phone,
      whatsapp: s.whatsapp,
      manager: s.manager,
      hero_title: s.hero_title,
      hero_subtitle: s.hero_subtitle,
      store_desc: s.store_desc,
      currency: s.currency,
      address: s.address,
      working_hours: s.working_hours,
    },
    categories: cats,
  };
}
