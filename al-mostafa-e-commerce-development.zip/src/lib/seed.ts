import { db } from "@/db";
import { adminUsers, settings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword } from "./auth";
import { DEFAULT_SETTINGS } from "./site-settings";

/**
 * Bootstrap only — creates the required settings + the initial admin account.
 * NO demo content is created: products, categories, companies, offers, orders,
 * customers and invoices all start empty and are managed by the site owner.
 */
let seeded = false;

export async function ensureSeed(): Promise<void> {
  if (seeded) return;
  try {
    // 1) settings (only missing keys are inserted)
    const existingSettings = await db.select().from(settings).limit(1);
    if (existingSettings.length === 0) {
      for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) {
        await db.insert(settings).values({ key: k, value: v }).onConflictDoNothing();
      }
    }

    // 2) initial administrator account (required to access the dashboard)
    const admins = await db.select().from(adminUsers).where(eq(adminUsers.email, "Admin@gmail.com")).limit(1);
    if (admins.length === 0) {
      const hash = await hashPassword("Admin101");
      await db.insert(adminUsers).values({
        name: "مدير المعرض",
        email: "Admin@gmail.com",
        passwordHash: hash,
        role: "admin",
        isActive: true,
      });
    }

    seeded = true;
  } catch (e) {
    console.error("seed error", e);
  }
}
