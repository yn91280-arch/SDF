// Centralized WhatsApp configuration.
// Number is stored in DB settings (key: whatsapp), defaults to 01147104601.
// Egypt country code: 20. Local numbers starting with 0 -> replace with 20.

export const DEFAULT_WHATSAPP = "01147104601";

/** Official website address used in WhatsApp messages and shared links */
export const SITE_URL = "https://Sanitary-ware-store";

export function normalizeWhatsApp(raw?: string | null): string {
  const v = (raw || DEFAULT_WHATSAPP).replace(/[^0-9]/g, "");
  if (v.startsWith("20") && v.length >= 12) return v;
  if (v.startsWith("0020")) return v.slice(2);
  if (v.startsWith("0")) return "20" + v.slice(1);
  if (v.length === 10) return "20" + v;
  return v || "201147104601";
}

export function waLink(phone: string, message: string): string {
  return `https://wa.me/${normalizeWhatsApp(phone)}?text=${encodeURIComponent(message)}`;
}

export function productWaMessage(p: {
  name: string;
  code?: string | null;
  company?: string | null;
  price?: number | string | null;
  quantity?: number;
  storeName?: string;
}): string {
  const lines = [
    "🛁 *طلب جديد من المعرض*",
    "———————————",
    `📦 المنتج: ${p.name}`,
    p.code ? `🔢 الكود: ${p.code}` : "",
    p.company ? `🏭 الشركة: ${p.company}` : "",
    p.price !== undefined && p.price !== null ? `💰 السعر: ${p.price} ج.م` : "",
    `🔢 الكمية: ${p.quantity ?? 1}`,
    "———————————",
    `🌐 الموقع: ${SITE_URL}`,
    `🏪 ${p.storeName || "معرض المصطفي"}`,
  ].filter(Boolean);
  return lines.join("\n");
}

export function orderWaMessage(o: {
  orderNumber: string;
  name: string;
  phone: string;
  address?: string;
  total: number | string;
  items: Array<{ name: string; qty: number; price: number | string }>;
  storeName?: string;
}): string {
  const itemLines = o.items.map((it, i) => `${i + 1}) ${it.name} × ${it.qty} = ${it.price} ج.م`).join("\n");
  return [
    "🧾 *طلب جديد من الموقع*",
    "———————————",
    `رقم الطلب: ${o.orderNumber}`,
    `الاسم: ${o.name}`,
    `الهاتف: ${o.phone}`,
    o.address ? `العنوان: ${o.address}` : "",
    "———————————",
    itemLines,
    "———————————",
    `الإجمالي: ${o.total} ج.م`,
    `🌐 الموقع: ${SITE_URL}`,
    `🏪 ${o.storeName || "معرض المصطفي"}`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function invoiceWaMessage(inv: {
  invoiceNumber: string;
  customerName: string;
  total: number | string;
  paid: number | string;
  remaining: number | string;
  storeName?: string;
}): string {
  return [
    "🧾 *فاتورة من المعرض*",
    "———————————",
    `رقم الفاتورة: ${inv.invoiceNumber}`,
    `العميل: ${inv.customerName}`,
    `الإجمالي: ${inv.total} ج.م`,
    `المدفوع: ${inv.paid} ج.م`,
    `المتبقي: ${inv.remaining} ج.م`,
    `🌐 الموقع: ${SITE_URL}`,
    `🏪 ${inv.storeName || "معرض المصطفي"}`,
  ].join("\n");
}

export function generalWaMessage(storeName = "معرض المصطفي"): string {
  return `السلام عليكم، أريد الاستفسار عن منتجات ${storeName}`;
}
