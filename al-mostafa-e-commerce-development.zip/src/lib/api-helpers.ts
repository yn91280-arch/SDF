import { NextResponse } from "next/server";

export function ok(data: unknown, status = 200) {
  return NextResponse.json({ ok: true, ...(typeof data === "object" && data !== null ? (data as Record<string, unknown>) : { data }) }, { status });
}

export function fail(message: string, status = 400, extra?: Record<string, unknown>) {
  return NextResponse.json({ ok: false, message, ...(extra || {}) }, { status });
}

export function serverError(e: unknown, message = "حدث خطأ في الخادم، حاول مرة أخرى") {
  console.error("API error:", e);
  return NextResponse.json({ ok: false, message }, { status: 500 });
}

export function parsePagination(url: URL) {
  const page = Math.max(1, parseInt(url.searchParams.get("page") || "1", 10) || 1);
  const rawLimit = parseInt(url.searchParams.get("limit") || "24", 10) || 24;
  const limit = Math.min(100, Math.max(1, rawLimit));
  return { page, limit, offset: (page - 1) * limit };
}
