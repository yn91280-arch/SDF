import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";

export const DEFAULT_SETTINGS: Record<string, string> = {
  site_url: "https://Sanitary-ware-store",
  store_name: "معرض المصطفي",
  store_name_en: "Al Mostafa Showroom",
  store_desc: "كل ما تحتاجه لتجهيز حمامك ومطبخك في مكان واحد — أفضل المنتجات من أفضل الشركات وبأسعار مميزة",
  manager: "إدارة / محمد محمود طلبة",
  phone: "01147104601",
  whatsapp: "01147104601",
  address: "مصر",
  maps_url: "",
  working_hours: "يومياً من 9 صباحاً حتى 11 مساءً",
  facebook: "",
  instagram: "",
  tiktok: "",
  youtube: "",
  currency: "ج.م",
  tax_enabled: "0",
  tax_percent: "14",
  invoice_prefix: "INV",
  invoice_notes: "شكراً لتعاملكم مع معرض المصطفي",
  hero_title: "كل ما تحتاجه لتجهيز حمامك ومطبخك في مكان واحد",
  hero_subtitle: "أفضل المنتجات من أفضل الشركات وبأسعار مميزة",
};

let cache: { data: Record<string, string>; at: number } | null = null;
const CACHE_MS = 30_000;

export async function getSettings(): Promise<Record<string, string>> {
  if (cache && Date.now() - cache.at < CACHE_MS) return cache.data;
  try {
    const rows = await db.select().from(settings);
    const data: Record<string, string> = { ...DEFAULT_SETTINGS };
    for (const r of rows) {
      if (r.key) data[r.key] = r.value ?? "";
    }
    cache = { data, at: Date.now() };
    return data;
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export async function getSetting(key: string): Promise<string> {
  const s = await getSettings();
  return s[key] ?? DEFAULT_SETTINGS[key] ?? "";
}

export async function setSetting(key: string, value: string): Promise<void> {
  cache = null;
  try {
    const existing = await db.select().from(settings).where(eq(settings.key, key)).limit(1);
    if (existing.length > 0) {
      await db.update(settings).set({ value, updatedAt: new Date() }).where(eq(settings.key, key));
    } else {
      await db.insert(settings).values({ key, value });
    }
  } catch {
    // ignore
  }
}

export async function setSettingsBulk(obj: Record<string, string>): Promise<void> {
  for (const [k, v] of Object.entries(obj)) {
    await setSetting(k, String(v ?? ""));
  }
}

export function clearSettingsCache() {
  cache = null;
}
