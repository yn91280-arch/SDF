import bcrypt from "bcryptjs";
import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { db } from "@/db";
import { adminSessions, adminUsers, customerSessions, customers, loginAttempts } from "@/db/schema";
import { eq, and, gte, desc } from "drizzle-orm";

const JWT_SECRET = new TextEncoder().encode(
  process.env.AUTH_SECRET || "al-mostafa-showroom-secret-key-change-me-2026"
);

export const ADMIN_COOKIE = "am_admin_token";
export const CUSTOMER_COOKIE = "am_customer_token";

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  try {
    return await bcrypt.compare(password, hash);
  } catch {
    return false;
  }
}

export function randomToken(bytes = 32): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let out = "";
  const arr = new Uint8Array(bytes);
  crypto.getRandomValues(arr);
  for (const b of arr) out += chars[b % chars.length];
  return out;
}

export async function signAdminJWT(payload: { adminId: number; email: string; role: string }): Promise<string> {
  return new SignJWT({ ...payload, type: "admin" })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(JWT_SECRET);
}

export async function verifyAdminJWT(token: string): Promise<{ adminId: number; email: string; role: string } | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    if (payload.type !== "admin") return null;
    return { adminId: payload.adminId as number, email: payload.email as string, role: (payload.role as string) || "admin" };
  } catch {
    return null;
  }
}

export async function signCustomerJWT(payload: { customerId: number }): Promise<string> {
  return new SignJWT({ ...payload, type: "customer" })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("30d")
    .sign(JWT_SECRET);
}

export async function verifyCustomerJWT(token: string): Promise<{ customerId: number } | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    if (payload.type !== "customer") return null;
    return { customerId: payload.customerId as number };
  } catch {
    return null;
  }
}

export async function getAdminFromRequest(): Promise<{ id: number; name: string; email: string; role: string } | null> {
  try {
    const jar = await cookies();
    const token = jar.get(ADMIN_COOKIE)?.value;
    if (!token) return null;
    const decoded = await verifyAdminJWT(token);
    if (!decoded) return null;
    const rows = await db.select().from(adminUsers).where(eq(adminUsers.id, decoded.adminId)).limit(1);
    const admin = rows[0];
    if (!admin || !admin.isActive) return null;
    return { id: admin.id, name: admin.name, email: admin.email, role: admin.role };
  } catch {
    return null;
  }
}

export async function getCustomerFromRequest(): Promise<{ id: number; name: string; phone: string; email: string | null } | null> {
  try {
    const jar = await cookies();
    const token = jar.get(CUSTOMER_COOKIE)?.value;
    if (!token) return null;
    const decoded = await verifyCustomerJWT(token);
    if (!decoded) return null;
    const rows = await db.select().from(customers).where(eq(customers.id, decoded.customerId)).limit(1);
    const c = rows[0];
    if (!c || !c.isActive) return null;
    return { id: c.id, name: c.name, phone: c.phone, email: c.email };
  } catch {
    return null;
  }
}

// Rate limiting: max 8 attempts per 15 min per identifier
export async function checkRateLimit(identifier: string): Promise<{ allowed: boolean; remaining: number }> {
  const fifteenMinAgo = new Date(Date.now() - 15 * 60 * 1000);
  try {
    const attempts = await db
      .select()
      .from(loginAttempts)
      .where(and(eq(loginAttempts.identifier, identifier), gte(loginAttempts.createdAt, fifteenMinAgo)))
      .orderBy(desc(loginAttempts.createdAt));
    const failed = attempts.filter((a) => !a.success).length;
    const allowed = failed < 8;
    return { allowed, remaining: Math.max(0, 8 - failed) };
  } catch {
    return { allowed: true, remaining: 8 };
  }
}

export async function recordLoginAttempt(identifier: string, success: boolean): Promise<void> {
  try {
    await db.insert(loginAttempts).values({ identifier, success });
  } catch {
    // ignore
  }
}

export { adminSessions, customerSessions };
