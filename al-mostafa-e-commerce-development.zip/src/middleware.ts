import { NextRequest, NextResponse } from "next/server";
import { jwtVerify } from "jose";

/**
 * Server-side route protection for the admin dashboard.
 * Every /admin/* route requires a valid admin session token,
 * except the login screen itself.
 */
const SECRET = new TextEncoder().encode(
  process.env.AUTH_SECRET || "al-mostafa-showroom-secret-key-change-me-2026"
);

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  if (pathname.startsWith("/admin") && pathname !== "/admin/login") {
    const token = req.cookies.get("am_admin_token")?.value;
    if (!token) {
      return NextResponse.redirect(new URL("/admin/login", req.url));
    }
    try {
      const { payload } = await jwtVerify(token, SECRET);
      if (payload.type !== "admin") throw new Error("invalid token type");
    } catch {
      const res = NextResponse.redirect(new URL("/admin/login", req.url));
      res.cookies.set("am_admin_token", "", { path: "/", maxAge: 0 });
      return res;
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*"],
};
